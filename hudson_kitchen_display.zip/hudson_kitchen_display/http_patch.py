# -*- coding: utf-8 -*-
import logging
import re
import time
import psycopg2
from odoo.tools import config
from odoo.http import router
from odoo.http.session import logout

_logger = logging.getLogger(__name__)

# Public QR / self-ordering URLs. Phones opening them must always reach the database
# the QR code belongs to, whatever database their session cookie was bound to before.
_SELF_ORDER_PATH_RE = re.compile(r'^/(?:r/|pos-self(?:-order)?(?:/|$)|pos-order-status/)')
_SELF_ORDER_REFERER_RE = re.compile(r'/(?:r/|pos-self(?:-order)?(?:/|$|\?))')


def _is_self_order_request(request):
    path = request.httprequest.path or ''
    if _SELF_ORDER_PATH_RE.match(path):
        return True
    referer = request.httprequest.headers.get('Referer') or ''
    return bool(_SELF_ORDER_REFERER_RE.search(referer))

# Keep a private reference to Odoo's own _set_session_and_dbname. Other addons
# may also patch the router (they chain through
# router._original_set_session_and_dbname), so this module stores its own copy
# and never depends on what they install.
if not hasattr(router, '_hudson_kds_core_set_session_and_dbname'):
    router._hudson_kds_core_set_session_and_dbname = getattr(
        router, '_original_set_session_and_dbname', router._set_session_and_dbname)


_MATCH_CACHE = {}
_MATCH_CACHE_TTL = 300  # seconds
_MATCH_CACHE_MAX = 512


def _first_db_matching(candidate_dbs, query, params):
    """Return the first database where ``query`` returns a row, else None.

    Connections are always closed, also when the query fails (e.g. the table
    does not exist in a payroll-only database), so lookups cannot leak
    PostgreSQL connections. Matches are cached for a few minutes: the self-order
    page polls the server, and every poll would otherwise open new connections.
    """
    key = (tuple(candidate_dbs), query, tuple(params))
    hit = _MATCH_CACHE.get(key)
    if hit and time.monotonic() - hit[1] < _MATCH_CACHE_TTL:
        return hit[0]
    c_db = _first_db_matching_uncached(candidate_dbs, query, params)
    if c_db:
        if len(_MATCH_CACHE) >= _MATCH_CACHE_MAX:
            _MATCH_CACHE.clear()
        _MATCH_CACHE[key] = (c_db, time.monotonic())
    return c_db


def _first_db_matching_uncached(candidate_dbs, query, params):
    conn_kwargs = {
        'user': config['db_user'] or 'odoo',
        'password': config['db_password'] or 'odoopwd',
        'host': config['db_host'] or 'localhost',
        'port': config['db_port'] or 5432,
        'connect_timeout': 5,
    }
    for c_db in candidate_dbs:
        conn = None
        try:
            conn = psycopg2.connect(dbname=c_db, **conn_kwargs)
            with conn.cursor() as cur:
                cur.execute(query, params)
                if cur.fetchone():
                    return c_db
        except Exception:
            continue
        finally:
            if conn is not None:
                conn.close()
    return None


def _patched_set_session_and_dbname(request):
    try:
        router._hudson_kds_core_set_session_and_dbname(request)
    except Exception as e:
        _logger.exception("Error in original _set_session_and_dbname: %s", e)

    try:
        current_db = getattr(request, 'db', None)
        # Normal requests keep the database Odoo picked (session cookie / monodb).
        # QR / self-order requests are always resolved: a phone whose cookie still
        # points to another database (an earlier visit, a test database) would
        # otherwise open that database and get a 404 or a 500 instead of the menu.
        if current_db and not _is_self_order_request(request):
            return
        target_db = _resolve_db(request)
        if not target_db or target_db == current_db:
            return
        session = request.session
        if current_db and session.db and session.db != target_db:
            _logger.info("Self-order request for %r with a session bound to %r: switching database.",
                         target_db, session.db)
            # Never carry a login (uid) from one database into another one.
            logout(session, keep_db=False)
        session.db = target_db
        request.db = target_db
    except Exception as e:
        _logger.exception("Error in _patched_set_session_and_dbname: %s", e)


def _resolve_db(request):
    """Database a QR / self-order request belongs to, or None when unknown."""
    host = request.httprequest.environ.get('HTTP_HOST') or ''
    path = request.httprequest.path or ''
    referer = request.httprequest.headers.get('Referer') or ''

    # 1. ?db= in the query string (self-order routes and QR links carry it)
    db_param = request.httprequest.args.get('db')
    if db_param:
        valid_dbs = router.db_filter([db_param], host=host)
        if valid_dbs:
            return valid_dbs[0]

    # 2. db= in the Referer query string (RPCs made by the self-order page)
    if 'db=' in referer:
        ref_db_match = re.search(r'[?&]db=([a-zA-Z0-9_\-]+)', referer)
        if ref_db_match:
            valid_dbs = router.db_filter([ref_db_match.group(1)], host=host)
            if valid_dbs:
                return valid_dbs[0]

    # Candidate databases: prioritize RESTO10, then all available databases
    all_dbs = router.db_list(force=True, host=host)
    candidate_dbs = []
    if 'RESTO10' in all_dbs:
        candidate_dbs.append('RESTO10')
    for d in all_dbs:
        if d not in candidate_dbs:
            candidate_dbs.append(d)

    # 3. Host matches a database's web.base.url (dev tunnel such as
    #    63d065bx-8069.inc1.devtunnels.ms). Checked first: it is the most
    #    precise signal and always points to the live restaurant database.
    # Dev Tunnels / reverse proxies rewrite Host to localhost:8069 and
    # pass the public address in X-Forwarded-Host, so prefer that.
    headers = request.httprequest.headers
    public_host = (
        headers.get('X-Forwarded-Host')
        or headers.get('X-Original-Host')
        or host
    ).split(',')[0].strip()
    clean_host = public_host.split(':')[0]
    if clean_host and clean_host not in ('localhost', '127.0.0.1', '0.0.0.0'):
        c_db = _first_db_matching(
            candidate_dbs,
            "SELECT 1 FROM ir_config_parameter WHERE key = 'web.base.url' AND value LIKE %s LIMIT 1",
            (f"%{clean_host}%",))
        if c_db:
            return c_db

    # 4. Link Tracker short URLs: /r/<code> (printed table QR codes)
    link_code = None
    if path.startswith('/r/'):
        code_match = re.search(r'^/r/([a-zA-Z0-9_\-]+)', path)
        if code_match:
            link_code = code_match.group(1)
    elif '/r/' in referer:
        code_match = re.search(r'/r/([a-zA-Z0-9_\-]+)', referer)
        if code_match:
            link_code = code_match.group(1)

    if link_code:
        c_db = _first_db_matching(
            candidate_dbs,
            "SELECT 1 FROM link_tracker_code WHERE code = %s LIMIT 1",
            (link_code,))
        if c_db:
            return c_db

    # 5. POS Self-Order access token (exact match only). Matching on the
    #    POS id alone is deliberately NOT done: ids repeat across databases
    #    and would send customers to a test database.
    pos_token = request.httprequest.args.get('access_token')
    if not pos_token and 'access_token=' in referer:
        t_match = re.search(r'[?&]access_token=([a-zA-Z0-9_\-]+)', referer)
        if t_match:
            pos_token = t_match.group(1)

    if pos_token:
        config_id_match = re.search(r'/pos-self(?:/data)?/(\d+)', path) or re.search(r'/pos-self(?:/data)?/(\d+)', referer)
        if config_id_match:
            return _first_db_matching(
                candidate_dbs,
                "SELECT 1 FROM pos_config WHERE id = %s AND access_token = %s LIMIT 1",
                (int(config_id_match.group(1)), pos_token))
        return _first_db_matching(
            candidate_dbs,
            "SELECT 1 FROM pos_config WHERE access_token = %s LIMIT 1",
            (pos_token,))
    return None


_patched_set_session_and_dbname._hudson_kds_patch = True


def apply_http_patch():
    """Install the KDS database resolver without replacing other addons' patches.

    Other addons that patch the router call ``router._original_set_session_and_dbname``
    before running their own lookup. Pointing that attribute at this function
    puts KDS underneath them in the chain, so a patch installed later (or earlier)
    by another addon can no longer drop the self-order/QR resolution.
    """
    core = router._hudson_kds_core_set_session_and_dbname
    router._original_set_session_and_dbname = _patched_set_session_and_dbname
    current = router._set_session_and_dbname
    if current is core or getattr(current, '_hudson_kds_patch', False):
        # Nothing else is patched on top: install KDS directly.
        router._set_session_and_dbname = _patched_set_session_and_dbname
    _logger.info("Successfully installed Hudson _set_session_and_dbname router patch.")


apply_http_patch()
