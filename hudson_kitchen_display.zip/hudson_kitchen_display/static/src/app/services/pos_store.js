/** @odoo-module */

import { PosStore } from "@point_of_sale/app/services/pos_store";
import { patch } from "@web/core/utils/patch";
import { debounce } from "@web/core/utils/timing";

patch(PosStore.prototype, {
    /**
     * Odoo creates `syncAllOrdersDebounced` only AFTER `initServerData()`, but while that
     * data loads, pos_restaurant may already delete duplicate table orders, and on a
     * shared config `removeOrder` calls it -> "this.syncAllOrdersDebounced is not a
     * function" and the POS fails to start. Create it on demand (setup re-creates it later).
     */
    removeOrder(order, removeFromServer = true) {
        if (typeof this.syncAllOrdersDebounced !== "function") {
            this.syncAllOrdersDebounced = debounce(this.syncAllOrders, 100);
        }
        return super.removeOrder(...arguments);
    },

    /**
     * Push the order to the Kitchen Display. Staff POS orders reach the KDS only this way
     * (the server no longer auto-sends them), so a failure is shown to the waiter instead
     * of being silently swallowed.
     */
    async _hkdSendToKitchen(order) {
        if (!order || typeof order.sendToKitchen !== "function") {
            return;
        }
        let res;
        try {
            res = await order.sendToKitchen();
        } catch (err) {
            console.error("Error sending order to kitchen display:", err);
            res = { ok: false, message: err?.message || String(err) };
        }
        if (res && res.ok === false && !/already being sent|order is empty/i.test(res.message || "")) {
            console.warn("Kitchen Display did not receive the order:", res);
            this.notification.add(`Kitchen Display: ${res.message || "order not sent"}`, {
                type: "danger",
                sticky: false,
            });
        }
    },

    async sendOrderInPreparation(order, opts = {}) {
        // A cancellation is not a new round for the kitchen (cancelled orders are archived
        // server-side): never re-send the lines in that case.
        if (!opts.cancelled) {
            await this._hkdSendToKitchen(order);
        }
        return await super.sendOrderInPreparation(...arguments);
    },

    /** "Fire course" only prints a course ticket in Odoo: also push it to the KDS. */
    async fireCourse(course) {
        const result = await super.fireCourse(...arguments);
        await this._hkdSendToKitchen(course?.order_id);
        return result;
    },
});
