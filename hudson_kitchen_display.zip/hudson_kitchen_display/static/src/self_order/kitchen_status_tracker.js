import { Component, onMounted, onWillUnmount, proxy, t, useProps } from "@odoo/owl";
import { rpc } from "@web/core/network/rpc";
import { _t } from "@web/core/l10n/translation";
import { serializeDateTime } from "@web/core/l10n/dates";
import { patch } from "@web/core/utils/patch";
import { SelfOrder } from "@pos_self_order/app/services/self_order_service";
import { LandingPage } from "@pos_self_order/app/pages/landing_page/landing_page";
import { OrdersHistoryPage } from "@pos_self_order/app/pages/order_history_page/order_history_page";
import { CartPage } from "@pos_self_order/app/pages/cart_page/cart_page";
import { ConfirmationPage } from "@pos_self_order/app/pages/confirmation_page/confirmation_page";

export class KitchenOrderStatusCard extends Component {
    static template = "hudson_kitchen_display.KitchenOrderStatusCard";

    props = useProps({
        orderAccessToken: t.string(),
        showRefreshHint: t.boolean().optional(),
    });

    setup() {
        this.selfOrder = this.env.services.self_order;
        // Open by default so food items and stepper are directly visible
        this.state = proxy({ collapsedTickets: {} });
    }

    toggleBatch(ticketId) {
        this.state.collapsedTickets[ticketId] = !this.state.collapsedTickets[ticketId];
    }

    isBatchExpanded(batch) {
        return !this.state.collapsedTickets[batch.ticket_id];
    }

    get status() {
        return this.selfOrder.kitchenStatusByToken?.[this.props.orderAccessToken] || null;
    }

    get hasDisplays() {
        const s = this.status;
        return Boolean(
            s &&
            !s.is_cancelled &&
            s.has_kitchen &&
            !s.is_served_done &&
            s.summary_state !== "completed" &&
            ((s.batches && s.batches.length) || (s.displays && s.displays.length))
        );
    }

    get batches() {
        const s = this.status;
        if (!s || s.is_cancelled || !s.has_kitchen || s.is_served_done || s.summary_state === "completed") {
            return [];
        }
        if (s.batches && s.batches.length) {
            // Show newest batch first so repeat orders appear immediately at top
            return [...s.batches].reverse();
        }
        return (s.displays || []).map((d, idx) => ({
            ...d,
            ticket_id: d.display_id || idx + 1,
            batch_number: idx + 1,
            categories: [],
        }));
    }

    get hasMultipleBatches() {
        return this.batches.length > 1;
    }

    get summaryPillClass() {
        const s = this.status;
        if (!s) return "hkd_self_status_pill--cook";
        if (s.is_served_done || s.summary_state === "completed") {
            return "hkd_self_status_pill--done";
        }
        if ((s.summary_label || "").toLowerCase().includes("ready")) {
            return "hkd_self_status_pill--ready";
        }
        return "hkd_self_status_pill--cook";
    }

    getBatchTitle(batch) {
        if (batch.display_name) {
            return batch.display_name;
        }
        return _t("Current Kitchen Order");
    }

    getStationThemeClass(batch) {
        if (batch.is_served_done || batch.is_completed) {
            return "hkd_self_status_station--completed";
        }
        const name = (batch.current_stage_name || "").toLowerCase();
        if (name.includes("ready")) {
            return "hkd_self_status_station--ready";
        }
        return "hkd_self_status_station--cook";
    }

    formatBatchTime(createdAt) {
        if (!createdAt) return "";
        try {
            const iso = createdAt.replace(" ", "T") + "Z";
            const d = new Date(iso);
            if (Number.isNaN(d.getTime())) return "";
            return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
        } catch {
            return "";
        }
    }

    getPillClass(disp) {
        if (disp.is_served_done || disp.is_completed) {
            return "hkd_self_status_pill--done";
        }
        const name = (disp.current_stage_name || "").toLowerCase();
        if (name.includes("ready")) {
            return "hkd_self_status_pill--ready";
        }
        return "hkd_self_status_pill--cook";
    }

    getStepClasses(disp, stage, idx) {
        const classes = [];
        if (stage.state === "done") {
            classes.push("hkd_self_step--done");
        } else if (stage.state === "active") {
            classes.push("hkd_self_step--active");
        } else {
            classes.push("hkd_self_step--pending");
        }
        if (idx === (disp.stages?.length || 0) - 1) {
            classes.push("hkd_self_step--last");
        }
        return classes.join(" ");
    }

    isLeftLineFilled(disp, idx) {
        if (idx === 0) {
            return false;
        }
        const prev = disp.stages?.[idx - 1];
        return prev?.state === "done";
    }

    isRightLineFilled(disp, idx) {
        const stages = disp.stages || [];
        if (idx >= stages.length - 1) {
            return false;
        }
        const curr = stages[idx];
        return curr?.state === "done";
    }
}

patch(SelfOrder.prototype, {
    setup() {
        super.setup(...arguments);
        this.kitchenStatusByToken = proxy({});
        this._kitchenTrackingCount = 0;
        this._kitchenTrackingTimer = null;
        this._kitchenRefreshDebounce = null;
        this._kitchenFetchInFlight = false;
        this._kitchenFetchQueued = false;
        this._kitchenQueuedOrders = null;

        this.data.connectWebSocket("KITCHEN_STATUS_CHANGED", () => {
            if (this._kitchenTrackingCount > 0) {
                this.scheduleKitchenStatusRefresh(100);
            }
        });
        this.data.connectWebSocket("ORDER_STATE_CHANGED", () => {
            if (this._kitchenTrackingCount > 0) {
                this.scheduleKitchenStatusRefresh(350);
            }
        });
    },

    /**
     * When an order has already been sent/synced to the server, do not reuse
     * it for new cart items. Each new submission creates an individual order.
     */
    isOrderAvailable(order) {
        if (this.config?.self_ordering_mode === "mobile" && order?.isSynced) {
            return false;
        }
        return super.isOrderAvailable(...arguments);
    },

    /**
     * Each person scanning the table QR gets an independent, unique order.
     * Table orders are never shared between different devices or guests:
     * only orders placed by THIS device (matching its own accessTokens) are retrieved.
     */
    async _getUserDataFromServer(tokens = [], opts = {}) {
        if (this.config?.self_ordering_mode !== "mobile") {
            return super._getUserDataFromServer(...arguments);
        }
        const dbAccessToken = this.models["pos.order"]
            .filter((o) => o.state === "draft" && o.isSynced && o.access_token)
            .map((order) => {
                let writeDateStr = "1970-01-01 00:00:00";
                if (order.write_date) {
                    try {
                        const nextDate = typeof order.write_date.plus === "function"
                            ? order.write_date.plus({ seconds: 1 })
                            : order.write_date;
                        writeDateStr = serializeDateTime(nextDate) || writeDateStr;
                    } catch {
                        writeDateStr = "1970-01-01 00:00:00";
                    }
                }
                return {
                    access_token: order.access_token,
                    state: order.state,
                    write_date: writeDateStr,
                };
            });
        const argTokens = tokens.map((token) => ({
            access_token: token,
            write_date: "1970-01-01 00:00:00",
        }));
        const accessTokens = [...dbAccessToken, ...argTokens];
        if (accessTokens.length === 0) {
            // New scan by a guest who hasn't placed an order yet: keep session clean and private
            return;
        }
        const pendingDeltas = this._computePendingDeltas();
        try {
            const data = await rpc(`/pos-self-order/get-user-data/`, {
                access_token: this.access_token,
                order_access_tokens: accessTokens,
                table_identifier: null, // Never share table-wide orders across devices
            });
            const result = this.models.connectNewData(data);
            for (const order of result["pos.order"] || []) {
                if (order.state === "draft") {
                    this._reapplyPendingDeltas(order, pendingDeltas);
                }
            }
            // Never reopen an order already sent to the kitchen as the cart
            const selected = this.selectedOrderUuid
                ? this.models["pos.order"].getBy("uuid", this.selectedOrderUuid)
                : null;
            if (selected && !this.isOrderAvailable(selected)) {
                this.selectedOrderUuid = null;
            }
            this.data.debouncedSynchronizeLocalDataInIndexedDB();
        } catch (error) {
            this.handleErrorNotification(
                error,
                this.models["pos.order"].map((order) => order.access_token)
            );
        }
    },

    /** Download Receipt on every order sent to the restaurant (unpaid ones get a provisional bill). */
    showDownloadButton(order) {
        if (this.config?.self_ordering_mode !== "mobile") {
            return super.showDownloadButton(...arguments);
        }
        return Boolean(order && typeof order.id === "number" && order.access_token && order.state !== "cancel");
    },

    async downloadReceipt(order) {
        if (this.config?.self_ordering_mode !== "mobile") {
            return super.downloadReceipt(...arguments);
        }
        // All states use our route: it falls back to a PDF when the server has no wkhtmltoimage
        // (Odoo's own /pos-self-order/receipt then fails with "422 Unprocessable Entity").
        if (!order?.id || typeof order.id !== "number") {
            return;
        }
        const link = document.createElement("a");
        link.href = `/pos-self-order/hkd-receipt/${order.id}?access_token=${encodeURIComponent(order.access_token)}`;
        link.click();
    },

    /** True while the kitchen is still working on the order this status belongs to. */
    isKitchenStatusActive(status) {
        return Boolean(
            status &&
            !status.is_cancelled &&
            status.has_kitchen &&
            !status.is_served_done &&
            status.summary_state !== "completed" &&
            ((status.batches && status.batches.length) || (status.displays && status.displays.length))
        );
    },

    /**
     * Orders whose kitchen status must be (re)fetched:
     * - orders not fetched yet,
     * - orders the kitchen is still working on,
     * - draft orders.
     */
    getActiveKitchenOrders(orders = null) {
        let candidates = orders;
        if (!candidates || !candidates.length) {
            candidates = (this.models["pos.order"] || [])
                .filter((o) => o && o.access_token)
                .sort((a, b) => (b.id || 0) - (a.id || 0))
                .slice(0, 20);
        }
        return (candidates || []).filter((o) => {
            if (!o || !o.access_token || o.state === "cancel") {
                return false;
            }
            const status = this.kitchenStatusByToken?.[o.access_token];
            if (!status || o.state === "draft") {
                return true;
            }
            return this.isKitchenStatusActive(status);
        });
    },

    _ensureKitchenTimer() {
        if (this._kitchenTrackingTimer || this._kitchenTrackingCount <= 0) {
            return;
        }
        this._kitchenTrackingTimer = setInterval(() => {
            if (this._kitchenTrackingCount > 0) {
                this.fetchKitchenStatus();
            } else if (this._kitchenTrackingTimer) {
                clearInterval(this._kitchenTrackingTimer);
                this._kitchenTrackingTimer = null;
            }
        }, 3500);
    },

    async fetchKitchenStatus(orders = null) {
        if (this.config?.self_ordering_mode !== "mobile") {
            return;
        }
        if (this._kitchenFetchInFlight) {
            this._kitchenFetchQueued = true;
            if (orders && orders.length) {
                this._kitchenQueuedOrders = orders;
            }
            return;
        }
        const activeOrders = this.getActiveKitchenOrders(orders);
        if (!activeOrders.length) {
            if (this._kitchenTrackingTimer) {
                clearInterval(this._kitchenTrackingTimer);
                this._kitchenTrackingTimer = null;
            }
            return;
        }
        const seenTokens = new Set();
        const payload = [];
        for (const o of activeOrders) {
            if (!seenTokens.has(o.access_token)) {
                seenTokens.add(o.access_token);
                payload.push({ id: o.id, access_token: o.access_token });
            }
        }
        if (!payload.length) {
            if (this._kitchenTrackingTimer) {
                clearInterval(this._kitchenTrackingTimer);
                this._kitchenTrackingTimer = null;
            }
            return;
        }
        this._kitchenFetchInFlight = true;
        try {
            const res = await rpc("/pos-self-order/kitchen-status", {
                access_token: this.access_token,
                orders: payload,
            });
            const statuses = res?.statuses || {};
            for (const [token, nextStatus] of Object.entries(statuses)) {
                const prev = this.kitchenStatusByToken[token];
                if (JSON.stringify(prev) !== JSON.stringify(nextStatus)) {
                    this.kitchenStatusByToken[token] = nextStatus;
                }
            }
            const remaining = this.getActiveKitchenOrders();
            if (!remaining.length && this._kitchenTrackingTimer) {
                clearInterval(this._kitchenTrackingTimer);
                this._kitchenTrackingTimer = null;
            } else if (remaining.length) {
                this._ensureKitchenTimer();
            }
        } catch {
            // Keep last known state on transient error
        } finally {
            this._kitchenFetchInFlight = false;
            if (this._kitchenFetchQueued) {
                const nextOrders = this._kitchenQueuedOrders;
                this._kitchenFetchQueued = false;
                this._kitchenQueuedOrders = null;
                this.fetchKitchenStatus(nextOrders);
            }
        }
    },

    scheduleKitchenStatusRefresh(delayMs = 150) {
        clearTimeout(this._kitchenRefreshDebounce);
        this._kitchenRefreshDebounce = setTimeout(() => {
            this.fetchKitchenStatus();
        }, delayMs);
    },

    startKitchenTracking(orders = null) {
        this._kitchenTrackingCount += 1;
        const activeOrders = this.getActiveKitchenOrders(orders);
        if (!activeOrders.length) {
            return;
        }
        this.fetchKitchenStatus(activeOrders);
        this._ensureKitchenTimer();
    },

    stopKitchenTracking() {
        this._kitchenTrackingCount = Math.max(0, this._kitchenTrackingCount - 1);
        if (this._kitchenTrackingCount === 0 && this._kitchenTrackingTimer) {
            clearInterval(this._kitchenTrackingTimer);
            this._kitchenTrackingTimer = null;
        }
    },
});

patch(LandingPage.prototype, {
    clickMyOrder() {
        this.router.navigate("orderHistory");
    },
});

OrdersHistoryPage.components = {
    ...(OrdersHistoryPage.components || {}),
    KitchenOrderStatusCard,
};

patch(OrdersHistoryPage.prototype, {
    setup() {
        super.setup(...arguments);
        this.historyFilter = proxy({
            viewMode: "kitchen", // "kitchen" (default) or "past"
        });
        this._historyKitchenStarted = false;
        this._historyUnmounted = false;
        onMounted(async () => {
            if (this.selfOrder.config?.self_ordering_mode === "mobile") {
                if (!this._historyUnmounted && !this._historyKitchenStarted) {
                    this._historyKitchenStarted = true;
                    this.selfOrder.startKitchenTracking(this.allOrders);
                }
                try {
                    await this.selfOrder.getUserDataFromServer();
                    if (!this._historyUnmounted && this.allOrders?.length) {
                        this.selfOrder.fetchKitchenStatus(this.allOrders);
                    }
                } catch {
                    // Fallback
                }
            }
        });
        onWillUnmount(() => {
            this._historyUnmounted = true;
            if (this._historyKitchenStarted) {
                this.selfOrder.stopKitchenTracking();
                this._historyKitchenStarted = false;
            }
        });
    },

    get allOrders() {
        return (this.selfOrder.models["pos.order"] || [])
            .filter((o) => o && o.access_token)
            .sort((a, b) => (b.id || 0) - (a.id || 0));
    },

    get kitchenOrders() {
        return this.allOrders.filter((order) => this.isOrderInKitchen(order));
    },

    get pastOrders() {
        return this.allOrders.filter((order) => !this.isOrderInKitchen(order));
    },

    get orders() {
        if (this.selfOrder.config?.self_ordering_mode !== "mobile") {
            return this.allOrders;
        }
        return this.historyFilter.viewMode === "past" ? this.pastOrders : this.kitchenOrders;
    },

    setViewMode(mode) {
        this.historyFilter.viewMode = mode;
    },

    toggleViewMode() {
        this.historyFilter.viewMode = this.historyFilter.viewMode === "past" ? "kitchen" : "past";
    },

    /**
     * An order is considered actively in the kitchen when:
     * - It is not cancelled
     * - The KDS status shows active batches or displays (not yet served / completed)
     * - Or if it was placed and still in draft/kitchen sync state
     */
    isOrderInKitchen(order) {
        if (!order || !order.access_token || order.state === "cancel") {
            return false;
        }
        const status = this.selfOrder.kitchenStatusByToken?.[order.access_token];
        if (status) {
            if (status.is_cancelled) {
                return false;
            }
            if (status.is_served_done || status.summary_state === "completed") {
                return false;
            }
            if (status.has_kitchen) {
                return true;
            }
        }
        if (order.state === "paid") {
            return false;
        }
        return order.state === "draft";
    },

    /**
     * Checks if this specific order is active in the kitchen.
     * When completed, it returns false, causing the KDS card to disappear.
     */
    isOrderActive(order) {
        if (!order || !order.access_token || order.state === "cancel") {
            return false;
        }
        const status = this.selfOrder.kitchenStatusByToken?.[order.access_token];
        return Boolean(
            status &&
            !status.is_cancelled &&
            status.has_kitchen &&
            !status.is_served_done &&
            status.summary_state !== "completed" &&
            ((status.batches && status.batches.length) || (status.displays && status.displays.length))
        );
    },

    editOrder(order) {
        // Do not navigate away when clicking the order header
        return;
    },

    getOrderBadgeClass(order) {
        if (!order) {
            return "badge py-2 rounded-pill text-capitalize text-bg-primary";
        }
        const status = this.selfOrder.kitchenStatusByToken?.[order.access_token];
        if (status && status.has_kitchen) {
            if (status.is_cancelled) {
                return "badge py-2 rounded-pill text-capitalize text-bg-danger";
            }
            if (status.is_served_done || status.summary_state === "completed" || order.state === "paid") {
                return "badge py-2 rounded-pill text-capitalize text-bg-success";
            }
            const label = (status.summary_label || "").toLowerCase();
            if (label.includes("ready")) {
                return "badge py-2 rounded-pill text-capitalize text-bg-warning text-dark";
            }
            return "badge py-2 rounded-pill text-capitalize text-bg-info text-white";
        }
        return order.state === "paid"
            ? "badge py-2 rounded-pill text-capitalize text-bg-success"
            : "badge py-2 rounded-pill text-capitalize text-bg-primary";
    },

    getOrderStatusLabel(order) {
        if (!order) {
            return "";
        }
        const status = this.selfOrder.kitchenStatusByToken?.[order.access_token];
        if (status && status.has_kitchen) {
            if (status.is_cancelled) {
                return _t("Cancelled");
            }
            if (status.is_served_done || status.summary_state === "completed") {
                return _t("Served");
            }
            if (status.summary_label) {
                return status.summary_label;
            }
        }
        return typeof this.getOrderState === "function"
            ? this.getOrderState(order.state)
            : (order.state === "draft" ? _t("Current") : order.state);
    },
});

CartPage.components = {
    ...(CartPage.components || {}),
    KitchenOrderStatusCard,
};

patch(CartPage.prototype, {
    setup() {
        super.setup(...arguments);
        this._cartKitchenStarted = false;
        this._cartUnmounted = false;
        onMounted(async () => {
            if (this.selfOrder.config?.self_ordering_mode === "mobile" && !this.isCheckout) {
                if (this.showKitchenStatusBanner && !this._cartUnmounted && !this._cartKitchenStarted) {
                    this._cartKitchenStarted = true;
                    this.selfOrder.startKitchenTracking([this.selfOrder.currentOrder]);
                }
                try {
                    await this.selfOrder.getUserDataFromServer();
                    if (this.showKitchenStatusBanner && !this._cartUnmounted) {
                        if (!this._cartKitchenStarted) {
                            this._cartKitchenStarted = true;
                            this.selfOrder.startKitchenTracking([this.selfOrder.currentOrder]);
                        } else {
                            this.selfOrder.fetchKitchenStatus([this.selfOrder.currentOrder]);
                        }
                    }
                } catch {
                    // Fallback polling still handles updates.
                }
            }
        });
        onWillUnmount(() => {
            this._cartUnmounted = true;
            if (this._cartKitchenStarted) {
                this.selfOrder.stopKitchenTracking();
                this._cartKitchenStarted = false;
            }
        });
    },

    get showKitchenStatusBanner() {
        const order = this.selfOrder.currentOrder;
        return Boolean(
            this.selfOrder.config?.self_ordering_mode === "mobile" &&
            !this.isCheckout &&
            order &&
            order.isSynced &&
            order.access_token &&
            order.state !== "cancel"
        );
    },

    openMyOrders() {
        this.router.navigate("orderHistory");
    },
});

ConfirmationPage.components = {
    ...(ConfirmationPage.components || {}),
    KitchenOrderStatusCard,
};

patch(ConfirmationPage.prototype, {
    setup() {
        super.setup(...arguments);
        this._confirmationKitchenStarted = false;
        onMounted(() => {
            if (this.selfOrder.config?.self_ordering_mode === "mobile") {
                const token = this.props.orderAccessToken;
                const order = (this.selfOrder.models["pos.order"] || []).find((o) => o && o.access_token === token);
                this._confirmationKitchenStarted = true;
                this.selfOrder.startKitchenTracking(order ? [order] : null);
            }
        });
        onWillUnmount(() => {
            if (this._confirmationKitchenStarted) {
                this.selfOrder.stopKitchenTracking();
                this._confirmationKitchenStarted = false;
            }
            if (this.selfOrder.config?.self_ordering_mode === "mobile" && this.selfOrder.selectedOrderUuid) {
                this.selfOrder.selectedOrderUuid = null;
            }
        });
    },

    get confirmedOrder() {
        let order = null;
        if (this.props?.orderAccessToken) {
            order = (this.selfOrder.models["pos.order"] || []).find(
                (o) => o && o.access_token === this.props.orderAccessToken
            );
        }
        if (!order && this.selfOrder.selectedOrderUuid) {
            order = this.selfOrder.models["pos.order"]?.getBy?.("uuid", this.selfOrder.selectedOrderUuid);
        }
        if (!order) {
            order = this.selfOrder.currentOrder;
        }
        return order || {};
    },

    async initOrder() {
        await super.initOrder(...arguments);
        if (this.selfOrder.config?.self_ordering_mode === "mobile" && this.confirmedOrder?.access_token) {
            await this.selfOrder.fetchKitchenStatus([this.confirmedOrder]);
        }
    },

    get showMobileKitchenStatus() {
        return Boolean(
            this.selfOrder.config?.self_ordering_mode === "mobile" &&
            this.confirmedOrder?.access_token
        );
    },

    openMyOrders() {
        this.router.navigate("orderHistory");
    },
});
