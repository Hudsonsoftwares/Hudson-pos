# -*- coding: utf-8 -*-
import importlib
import logging
from odoo import models

_logger = logging.getLogger(__name__)

try:
    from .. import http_patch
    importlib.reload(http_patch)
    if hasattr(http_patch, 'apply_http_patch'):
        http_patch.apply_http_patch()
except Exception as e:
    _logger.debug("Could not reload http_patch from pos_config: %s", e)


class PosConfig(models.Model):
    _inherit = 'pos.config'

    def _get_self_order_route(self, table_id=None, order=None):
        route = super()._get_self_order_route(table_id=table_id, order=order)
        if route and 'db=' not in route and self.env.cr.dbname:
            sep = '&' if '?' in route else '?'
            route = f"{route}{sep}db={self.env.cr.dbname}"
        return route
