# -*- coding: utf-8 -*-
from . import models
from . import controllers


def _post_init_hook(env):
    """Ensure Pre-Order Food preset and schedule exist and are linked to POS configs on install."""
    # 1. Ensure resource calendar has 7 days 11:00 - 22:00
    cal = env.ref('pos_restaurant.pos_resource_preset', raise_if_not_found=False)
    if not cal:
        cal = env['resource.calendar'].search([('name', '=', 'Opening time')], limit=1)
    if not cal:
        cal = env['resource.calendar'].sudo().create({
            'name': 'Opening time',
            'company_id': env.company.id,
        })
    if cal and len(cal.attendance_ids) != 7:
        cal.attendance_ids.unlink()
        attendances = []
        for day in range(7):
            attendances.append((0, 0, {
                'dayofweek': str(day),
                'hour_from': 11.0,
                'hour_to': 22.0,
                'day_period': 'full_day',
            }))
        cal.sudo().write({'attendance_ids': attendances})

    # 2. Ensure Pre-Order Food preset is configured
    preset = env.ref('pos_restaurant.pos_takeout_preset', raise_if_not_found=False)
    if not preset:
        preset = env['pos.preset'].search([('name', 'in', ['Takeout', 'Pre-Order Food'])], limit=1)

    preset_vals = {
        'name': 'Pre-Order Food',
        'color': 3,
        'identification': 'name',
        'use_timing': True,
        'slots_per_interval': 5,
        'interval_time': 20,
        'available_in_self': True,
        'service_at': 'counter',
        'resource_calendar_id': cal.id if cal else False,
    }
    mail_template = env.ref('pos_self_order.takeout_email_template', raise_if_not_found=False)
    if mail_template:
        preset_vals['mail_template_id'] = mail_template.id

    if preset:
        preset.sudo().write(preset_vals)
    else:
        preset = env['pos.preset'].sudo().create(preset_vals)

    # 3. Attach preset to all restaurant pos.config records
    pos_configs = env['pos.config'].sudo().search([])
    for cfg in pos_configs:
        if preset not in cfg.available_preset_ids:
            cfg.write({'available_preset_ids': [(4, preset.id)]})

    # 4. Sync restaurant tables & configure Table Booking appointment type for website customer choice
    app_types = env['appointment.type'].sudo().search([('name', 'ilike', 'Table Booking')])
    for at in app_types:
        at.write({'assign_method': 'customer'})
    tables = env['restaurant.table'].sudo().search([])
    tables._sync_appointment_resource()
