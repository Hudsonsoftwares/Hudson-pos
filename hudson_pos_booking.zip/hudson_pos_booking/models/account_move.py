# -*- coding: utf-8 -*-
from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    booking_id = fields.Many2one(
        'appointment.booking',
        string="Linked Table Booking",
        compute='_compute_booking_id',
        store=True,
        check_company=True,
    )

    @api.depends('invoice_line_ids.sale_line_ids.order_id', 'company_id')
    def _compute_booking_id(self):
        for move in self:
            booking = False
            so_ids = move.invoice_line_ids.sale_line_ids.order_id.ids
            if so_ids:
                booking = self.env['appointment.booking'].search([
                    ('sale_order_id', 'in', so_ids),
                    ('company_id', 'in', [move.company_id.id, False]),
                ], limit=1)
            move.booking_id = booking

