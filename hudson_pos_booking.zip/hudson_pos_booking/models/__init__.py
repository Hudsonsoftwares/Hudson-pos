# -*- coding: utf-8 -*-
from . import appointment_type
from . import restaurant_table
from . import pos_config
from . import appointment_booking
from . import pos_order
from . import pos_session
from . import res_config_settings
from . import account_move
