# -*- coding: utf-8 -*-
# Part of Hudson. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models

class PosOrder(models.Model):
    _inherit = 'pos.order'

    booking_id = fields.Many2one(
        'appointment.booking',
        string='Table Booking',
        readonly=True,
        index='btree_not_null',
        help="The appointment booking associated with this POS order."
    )

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        if 'booking_id' not in fields_list:
            fields_list.append('booking_id')
        return fields_list

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('booking_id') and vals.get('table_id'):
                order_dt = vals.get('date_order') or fields.Datetime.now()
                # Only link to an actively checked-in booking on this table whose time window contains order_dt
                booking = self.env['appointment.booking'].search([
                    ('table_ids', 'in', [vals['table_id']]),
                    ('state', '=', 'checked_in'),
                    ('start_datetime', '<=', fields.Datetime.add(fields.Datetime.to_datetime(order_dt), minutes=30)),
                    ('end_datetime', '>=', fields.Datetime.to_datetime(order_dt)),
                ], order='start_datetime asc', limit=1)
                if booking:
                    vals['booking_id'] = booking.id
        orders = super().create(vals_list)
        for order in orders:
            if order.booking_id:
                order.booking_id._notify_pos_floor()
        return orders

    def write(self, vals):
        res = super().write(vals)
        for order in self:
            if order.booking_id:
                order.booking_id._notify_pos_floor()
        return res

