import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { getOnNotified } from "@point_of_sale/utils";
import { _t } from "@web/core/l10n/translation";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";

function upsertBooking(posStore, data) {
    if (!data) return;
    const bookingData = (data["appointment.booking"] && Array.isArray(data["appointment.booking"]))
        ? data["appointment.booking"][0]
        : data;
    if (!bookingData || !bookingData.id) return;
    try {
        const bookingModel = posStore.models?.["appointment.booking"];
        if (bookingModel) {
            const existing = typeof bookingModel.get === "function" ? bookingModel.get(bookingData.id) : null;
            if (existing) {
                if (typeof existing.update === "function") {
                    existing.update(bookingData);
                }
                Object.assign(existing, bookingData);
            }
        }
        if (posStore.models && typeof posStore.models.connectNewData === "function") {
            posStore.models.connectNewData({ "appointment.booking": [bookingData] });
        }
    } catch (err) {
        console.warn("Could not upsert booking into pos model:", err);
    }
}

patch(PosStore.prototype, {
    async setup() {
        await super.setup(...arguments);
        if (this.config.use_booking && this.bus) {
            this._setupBookingBusListener();
        }
    },

    _setupBookingBusListener() {
        if (!this.config.access_token) return;
        const onNotified = getOnNotified(this.bus, this.config.access_token);
        onNotified("BOOKING_UPDATE", (payload) => {
            this._onRemoteBookingUpdate(payload);
        });
    },

    _onRemoteBookingUpdate(payload) {
        if (!payload || !payload.booking_data) return;
        upsertBooking(this, payload.booking_data);
    },

    ensureBookingSettledAndNamed(order) {
        if (!order || order.finalized) return;
        // 1. Resolve booking
        let booking = order.booking_id;
        if (typeof booking === "number") {
            booking = this.models["appointment.booking"]?.get?.(booking) || null;
            if (booking) order.booking_id = booking;
        }
        if (!booking && order.table_id) {
            const table = typeof order.table_id === "object" ? order.table_id : this.models["restaurant.table"]?.get?.(order.table_id);
            if (table && table.getUpcomingBooking) {
                booking = table.getUpcomingBooking();
                if (booking) order.booking_id = booking;
            }
        }
        if (!booking) return;

        // 2. Resolve guest partner (Never use internal company partner)
        const partnerId = typeof booking.partner_id === "object" && booking.partner_id ? (booking.partner_id.id || booking.partner_id[0]) : booking.partner_id;
        let partner = (partnerId && this.models["res.partner"]?.get) ? this.models["res.partner"].get(partnerId) : null;
        if (partner && (!order.partner_id || order.partner_id.id === 1 || order.partner_id.name === "Resto Cafe")) {
            if (typeof order.setPartner === "function") {
                order.setPartner(partner);
            } else {
                order.partner_id = partner;
            }
        }

        // 3. Customer count
        if (booking.party_size && !order.customer_count) {
            order.customer_count = booking.party_size;
        }

        // 4. Pre-ordered food items auto-credit
        if ((booking.has_food_order || (booking.food_order_total > 0)) && order.lines && order.lines.length > 0) {
            const prepaidTarget = parseFloat(booking.food_order_total) || 0;
            const existingPaid = (order.payment_ids || []).reduce(
                (sum, p) => sum + (parseFloat(p.amount) || 0), 
                0
            );

            const unpaidPrepaid = Math.max(0, prepaidTarget - existingPaid);

            if (unpaidPrepaid > 0) {
                const totalDue = order.remainingDue !== undefined ? order.remainingDue : (typeof order.get_due === "function" ? order.get_due() : (order.totalDue || 0));
                const amountToCredit = Math.min(unpaidPrepaid, totalDue > 0 ? totalDue : 0);

                if (amountToCredit > 0) {
                    const pmList = this.config.payment_method_ids || this.models["pos.payment.method"]?.getAll?.() || [];
                    const cardPm = pmList.find(m => {
                        const n = (m.name || "").toLowerCase();
                        return n.includes("card") || n.includes("online") || n.includes("bank") || n.includes("customer account");
                    }) || pmList[0];

                    if (cardPm && typeof order.addPaymentline === "function") {
                        try {
                            const res = order.addPaymentline(cardPm);
                            const payLine = res?.data || (typeof order.getSelectedPaymentline === "function" ? order.getSelectedPaymentline() : null);
                            if (payLine && typeof payLine.setAmount === "function") {
                                payLine.setAmount(amountToCredit);
                            }
                        } catch (pErr) {
                            console.warn("Could not auto-settle online pre-payment line:", pErr);
                        }
                    }
                }
            }
        }
    },

    async setTableFromUi(table, orderUuid = null, isFromBooking = false) {
        if (!orderUuid && !isFromBooking && this.config.use_booking && table) {
            const existingOrders = this.getTableOrders(table.id) || [];
            // If there is an existing active order for this table, let standard POS handle it
            if (existingOrders.length > 0) {
                return super.setTableFromUi(table, orderUuid);
            }
            // Only auto-load if a booking on this table is ALREADY checked_in
            const booking = table.getUpcomingBooking ? table.getUpcomingBooking() : null;
            if (booking && booking.state === "checked_in") {
                await this.loadBookingIntoTable(booking, table);
                return;
            }
        }
        return super.setTableFromUi(table, orderUuid);
    },

    async loadBookingIntoTable(booking, table) {
        if (!booking || !table) return;

        // 1. Check in booking if confirmed
        if (booking.state === "confirmed") {
            await this.updateBookingFromPos(booking.id, { state: "checked_in" });
        }

        // 2. Clear any lingering stale draft order from table that is NOT for this booking
        const existingTableOrders = this.getTableOrders(table.id) || [];
        let matchingOrder = null;
        for (const o of existingTableOrders) {
            if (!o.finalized) {
                if (o.booking_id && o.booking_id.id === booking.id) {
                    matchingOrder = o;
                } else if (!o.lines || o.lines.length === 0) {
                    this.removeOrder(o);
                }
            }
        }

        // 3. Switch to table
        if (!matchingOrder) {
            await this.setTableFromUi(table, null, true);
        } else {
            this.setOrder(matchingOrder);
        }
        const order = matchingOrder || this.getOrder();
        if (!order) return;

        // 4. Attach booking to order
        order.booking_id = booking;

        // 5. Customer partner
        const partnerId = typeof booking.partner_id === "object" && booking.partner_id ? (booking.partner_id.id || booking.partner_id[0]) : booking.partner_id;
        let partner = (partnerId && this.models["res.partner"]?.get) ? this.models["res.partner"].get(partnerId) : null;
        if (partner) {
            if (typeof order.setPartner === "function") {
                order.setPartner(partner);
            } else {
                order.partner_id = partner;
            }
        }

        // 6. Customer count
        if (booking.party_size) {
            order.customer_count = booking.party_size;
        }

        // 7. Auto-load pre-ordered food items if cart is empty
        if (Array.isArray(booking.food_order_details) && booking.food_order_details.length > 0 && (!order.lines || order.lines.length === 0)) {
            const productModel = this.models["product.product"];
            const templateModel = this.models["product.template"];
            for (const item of booking.food_order_details) {
                const product = productModel?.get ? productModel.get(item.product_id) : (productModel?.getAll?.()?.find(p => p.id === item.product_id));
                if (product) {
                    const tmplId = product.product_tmpl_id?.id || product.product_tmpl_id;
                    const productTemplate = (templateModel?.get ? templateModel.get(tmplId) : null) || product.product_tmpl_id;
                    try {
                        await this.addLineToOrder({
                            product_id: product,
                            product_tmpl_id: productTemplate,
                            qty: item.qty || 1,
                        }, order, {}, false);
                    } catch (e) {
                        console.warn("Could not auto-add dish:", e);
                    }
                }
            }
        }

        // 8. Auto-credit online pre-payment if dishes are present
        const prepaidTarget = parseFloat(booking.food_order_total) || 0;
        if (prepaidTarget > 0 && order.lines && order.lines.length > 0) {
            const existingPaid = (order.payment_ids || []).reduce(
                (sum, p) => sum + (parseFloat(p.amount) || 0), 
                0
            );
            const unpaidPrepaid = Math.max(0, prepaidTarget - existingPaid);
            if (unpaidPrepaid > 0) {
                const totalDue = order.remainingDue !== undefined ? order.remainingDue : (typeof order.get_due === "function" ? order.get_due() : (order.totalDue || 0));
                const amountToCredit = Math.min(unpaidPrepaid, totalDue > 0 ? totalDue : 0);
                if (amountToCredit > 0) {
                    const pmList = this.config.payment_method_ids || this.models["pos.payment.method"]?.getAll?.() || [];
                    const cardPm = pmList.find(m => {
                        const n = (m.name || "").toLowerCase();
                        return n.includes("card") || n.includes("online") || n.includes("bank") || n.includes("customer account");
                    }) || pmList[0];

                    if (cardPm && typeof order.addPaymentline === "function") {
                        try {
                            const res = order.addPaymentline(cardPm);
                            const payLine = res?.data || (typeof order.getSelectedPaymentline === "function" ? order.getSelectedPaymentline() : null);
                            if (payLine && typeof payLine.setAmount === "function") {
                                payLine.setAmount(amountToCredit);
                            }
                        } catch (pErr) {
                            console.warn("Could not auto-settle payment line:", pErr);
                        }
                    }
                }
            }
        }

        // 9. Navigate to ProductScreen to display order lines, guest name and total
        this.navigate("ProductScreen", { orderUuid: order.uuid });
    },

    async releaseTable(table, booking = null) {
        if (!table) return;
        const tableObj = (typeof table === "object" && table) ? table : (this.models["restaurant.table"]?.get?.(table) || { id: table });
        const tableId = tableObj.id || table;
        // Strictly use explicit booking passed - NEVER grab unrelated future bookings!
        const bId = booking ? (typeof booking === "object" ? booking.id : booking) : false;
        try {
            const orm = this.data?.orm || this.env?.services?.orm;
            if (orm) {
                await orm.call("pos.config", "pos_release_table", [this.config.id, tableId, bId]);
            } else if (this.data?.call) {
                await this.data.call("pos.config", "pos_release_table", [this.config.id, tableId, bId]);
            }

            // Clean only empty orders for this table locally (protect split bills)
            const currentOrder = this.getOrder();
            if (currentOrder && currentOrder.table_id?.id === tableId && (!currentOrder.lines || currentOrder.lines.length === 0)) {
                this.removeOrder(currentOrder);
            }
            if (this.models["pos.order"]) {
                const emptyTableOrders = this.models["pos.order"].filter(o => o.table_id?.id === tableId && !o.finalized && (!o.lines || o.lines.length === 0));
                for (const o of emptyTableOrders) {
                    this.removeOrder(o);
                }
            }

            // Update local booking state
            if (bId && this.models["appointment.booking"]?.get) {
                const b = this.models["appointment.booking"].get(bId);
                if (b) {
                    b.state = "checked_out";
                    b.end_datetime = luxon.DateTime.now().toISO();
                }
            }

            // Navigate back to FloorScreen
            this.navigate("FloorScreen");
        } catch (err) {
            console.error("Error releasing table:", err);
            this.navigate("FloorScreen");
        }
    },

    async orderDone(order) {
        const table = order?.table_id;
        const booking = order?.booking_id;
        
        super.orderDone(...arguments);

        if (this.config.module_pos_restaurant && table) {
            // Only release table if there are no other open orders on the table AND this order had a booking
            const remainingOrders = (this.getTableOrders(table.id) || []).filter(o => !o.finalized && o.id !== order.id);
            if (remainingOrders.length === 0 && booking) {
                try {
                    await this.releaseTable(table, booking);
                } catch (err) {
                    console.error("Error releasing table on orderDone:", err);
                }
            }
            this.navigate("FloorScreen");
        }
    },

    addNewOrder(vals = {}) {
        const order = super.addNewOrder(...arguments);
        if (this.config.use_booking && order) {
            this.ensureBookingSettledAndNamed(order);
        }
        return order;
    },

    setOrder(order) {
        super.setOrder(...arguments);
        if (order && !order.finalized && this.config.use_booking) {
            this.ensureBookingSettledAndNamed(order);
        }
    },

    async setTable(table, order = null) {
        await super.setTable(...arguments);
        if (this.config.use_booking && table) {
            const currentOrder = this.getOrder();
            if (currentOrder) {
                this.ensureBookingSettledAndNamed(currentOrder);
            }
        }
    },

    async createBookingFromPos(vals) {
        if (!navigator.onLine) {
            this.dialog.add(AlertDialog, {
                title: _t("Network Offline"),
                body: _t("Cannot create bookings while offline. Please check your connection."),
            });
            return null;
        }
        try {
            const orm = this.data?.orm || this.env?.services?.orm;
            const res = orm
                ? await orm.call("pos.config", "pos_create_booking", [this.config.id, vals])
                : await this.data.call("pos.config", "pos_create_booking", [this.config.id, vals]);
            if (res) {
                upsertBooking(this, res);
            }
            return res;
        } catch (error) {
            this.dialog.add(AlertDialog, {
                title: _t("Booking Error"),
                body: error?.message?.data?.message || error?.message || _t("Failed to create booking."),
            });
            return null;
        }
    },

    async updateBookingFromPos(bookingId, vals) {
        if (!navigator.onLine) {
            this.dialog.add(AlertDialog, {
                title: _t("Network Offline"),
                body: _t("Cannot update bookings while offline. Please check your connection."),
            });
            return null;
        }
        try {
            const orm = this.data?.orm || this.env?.services?.orm;
            const res = orm
                ? await orm.call("pos.config", "pos_update_booking", [this.config.id, bookingId, vals])
                : await this.data.call("pos.config", "pos_update_booking", [this.config.id, bookingId, vals]);
            if (res) {
                upsertBooking(this, res);
            }
            return res;
        } catch (error) {
            this.dialog.add(AlertDialog, {
                title: _t("Update Error"),
                body: error?.message?.data?.message || error?.message || _t("Failed to update booking."),
            });
            return null;
        }
    }
});
