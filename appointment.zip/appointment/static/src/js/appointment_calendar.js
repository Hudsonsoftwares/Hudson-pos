/** @odoo-module **/

import { CalendarController } from "@web/views/calendar/calendar_controller";
import { calendarView } from "@web/views/calendar/calendar_view";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { _t } from "@web/core/l10n/translation";
import { AppointmentBookingQuickCreateDialog } from "./appointment_booking_quick_create";
import { AppointmentCalendarRenderer } from "./appointment_booking_popover";

export class AppointmentCalendarController extends CalendarController {
    static components = {
        ...CalendarController.components,
        QuickCreateFormView: AppointmentBookingQuickCreateDialog,
    };

    setup() {
        super.setup();
        this.actionService = useService("action");
    }

    getQuickCreateFormViewProps(record) {
        return {
            ...super.getQuickCreateFormViewProps(record),
            title: _t("New Booking"),
            onRecordSaved: () => this.model.load(),
        };
    }

    onClickNew() {
        if (this.model.canCreate && this.model.quickCreateFormViewId) {
            // same pop-up as clicking a calendar cell, starting at the next full hour
            const start = luxon.DateTime.local().plus({ hours: 1 }).startOf("hour");
            return this.createRecord({ start, end: start.plus({ hours: 1 }), isAllDay: false });
        }
        this.actionService.doAction("appointment.action_appointment_booking_quick_create", {
            onClose: () => {
                if (this.model && this.model.load) {
                    this.model.load();
                }
            },
        });
    }

    onClickAddClosingDay() {
        const context = this.props.context;
        const additionalContext = {};
        if (context.appointment_closing_type) {
            additionalContext.default_closing_type = context.appointment_closing_type;
        } else if (context.default_appointment_type_id) {
            // bookings of one appointment type: close that appointment type
            additionalContext.default_appointment_type_ids = [context.default_appointment_type_id];
        }
        this.actionService.doAction("appointment.action_appointment_closing_day_new", {
            additionalContext,
        });
    }
}

export const appointmentCalendarView = {
    ...calendarView,
    Controller: AppointmentCalendarController,
    Renderer: AppointmentCalendarRenderer,
    buttonTemplate: "appointment.CalendarController.controlButtons",
};
registry.category("views").add("appointment_calendar", appointmentCalendarView);
