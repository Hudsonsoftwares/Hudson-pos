/** @odoo-module **/

import { Component, onWillStart, onWillUnmount, onWillUpdateProps, proxy, signal, t, useProps } from "@odoo/owl";

import { _t } from "@web/core/l10n/translation";
import { deserializeDateTime, serializeDateTime } from "@web/core/l10n/dates";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { CogMenu } from "@web/search/cog_menu/cog_menu";
import { Layout } from "@web/search/layout";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { useSearchBarToggler } from "@web/search/search_bar/search_bar_toggler";
import { standardViewProps } from "@web/views/standard_view_props";

import { AppointmentBookingQuickCreateDialog } from "./appointment_booking_quick_create";

const { DateTime } = luxon;

const LANE_HEIGHT = 34; // px, height of one stacked booking in a row
const DRAG_THRESHOLD = 4; // px, below this a pointer gesture is a click
const MIN_DURATION_MINUTES = 15;

// time unit of each scale: one column = one hour (day) or one day (week, month)
const SCALES = {
    day: { label: _t("Day"), unit: "day", step: { hours: 1 }, snapMinutes: 15 },
    week: { label: _t("Week"), unit: "week", step: { days: 1 }, snapMinutes: 60 },
    month: { label: _t("Month"), unit: "month", step: { days: 1 }, snapMinutes: 24 * 60 },
};

const BOOKING_FIELDS = [
    "name", "subject", "partner_id", "start_datetime", "end_datetime", "state",
    "staff_user_id", "resource_ids", "appointment_type_id",
];

export class AppointmentScheduleController extends Component {
    static template = "appointment.ScheduleView";
    static components = { Layout, SearchBar, CogMenu };

    props = useProps({
        ...standardViewProps,
        archInfo: t.object(),
    });

    gridRef = signal.ref();

    setup() {
        this.orm = useService("orm");
        this.dialog = useService("dialog");
        this.action = useService("action");
        this.notification = useService("notification");
        this.searchBarToggler = useSearchBarToggler();
        this.scales = SCALES;

        this.state = proxy({
            scale: this.props.archInfo.defaultScale,
            anchor: DateTime.local().startOf("day"),
            columns: [],
            rows: [],
            totals: [],
            drag: null,
            loading: false,
        });

        this._onPointerMove = this.onPointerMove.bind(this);
        this._onPointerUp = this.onPointerUp.bind(this);
        onWillUnmount(() => this.stopDragListeners());

        onWillStart(() => this.load(this.props));
        onWillUpdateProps((nextProps) => this.load(nextProps));
    }

    // ------------------------------------------------------------------
    // Range / columns
    // ------------------------------------------------------------------

    get scaleKeys() {
        return Object.keys(SCALES);
    }

    get groupBy() {
        return this.props.archInfo.groupBy;
    }

    get rowsTitle() {
        return this.groupBy === "resource_ids" ? _t("Resources") : _t("Staff");
    }

    getRange(scale = this.state.scale, anchor = this.state.anchor) {
        const unit = SCALES[scale].unit;
        const start = anchor.startOf(unit);
        return { start, end: start.plus({ [`${unit}s`]: 1 }) };
    }

    get rangeLabel() {
        const { start, end } = this.getRange();
        if (this.state.scale === "day") {
            return start.toLocaleString(DateTime.DATE_HUGE);
        }
        if (this.state.scale === "week") {
            const last = end.minus({ days: 1 });
            return `${start.toLocaleString({ day: "numeric", month: "short" })} – ${last.toLocaleString(DateTime.DATE_MED)}`;
        }
        return start.toLocaleString({ month: "long", year: "numeric" });
    }

    buildColumns(scale, start, end) {
        const step = SCALES[scale].step;
        const columns = [];
        const today = DateTime.local().startOf("day");
        for (let cursor = start; cursor < end; cursor = cursor.plus(step)) {
            const colEnd = cursor.plus(step);
            let label;
            if (scale === "day") {
                label = cursor.toLocaleString({ hour: "numeric" });
            } else if (scale === "week") {
                label = cursor.toLocaleString({ weekday: "short", day: "numeric" });
            } else {
                label = String(cursor.day);
            }
            columns.push({
                key: cursor.toMillis(),
                start: cursor,
                end: colEnd,
                label,
                isToday: scale !== "day" && cursor.hasSame(today, "day"),
                isWeekend: scale !== "day" && cursor.weekday >= 6,
            });
        }
        return columns;
    }

    // ------------------------------------------------------------------
    // Data
    // ------------------------------------------------------------------

    async load(props = this.props) {
        const { start, end } = this.getRange();
        const startUtc = serializeDateTime(start);
        const endUtc = serializeDateTime(end);
        const context = props.context || {};
        this.state.loading = true;
        try {
            const bookingDomain = [
                ...(props.domain || []),
                ["state", "!=", "cancelled"],
                ["start_datetime", "<", endUtc],
                ["end_datetime", ">", startUtc],
            ];
            const [bookings, targets, closings] = await Promise.all([
                this.orm.searchRead(props.resModel, bookingDomain, BOOKING_FIELDS, { context }),
                this.loadTargets(context),
                // closing days of a user / resource, or company-wide ones (no
                // appointment type): same rule as the booking checks, done on
                // the server so types of other companies are not mistaken for "none"
                this.orm.searchRead(
                    "appointment.closing.day",
                    [
                        ["start_datetime", "<", endUtc],
                        ["end_datetime", ">", startUtc],
                        "|",
                        ["closing_type", "!=", "appointments"],
                        ["appointment_type_ids", "=", false],
                    ],
                    ["name", "closing_type", "start_datetime", "end_datetime", "user_id", "resource_id"],
                    { context }
                ),
            ]);
            this.buildGrid(start, end, bookings, targets, closings);
        } finally {
            this.state.loading = false;
        }
    }

    /** Staff members (of staff-based types) or resources: one row each, even without bookings. */
    async loadTargets(context) {
        // opened from one appointment type: only its staff members / resources
        const typeId = Number.isInteger(context.default_appointment_type_id) ? context.default_appointment_type_id : false;
        if (this.groupBy === "resource_ids") {
            let resourceDomain = [];
            if (typeId) {
                const [type] = await this.orm.read("appointment.type", [typeId], ["resource_ids"], { context });
                resourceDomain = [["id", "in", type ? type.resource_ids : []]];
            }
            return this.orm.searchRead("appointment.resource", resourceDomain, ["name"], { context, order: "name" });
        }
        const typeDomain = [["booking_target", "=", "users"]];
        if (typeId) {
            typeDomain.push(["id", "=", typeId]);
        }
        const types = await this.orm.searchRead(
            "appointment.type", typeDomain, ["user_ids"], { context }
        );
        const userIds = [...new Set(types.flatMap((type) => type.user_ids))];
        if (!userIds.length) {
            return [];
        }
        return this.orm.searchRead("res.users", [["id", "in", userIds]], ["name"], { context, order: "name" });
    }

    buildGrid(start, end, rawBookings, targets, rawClosings) {
        const rangeMs = end.toMillis() - start.toMillis();
        const position = (from, to) => {
            const left = Math.max(0, (from.toMillis() - start.toMillis()) / rangeMs);
            const right = Math.min(1, (to.toMillis() - start.toMillis()) / rangeMs);
            return { left: left * 100, width: Math.max(right - left, 0) * 100 };
        };

        const rowsByKey = new Map();
        const addRow = (key, resId, name, isUnassigned = false) => {
            if (!rowsByKey.has(key)) {
                rowsByKey.set(key, { key, resId, name, isUnassigned, bookings: [], closings: [], lanes: 1 });
            }
            return rowsByKey.get(key);
        };
        addRow("unassigned", false, _t("Unassigned"), true);
        for (const target of targets) {
            addRow(`r${target.id}`, target.id, target.display_name || target.name);
        }

        const bookings = rawBookings.map((raw) => {
            const bookingStart = deserializeDateTime(raw.start_datetime);
            const bookingEnd = deserializeDateTime(raw.end_datetime);
            return {
                id: raw.id,
                raw,
                start: bookingStart,
                end: bookingEnd,
                title: raw.subject || raw.name,
                customer: raw.partner_id ? raw.partner_id[1] : "",
                timeLabel: `${bookingStart.toLocaleString(DateTime.TIME_SIMPLE)} – ${bookingEnd.toLocaleString(DateTime.TIME_SIMPLE)}`,
                state: raw.state,
            };
        });

        // place each booking in its row(s)
        for (const booking of bookings) {
            const raw = booking.raw;
            if (this.groupBy === "resource_ids") {
                const resourceIds = raw.resource_ids || [];
                if (!resourceIds.length) {
                    rowsByKey.get("unassigned").bookings.push(booking);
                }
                for (const resourceId of resourceIds) {
                    const name = targets.find((target) => target.id === resourceId)?.name || _t("Resource %s", resourceId);
                    addRow(`r${resourceId}`, resourceId, name).bookings.push(booking);
                }
            } else if (raw.staff_user_id) {
                addRow(`r${raw.staff_user_id[0]}`, raw.staff_user_id[0], raw.staff_user_id[1]).bookings.push(booking);
            } else {
                rowsByKey.get("unassigned").bookings.push(booking);
            }
        }

        // stack overlapping bookings of a row in lanes
        for (const row of rowsByKey.values()) {
            const laneEnds = [];
            row.items = row.bookings
                .slice()
                .sort((a, b) => a.start - b.start || a.end - b.end)
                .map((booking) => {
                    let lane = laneEnds.findIndex((laneEnd) => laneEnd <= booking.start);
                    if (lane === -1) {
                        lane = laneEnds.length;
                        laneEnds.push(booking.end);
                    } else {
                        laneEnds[lane] = booking.end;
                    }
                    return { booking, lane, ...position(booking.start, booking.end) };
                });
            row.lanes = Math.max(1, laneEnds.length);
        }

        // closing days: per user / resource, or the whole company (no type)
        for (const raw of rawClosings) {
            const closing = {
                id: raw.id,
                name: raw.name,
                ...position(deserializeDateTime(raw.start_datetime), deserializeDateTime(raw.end_datetime)),
            };
            if (raw.closing_type === "users" && this.groupBy === "staff_user_id" && raw.user_id) {
                rowsByKey.get(`r${raw.user_id[0]}`)?.closings.push(closing);
            } else if (raw.closing_type === "resources" && this.groupBy === "resource_ids" && raw.resource_id) {
                rowsByKey.get(`r${raw.resource_id[0]}`)?.closings.push(closing);
            } else if (raw.closing_type === "appointments") {
                for (const row of rowsByKey.values()) {
                    row.closings.push(closing);
                }
            }
        }

        const columns = this.buildColumns(this.state.scale, start, end);
        const unassigned = rowsByKey.get("unassigned");
        const rows = [...rowsByKey.values()].filter((row) => !row.isUnassigned);
        this.state.rows = unassigned.bookings.length || !rows.length ? [unassigned, ...rows] : rows;
        this.state.columns = columns;
        this.state.totals = columns.map(
            (column) => bookings.filter((booking) => booking.start < column.end && booking.end > column.start).length
        );
    }

    // ------------------------------------------------------------------
    // Navigation
    // ------------------------------------------------------------------

    async setScale(scale) {
        this.state.scale = scale;
        await this.load();
    }

    async move(direction) {
        const unit = SCALES[this.state.scale].unit;
        this.state.anchor = this.state.anchor.plus({ [`${unit}s`]: direction });
        await this.load();
    }

    async goToday() {
        this.state.anchor = DateTime.local().startOf("day");
        await this.load();
    }

    // ------------------------------------------------------------------
    // Records
    // ------------------------------------------------------------------

    openBooking(booking) {
        if (this.props.selectRecord) {
            this.props.selectRecord(booking.id);
        }
    }

    openQuickCreate(start, row = null) {
        const end = start.plus({ hours: 1 });
        const context = {
            ...this.props.context,
            form_view_ref: "appointment.appointment_booking_view_form_quick_create",
            default_start_datetime: serializeDateTime(start),
            default_end_datetime: serializeDateTime(end),
        };
        if (row) {
            if (this.groupBy === "resource_ids") {
                context.default_resource_ids = row.isUnassigned ? [] : [row.resId];
            } else {
                context.default_staff_user_id = row.isUnassigned ? false : row.resId;
            }
        }
        this.dialog.add(AppointmentBookingQuickCreateDialog, {
            resModel: this.props.resModel,
            title: _t("New Booking"),
            context,
            onRecordSaved: () => this.load(),
        });
    }

    onClickNew() {
        this.openQuickCreate(DateTime.local().plus({ hours: 1 }).startOf("hour"));
    }

    /** Same as the Calendar's "Add Closing Day" button; refreshes the shading once saved. */
    onClickAddClosingDay() {
        const context = this.props.context || {};
        const additionalContext = {};
        if (context.appointment_closing_type) {
            additionalContext.default_closing_type = context.appointment_closing_type;
        } else if (context.default_appointment_type_id) {
            // bookings of one appointment type: close that appointment type
            additionalContext.default_appointment_type_ids = [context.default_appointment_type_id];
        }
        this.action.doAction("appointment.action_appointment_closing_day_new", {
            additionalContext,
            onClose: () => this.load(),
        });
    }

    onCellClick(row, column) {
        // day scale: the clicked hour; week / month: 9:00 that day (or the next hour today)
        let start = column.start;
        if (this.state.scale !== "day") {
            start = column.start.set({ hour: 9 });
            const nextHour = DateTime.local().plus({ hours: 1 }).startOf("hour");
            if (start.hasSame(nextHour, "day") && start < nextHour) {
                start = nextHour;
            }
        }
        this.openQuickCreate(start, row);
    }

    // ------------------------------------------------------------------
    // Drag & drop: move / re-assign (bar) and resize (right handle)
    // ------------------------------------------------------------------

    onBarPointerDown(ev, row, item, mode = "move") {
        if (ev.button !== 0) {
            return;
        }
        ev.preventDefault();
        const grid = this.gridRef();
        const timeline = grid && grid.querySelector(".o_as_timeline");
        this.state.drag = {
            mode,
            bookingId: item.booking.id,
            item,
            sourceRow: row,
            startX: ev.clientX,
            startY: ev.clientY,
            dx: 0,
            dy: 0,
            moved: false,
            timelineWidth: timeline ? timeline.getBoundingClientRect().width : 1,
        };
        window.addEventListener("pointermove", this._onPointerMove);
        window.addEventListener("pointerup", this._onPointerUp);
    }

    onPointerMove(ev) {
        const drag = this.state.drag;
        if (!drag) {
            return;
        }
        drag.dx = ev.clientX - drag.startX;
        drag.dy = drag.mode === "move" ? ev.clientY - drag.startY : 0;
        if (Math.abs(drag.dx) > DRAG_THRESHOLD || Math.abs(drag.dy) > DRAG_THRESHOLD) {
            drag.moved = true;
        }
    }

    async onPointerUp(ev) {
        const drag = this.state.drag;
        this.stopDragListeners();
        if (!drag) {
            return;
        }
        if (!drag.moved) {
            this.state.drag = null;
            this.openBooking(drag.item.booking);
            return;
        }
        // dropped row (the dragged bar ignores the pointer while dragging)
        const target = document.elementFromPoint(ev.clientX, ev.clientY);
        const rowEl = target && target.closest(".o_as_row[data-row-key]");
        const targetRow = (rowEl && this.state.rows.find((row) => row.key === rowEl.dataset.rowKey)) || drag.sourceRow;
        this.state.drag = null;
        await this.saveDrag(drag, targetRow);
    }

    stopDragListeners() {
        window.removeEventListener("pointermove", this._onPointerMove);
        window.removeEventListener("pointerup", this._onPointerUp);
    }

    snapMinutes(minutes) {
        const snap = SCALES[this.state.scale].snapMinutes;
        return Math.round(minutes / snap) * snap;
    }

    async saveDrag(drag, targetRow) {
        const { start, end } = this.getRange();
        const msPerPx = (end.toMillis() - start.toMillis()) / Math.max(drag.timelineWidth, 1);
        const deltaMinutes = this.snapMinutes((drag.dx * msPerPx) / 60000);
        const booking = drag.item.booking;
        const vals = {};

        if (drag.mode === "resize") {
            let newEnd = booking.end.plus({ minutes: deltaMinutes });
            if (newEnd <= booking.start.plus({ minutes: MIN_DURATION_MINUTES })) {
                newEnd = booking.start.plus({ minutes: MIN_DURATION_MINUTES });
            }
            if (+newEnd !== +booking.end) {
                vals.end_datetime = serializeDateTime(newEnd);
            }
        } else {
            if (deltaMinutes) {
                vals.start_datetime = serializeDateTime(booking.start.plus({ minutes: deltaMinutes }));
                vals.end_datetime = serializeDateTime(booking.end.plus({ minutes: deltaMinutes }));
            }
            if (targetRow.key !== drag.sourceRow.key) {
                if (this.groupBy === "resource_ids") {
                    const commands = [];
                    if (!drag.sourceRow.isUnassigned) {
                        commands.push([3, drag.sourceRow.resId]);
                    }
                    if (!targetRow.isUnassigned) {
                        commands.push([4, targetRow.resId]);
                    }
                    vals.resource_ids = commands;
                } else {
                    vals.staff_user_id = targetRow.isUnassigned ? false : targetRow.resId;
                }
            }
        }
        if (!Object.keys(vals).length) {
            return;
        }
        try {
            await this.orm.write(this.props.resModel, [booking.id], vals, { context: this.props.context });
            this.notification.add(_t("Booking updated."), { type: "success" });
        } catch (error) {
            // e.g. the slot is already booked: the booking constraints refuse it
            const message = error?.data?.message || error?.message || _t("The booking could not be moved.");
            this.notification.add(message, { type: "danger", sticky: false });
        }
        await this.load();
    }

    // ------------------------------------------------------------------
    // Rendering helpers
    // ------------------------------------------------------------------

    rowHeight(row) {
        return row.lanes * LANE_HEIGHT + 8;
    }

    barStyle(item) {
        const drag = this.state.drag;
        let style = `left: ${item.left}%; width: max(${item.width}%, 6px); top: ${4 + item.lane * LANE_HEIGHT}px; height: ${LANE_HEIGHT - 4}px;`;
        if (drag && drag.moved && drag.bookingId === item.booking.id && drag.item === item) {
            if (drag.mode === "resize") {
                style += ` width: max(calc(${item.width}% + ${drag.dx}px), 6px);`;
            } else {
                style += ` transform: translate(${drag.dx}px, ${drag.dy}px);`;
            }
        }
        return style;
    }

    isDragging(item) {
        const drag = this.state.drag;
        return Boolean(drag && drag.moved && drag.item === item);
    }
}

class AppointmentScheduleArchParser {
    parse(arch) {
        const scale = arch.getAttribute("default_scale");
        return {
            title: arch.getAttribute("string") || "",
            groupBy: arch.getAttribute("group_by") || "staff_user_id",
            defaultScale: SCALES[scale] ? scale : "day",
        };
    }
}

export const appointmentScheduleView = {
    type: "appointment_schedule",
    searchMenuTypes: ["filter", "favorite"],
    Controller: AppointmentScheduleController,
    ArchParser: AppointmentScheduleArchParser,
    props: (genericProps, view) => ({
        ...genericProps,
        archInfo: new view.ArchParser().parse(genericProps.arch),
    }),
};

registry.category("views").add("appointment_schedule", appointmentScheduleView);
