/** @odoo-module **/

import { useService } from "@web/core/utils/hooks";
import { CalendarCommonPopover } from "@web/views/calendar/calendar_common/calendar_common_popover";
import { CalendarCommonRenderer } from "@web/views/calendar/calendar_common/calendar_common_renderer";
import { CalendarRenderer } from "@web/views/calendar/calendar_renderer";

// status buttons of the booking popover: [state, server method]
const STATUS_ACTIONS = {
    confirmed: "action_set_booked",
    checked_in: "action_check_in",
    no_show: "action_no_show",
};

export class AppointmentBookingPopover extends CalendarCommonPopover {
    static defaultFooterButtonsTemplate = "appointment.BookingPopoverFooterButtons";

    setup() {
        super.setup();
        this.orm = useService("orm");
    }

    get bookingState() {
        return this.props.record.rawRecord?.state;
    }

    // status colour of the popover header (see appointment_type_views.scss)
    get cardPopoverProps() {
        const props = super.cardPopoverProps;
        if (this.bookingState) {
            props.rootClass = `${props.rootClass} o_appointment_state_${this.bookingState}`;
        }
        return props;
    }

    statusButtonClass(state) {
        if (state !== this.bookingState) {
            return "btn-secondary";
        }
        return {
            confirmed: "btn-info",
            checked_in: "o_appointment_btn_checked_in",
            no_show: "o_appointment_btn_no_show",
        }[state];
    }

    get showStatusButtons() {
        return this.isEventEditable && this.bookingState && this.bookingState !== "cancelled";
    }

    // same rule as the booking form: a checked-in booking cannot become a no show
    get showNoShow() {
        return this.bookingState !== "checked_in";
    }

    async setStatus(state) {
        if (state === this.bookingState) {
            return;
        }
        await this.orm.call(this.props.model.resModel, STATUS_ACTIONS[state], [[this.resId]]);
        this.props.close();
        await this.props.model.load();
    }
}

export class AppointmentCalendarCommonRenderer extends CalendarCommonRenderer {
    static components = {
        ...CalendarCommonRenderer.components,
        Popover: AppointmentBookingPopover,
    };

    // status colour of the calendar event (see appointment_type_views.scss)
    eventClassNames(info) {
        const classNames = super.eventClassNames(info);
        const state = this.props.model.records[info.event.id]?.rawRecord?.state;
        if (state) {
            classNames.push(`o_appointment_state_${state}`);
        }
        return classNames;
    }
}

export class AppointmentCalendarRenderer extends CalendarRenderer {
    static components = {
        ...CalendarRenderer.components,
        day: AppointmentCalendarCommonRenderer,
        week: AppointmentCalendarCommonRenderer,
        month: AppointmentCalendarCommonRenderer,
    };
}
