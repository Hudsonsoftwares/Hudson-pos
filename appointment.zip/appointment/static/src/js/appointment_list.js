/** @odoo-module **/

import { ListController } from "@web/views/list/list_controller";
import { listView } from "@web/views/list/list_view";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class AppointmentListController extends ListController {
    setup() {
        super.setup();
        this.actionService = useService("action");
    }

    onClickAddClosingDay() {
        const context = this.props.context;
        const additionalContext = {};
        if (context.appointment_closing_type) {
            additionalContext.default_closing_type = context.appointment_closing_type;
        } else if (context.default_appointment_type_id) {
            // bookings of one appointment type: close that appointment type
            additionalContext.default_appointment_type_ids = [context.default_appointment_type_id];
        }
        this.actionService.doAction("appointment.action_appointment_closing_day_new", {
            additionalContext,
        });
    }
}

export const appointmentListView = {
    ...listView,
    Controller: AppointmentListController,
    buttonTemplate: "appointment.ListView.Buttons",
};

registry.category("views").add("appointment_list", appointmentListView);
