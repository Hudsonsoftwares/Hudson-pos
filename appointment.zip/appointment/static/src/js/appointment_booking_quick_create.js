/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { serializeDateTime } from "@web/core/l10n/dates";
import { formView } from "@web/views/form/form_view";
import { FormController } from "@web/views/form/form_controller";
import { FormViewDialog } from "@web/views/view_dialogs/form_view_dialog";

// fields copied to the full booking form by "More Options"
const FULL_FORM_FIELDS = {
    subject: "char",
    appointment_type_id: "many2one",
    start_datetime: "datetime",
    end_datetime: "datetime",
    partner_id: "many2one",
    staff_user_id: "many2one",
    resource_ids: "many2many",
    state: "selection",
    guest_details: "char",
};

export class AppointmentBookingQuickCreateFormController extends FormController {
    setup() {
        super.setup();
        this.actionService = useService("action");
    }

    getFullBookingContext() {
        const data = this.model.root.data;
        const context = {};
        for (const [fieldName, type] of Object.entries(FULL_FORM_FIELDS)) {
            if (!(fieldName in data)) {
                continue;
            }
            let value = data[fieldName];
            if (type === "many2one") {
                value = Array.isArray(value) ? value[0] : value?.id;
            } else if (type === "many2many") {
                value = value ? value.records.map((record) => record.resId) : [];
            } else if (type === "datetime") {
                value = value && serializeDateTime(value);
            }
            context[`default_${fieldName}`] = value || false;
        }
        return context;
    }

    goToFullBooking() {
        return this.actionService.doAction("appointment.action_appointment_booking_full_form", {
            additionalContext: {
                ...this.props.context,
                ...this.getFullBookingContext(),
            },
        });
    }
}

registry.category("views").add("appointment_booking_quick_create_form", {
    ...formView,
    Controller: AppointmentBookingQuickCreateFormController,
});

export class AppointmentBookingQuickCreateDialog extends FormViewDialog {
    setup() {
        super.setup();
        this.viewProps.buttonDialogTemplate = "appointment.BookingQuickCreateButtons";
    }
}
