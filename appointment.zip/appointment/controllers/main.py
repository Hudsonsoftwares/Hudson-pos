import math
from datetime import datetime, timedelta
from urllib.parse import quote

# pyrefly: ignore [missing-import]
from odoo import http, _
from odoo.exceptions import ValidationError, UserError
# pyrefly: ignore [missing-import]
from odoo.http import request


def _get_resource_conflict_ids(resource, env):
    """Return all appointment.resource IDs that conflict with this resource,
    including linked resources and merged POS restaurant tables."""
    res_ids = set([resource.id])
    if hasattr(resource, 'linked_resource_ids'):
        res_ids |= set(resource.linked_resource_ids.ids)
    if 'restaurant.table' in env:
        tables = env['restaurant.table'].sudo().search([
            ('appointment_resource_id', 'in', list(res_ids))
        ])
        if tables:
            merged = tables.get_merged_and_linked_tables()
            res_ids |= set(merged.mapped('appointment_resource_id').ids)
    return res_ids


def _linked_resources_state(appointment_type, resource, start, end, periods_by_resource, overlap_party):
    """Linked resources of ``resource`` over [start, end) (combined with it when
    a group is too big for it alone). Closed ones are skipped; a booked one
    (not shareable) makes ``resource`` unavailable; free ones add their seats.

    :param overlap_party: function(linked) -> party size already booked on it
    :return: (available, extra capacity, free linked resources)
    """
    free = resource.browse()
    extra_capacity = 0
    for linked in resource.sudo().linked_resource_ids:
        if appointment_type.sudo()._period_overlaps(start, end, periods_by_resource.get(linked.id, [])):
            continue
        linked_overlap = overlap_party(linked)
        if linked_overlap > 0 and not (getattr(linked, 'shareable', False) or appointment_type.group_booking):
            return False, 0, resource.browse()
        extra_capacity += linked.capacity - linked_overlap
        free |= linked
    return True, extra_capacity, free


def _linking_resources_warning(appointment_type, resources, start, end):
    """Information shown before booking: every resource of ``resources`` has a
    resource linking to it (e.g. a projector whose linked resource is this
    conference room) that is booked or closed over [start, end). The booking
    stays possible. '' when there is nothing to warn about."""
    if not resources:
        return ''
    Booking = request.env['appointment.booking'].sudo()
    Closing = request.env['appointment.closing.day'].sudo()
    # same bookings as the slot availability: confirmed, or awaiting payment for less than 15 minutes
    time_limit = (datetime.utcnow() - timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
    lines = []
    for resource in resources:
        busy = []
        for linking in resource.sudo()._get_linking_resources():
            closed = Closing.search_count([
                ('closing_type', '=', 'resources'), ('resource_id', '=', linking.id),
                ('start_datetime', '<', end), ('end_datetime', '>', start)], limit=1)
            booked = sum(Booking.search([
                ('resource_ids', 'in', linking.ids),
                ('start_datetime', '<', end),
                ('end_datetime', '>', start),
                '|',
                    ('state', 'in', ['confirmed', 'checked_in']),
                    '&', ('state', '=', 'pending_payment'), ('create_date', '>=', time_limit),
            ]).mapped('party_size'))
            if closed or (booked > 0 and (not linking.shareable or booked >= linking.capacity)):
                busy.append(linking)
        if not busy:
            return ''
        lines += [_("%(linked)s (linked to %(resource)s) is not available at this time.",
                    linked=linking.name, resource=resource.name) for linking in busy]
    return ' '.join(dict.fromkeys(lines))


class AppointmentController(http.Controller):

    def _get_tz(self, appointment_type=None):
        import pytz
        tz_name = None
        if appointment_type and getattr(appointment_type, 'appointment_tz', False):
            tz_name = appointment_type.appointment_tz
        if not tz_name and appointment_type and getattr(appointment_type, 'company_id', False) and appointment_type.company_id.partner_id.tz:
            tz_name = appointment_type.company_id.partner_id.tz
        if not tz_name and hasattr(request, 'env') and request.env:
            tz_name = request.env.company.partner_id.tz or request.env.user.tz
        tz_name = tz_name or 'Asia/Calcutta'
        try:
            return pytz.timezone(tz_name)
        except Exception:
            return pytz.timezone('Asia/Calcutta')

    @http.route(['/book/<string:token>'], type='http', auth='public', website=True)
    def book_appointment(self, token, **kwargs):
        # Look up the invite by token (short_code or access_token)
        invite = request.env['appointment.invite'].sudo().search([
            '|', ('short_code', '=', token), ('access_token', '=', token)
        ], limit=1)
        
        if not invite or not invite.appointment_type_ids:
            return request.redirect('/?error=invalid_token')
            
        # If there's only one appointment type, redirect directly to it
        if len(invite.appointment_type_ids) == 1:
            return request.redirect(f'/appointment/{invite.appointment_type_ids[0].id}?invite_token={invite.access_token}')
            
        # If there are multiple, redirect to the first one for now
        # (Standard Odoo handles multiple by showing a list, but we'll simplify here since they usually just share one or can pick the first)
        return request.redirect(f'/appointment/{invite.appointment_type_ids[0].id}?invite_token={invite.access_token}')
        
    @http.route(['/appointment'], type='http', auth='public', website=True)
    def appointment_index(self, search=None, **kwargs):
        # website editors also see the unpublished types (flagged "Unpublished")
        is_editor = request.env.user.has_group('website.group_website_restricted_editor')
        domain = [('company_id', 'in', [False, (request.env.website.company_id or request.env.company).id])]
        if not is_editor:
            domain.append(('is_published', '=', True))
        search = (search or '').strip()
        if search:
            domain.append(('name', 'ilike', search))
        appointment_types = request.env['appointment.type'].sudo().search(domain, order='is_published desc, id')
        return request.render('appointment.appointment_type_index', {
            'appointment_types': appointment_types,
            'search': search,
            'is_editor': is_editor,
        })

    @http.route(['/appointment/<model("appointment.type"):appointment_type>'], type='http', auth='public', website=True)
    def appointment_preview(self, appointment_type, **kwargs):
        import calendar
        from datetime import date, datetime, timedelta
        
        preview = kwargs.get('preview') == 'True'
        invite_token = kwargs.get('invite_token')
        
        # Country Validation
        if appointment_type.country_ids:
            user_country_id = False
            if request.env.user and request.env.user.id != request.env.ref('base.public_user').id:
                user_country_id = request.env.user.partner_id.country_id.id
            elif hasattr(request, 'geoip') and request.geoip.get('country_code'):
                country = request.env['res.country'].sudo().search([('code', '=', request.geoip.country_code)], limit=1)
                if country:
                    user_country_id = country.id
            
            if user_country_id not in appointment_type.country_ids.ids:
                return request.render('appointment.appointment_invalid_country', {
                    'appointment_type': appointment_type
                })
        
        # Determine the selected date
        date_str = kwargs.get('date')
        if date_str:
            try:
                selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except ValueError:
                selected_date = date.today()
        else:
            selected_date = date.today()
            
        try:
            selected_party_size = int(kwargs.get('party_size', 1))
        except ValueError:
            selected_party_size = 1
            
        current_date = date.today()
        month, year = selected_date.month, selected_date.year
        
        # Calculate available days of week from backend configuration
        available_dows = set()
        
        custom_dows = set()
        if appointment_type.availability_ids:
            for avail in appointment_type.availability_ids:
                custom_dows.add(avail.day_of_week)
        if appointment_type.availability_ids:
            available_dows = custom_dows

        # Employee Schedule: a day is open when a staff member's working time
        # (incl. time off), within the availability rows, fits one appointment
        employee_open_dates = set()
        if appointment_type.employee_schedule:
            import pytz
            schedule_users = appointment_type.sudo().user_ids
            requested_staff = kwargs.get('staff_user_id')
            if requested_staff:
                try:
                    requested_staff = int(requested_staff)
                    if requested_staff in schedule_users.ids:
                        schedule_users = schedule_users.filtered(lambda u: u.id == requested_staff)
                except ValueError:
                    pass
            schedule_tz = self._get_tz(appointment_type)
            range_first_day = current_date - timedelta(days=1)
            range_last_day = current_date + timedelta(days=(appointment_type.max_schedule_days or 15) + 1)
            range_start_utc = schedule_tz.localize(datetime.combine(range_first_day, datetime.min.time())).astimezone(pytz.UTC).replace(tzinfo=None)
            range_end_utc = schedule_tz.localize(datetime.combine(range_last_day, datetime.min.time())).astimezone(pytz.UTC).replace(tzinfo=None)
            windows_by_user = appointment_type.sudo()._get_employee_available_windows(
                schedule_users, range_start_utc, range_end_utc)
            needed = timedelta(hours=appointment_type.appointment_duration)
            for windows in windows_by_user.values():
                for window_start, window_end in windows:
                    local_start = pytz.UTC.localize(window_start).astimezone(schedule_tz).replace(tzinfo=None)
                    local_end = pytz.UTC.localize(window_end).astimezone(schedule_tz).replace(tzinfo=None)
                    day = local_start.date()
                    while day <= local_end.date():
                        day_start = max(local_start, datetime.combine(day, datetime.min.time()))
                        day_end = min(local_end, datetime.combine(day + timedelta(days=1), datetime.min.time()))
                        if day_end - day_start >= needed:
                            employee_open_dates.add(day)
                        day += timedelta(days=1)

        # Flexible schedule: the dates on which a slot starts
        flexible_dates = set()
        if appointment_type.schedule_type == 'flexible':
            import pytz
            flexible_tz = self._get_tz(appointment_type)
            utc_now_naive = datetime.utcnow()
            for period_start, period_end in appointment_type.sudo()._get_flexible_periods():
                if period_start > utc_now_naive:
                    flexible_dates.add(pytz.UTC.localize(period_start).astimezone(flexible_tz).date())

        def _is_open_day(d):
            if appointment_type.schedule_type == 'flexible':
                return d in flexible_dates
            if appointment_type.employee_schedule:
                return d in employee_open_dates
            if appointment_type.availability_ids:
                return str(d.weekday()) in available_dows
            return True
                
        # Closing days: the whole type, or single users / resources
        type_periods, periods_by_user, periods_by_resource = appointment_type.sudo()._get_closing_periods()
        # a date is closed when the closing periods cover all its opening hours,
        # for the whole type or for every bookable user / resource
        if appointment_type.booking_target == 'resources':
            closing_targets, periods_by_target = appointment_type.sudo().resource_ids, periods_by_resource
        else:
            closing_targets, periods_by_target = appointment_type.sudo().user_ids, periods_by_user
        requested_target = kwargs.get('staff_user_id')
        if requested_target:
            try:
                requested_target = int(requested_target)
                if requested_target in closing_targets.ids:
                    closing_targets = closing_targets.filtered(lambda t: t.id == requested_target)
            except ValueError:
                pass
        closed_dates = set()
        check_day = current_date
        last_check_day = current_date + timedelta(days=appointment_type.max_schedule_days or 15)
        while check_day <= last_check_day:
            if appointment_type.sudo()._is_day_closed(check_day, type_periods) or (
                    closing_targets and all(
                        appointment_type.sudo()._is_day_closed(check_day, type_periods + periods_by_target.get(target.id, []))
                        for target in closing_targets)):
                closed_dates.add(check_day)
            check_day += timedelta(days=1)

        # Without an explicit date, open on the first bookable day instead of today
        if not date_str and (appointment_type.availability_ids or appointment_type.employee_schedule
                             or appointment_type.schedule_type == 'flexible'):
            last_date = current_date + timedelta(days=appointment_type.max_schedule_days or 15)
            first_bookable = current_date
            while first_bookable <= last_date and (not _is_open_day(first_bookable) or first_bookable in closed_dates):
                first_bookable += timedelta(days=1)
            if first_bookable <= last_date:
                selected_date = first_bookable
                month, year = selected_date.month, selected_date.year

        cal = calendar.Calendar(firstweekday=6) # Sunday first
        month_days = cal.monthdatescalendar(year, month)
        
        max_date = current_date + timedelta(days=appointment_type.max_schedule_days or 15)
        
        month_grid = []
        for week in month_days:
            week_data = []
            for d in week:
                is_available = _is_open_day(d)
                is_past = d < current_date
                is_closed = d in closed_dates
                is_too_far = d > max_date
                
                week_data.append({
                    'date_str': d.strftime('%Y-%m-%d'),
                    'day': d.day,
                    'is_current_month': d.month == month,
                    'is_today': d == current_date,
                    'is_selected': d == selected_date,
                    'is_available': is_available and not is_past and not is_closed and not is_too_far,
                    'is_past': is_past or is_too_far,
                    'is_weekend': d.isoweekday() in [6, 7] # Sat or Sun
                })
            month_grid.append(week_data)
            
        max_date = current_date + timedelta(days=appointment_type.max_schedule_days or 15)
        
        # Generate time slots for the selected date
        slots = []
        if selected_date not in closed_dates and current_date <= selected_date <= max_date:
            selected_dow_str = str(selected_date.weekday())
            
            # Fetch existing bookings for the selected date to filter slots
            import pytz
            from datetime import datetime as dt, time as dt_time, timedelta as td
            tz = self._get_tz(appointment_type)
            
            selected_day_start_local = tz.localize(dt.combine(selected_date, dt_time.min))
            selected_day_end_local = tz.localize(dt.combine(selected_date, dt_time.max))
            start_utc = selected_day_start_local.astimezone(pytz.UTC).replace(tzinfo=None)
            end_utc = selected_day_end_local.astimezone(pytz.UTC).replace(tzinfo=None)
            
            search_start = start_utc - td(hours=appointment_type.appointment_duration)
            search_end = end_utc + td(hours=24)
            
            # 15-minute hold logic: only pending payments from the last 15 minutes block slots
            time_limit = (dt.utcnow() - td(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
            
            domain = [
                ('start_datetime', '<=', search_end),
                ('end_datetime', '>=', search_start),
                '|',
                    ('state', 'in', ['confirmed', 'checked_in']),
                    '&', ('state', '=', 'pending_payment'), ('create_date', '>=', time_limit)
            ]
            existing_bookings = request.env['appointment.booking'].sudo().search(domain)
            
            # Fetch staff user if passed
            staff_user_id = kwargs.get('staff_user_id')
            if staff_user_id:
                try:
                    staff_user_id = int(staff_user_id)
                    if staff_user_id not in appointment_type.sudo().user_ids.ids:
                        staff_user_id = False
                except ValueError:
                    staff_user_id = False
            
            utc_now = dt.utcnow()

            # Staff calendar events (incl. Google Calendar) block their time
            busy_by_user = {}
            if appointment_type.booking_target == 'users':
                busy_by_user = appointment_type.sudo()._get_busy_intervals_by_user(
                    appointment_type.sudo().user_ids, search_start, search_end)

            day_avails = []
            employee_windows = {}
            if appointment_type.employee_schedule:
                # free periods of each staff member on the selected day (working
                # schedule minus time off, within the availability rows)
                schedule_users = appointment_type.sudo().user_ids
                if staff_user_id:
                    schedule_users = schedule_users.filtered(lambda u: u.id == staff_user_id)
                day_start_naive = dt.combine(selected_date, dt_time.min)
                day_end_utc = tz.localize(day_start_naive + td(days=1)).astimezone(pytz.UTC).replace(tzinfo=None)
                employee_windows = appointment_type.sudo()._get_employee_available_windows(
                    schedule_users, start_utc, day_end_utc)
                if appointment_type.availability_ids:
                    # keep the slot grid of the availability rows
                    day_avails = appointment_type.availability_ids.filtered(lambda a: a.day_of_week == selected_dow_str)
                else:
                    spans = []
                    for windows in employee_windows.values():
                        for window_start, window_end in windows:
                            local_start = pytz.UTC.localize(window_start).astimezone(tz).replace(tzinfo=None)
                            local_end = pytz.UTC.localize(window_end).astimezone(tz).replace(tzinfo=None)
                            from_h = max(0.0, (local_start - day_start_naive).total_seconds() / 3600)
                            to_h = min(24.0, (local_end - day_start_naive).total_seconds() / 3600)
                            if to_h > from_h:
                                spans.append([from_h, to_h])
                    merged_spans = []
                    for span in sorted(spans):
                        if merged_spans and span[0] <= merged_spans[-1][1]:
                            merged_spans[-1][1] = max(merged_spans[-1][1], span[1])
                        else:
                            merged_spans.append(span)
                    # start slots on the slot-interval grid
                    step_h = appointment_type.slot_interval if appointment_type.slot_interval > 0 else 0.5
                    for from_h, to_h in merged_spans:
                        grid_from_h = math.ceil(round(from_h / step_h, 6)) * step_h
                        if grid_from_h < to_h:
                            day_avails.append(type('Avail', (object,), {'start_time': grid_from_h, 'end_time': to_h}))
            else:
                if appointment_type.availability_ids:
                    day_avails = appointment_type.availability_ids.filtered(lambda a: a.day_of_week == selected_dow_str)
                    
            if appointment_type.schedule_type == 'flexible':
                day_avails = []
                day_start_naive = dt.combine(selected_date, dt_time.min)
                for slot in appointment_type.sudo().flexible_slot_ids:
                    period_start, period_end = slot._get_period_utc()
                    local_start = pytz.UTC.localize(period_start).astimezone(tz).replace(tzinfo=None)
                    if local_start.date() != selected_date:
                        continue
                    day_avails.append(type('Avail', (object,), {
                        'start_time': (local_start - day_start_naive).total_seconds() / 3600,
                        'end_time': (local_start - day_start_naive).total_seconds() / 3600 + 1 / 60,
                        'slot_end_utc': period_end,
                        'single': True,
                        'label': request.env._('All day') if slot.allday else None,
                    }))

            if day_avails:
                for avail in day_avails:
                    start_h = int(avail.start_time)
                    start_m = int(round((avail.start_time - start_h) * 60))
                    end_h = int(avail.end_time)
                    end_m = int(round((avail.end_time - end_h) * 60))
                    
                    # Generate slots every 30 mins
                    current_h, current_m = start_h, start_m
                    while current_h < end_h or (current_h == end_h and current_m < end_m):
                        time_str = f"{current_h:02d}:{current_m:02d}"
                        ampm = "am" if current_h < 12 else "pm"
                        display_h = current_h if current_h <= 12 else current_h - 12
                        if display_h == 0: display_h = 12
                        display_str = f"{display_h}:{current_m:02d} {ampm}"
                        
                        # Check availability
                        local_slot_start = tz.localize(dt.combine(selected_date, dt_time(current_h, current_m)))
                        slot_start_utc = local_slot_start.astimezone(pytz.UTC).replace(tzinfo=None)
                        # a flexible slot lasts until its own end
                        slot_end_utc = getattr(avail, 'slot_end_utc', None) or (
                            slot_start_utc + td(hours=appointment_type.appointment_duration))
                        if getattr(avail, 'label', None):
                            display_str = avail.label

                        available_users_for_slot = []
                        if slot_start_utc <= utc_now:
                            is_available = False
                        else:
                            if appointment_type.booking_target == 'users':
                                users_to_check = appointment_type.sudo().user_ids
                                if staff_user_id:
                                    users_to_check = users_to_check.filtered(lambda u: u.id == staff_user_id)
                                    
                                for u in users_to_check:
                                    u_avail = True
                                    if appointment_type.sudo()._period_overlaps(slot_start_utc, slot_end_utc, type_periods + periods_by_user.get(u.id, [])):
                                        u_avail = False
                                    if appointment_type.employee_schedule and not any(
                                            window_start <= slot_start_utc and slot_end_utc <= window_end
                                            for window_start, window_end in employee_windows.get(u.id, [])):
                                        # the whole appointment must fit in the staff member's free period
                                        u_avail = False

                                    if u_avail and any(b_start < slot_end_utc and b_stop > slot_start_utc
                                                       for b_start, b_stop in busy_by_user.get(u.id, [])):
                                        u_avail = False

                                    if u_avail:
                                        # Check user overlapping bookings
                                        user_bookings = existing_bookings.filtered(lambda b: b.staff_user_id.id == u.id)
                                        overlapping_party_size = sum(b.party_size for b in user_bookings if b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc)
                                        
                                        user_cap = u.capacity if hasattr(u, 'capacity') else appointment_type.capacity
                                        if overlapping_party_size + selected_party_size > user_cap:
                                            if not appointment_type.group_booking:
                                                u_avail = False
                                            elif overlapping_party_size + selected_party_size > user_cap:
                                                u_avail = False
                                                
                                        if u_avail and hasattr(u, 'capacity') and selected_party_size > u.capacity:
                                            u_avail = False
                                                
                                    if u_avail:
                                        available_users_for_slot.append(u)
                                        
                                is_available = len(available_users_for_slot) > 0
                            else:
                                resources_to_check = appointment_type.sudo().resource_ids
                                if staff_user_id:
                                    resources_to_check = resources_to_check.filtered(lambda r: r.id == staff_user_id)
                                    
                                for r in resources_to_check:
                                    r_avail = True
                                    if appointment_type.sudo()._period_overlaps(slot_start_utc, slot_end_utc, type_periods + periods_by_resource.get(r.id, [])):
                                        r_avail = False
                                    r_conflicts = _get_resource_conflict_ids(r, request.env)
                                    resource_bookings = existing_bookings.filtered(lambda b: bool(set(b.resource_ids.ids) & r_conflicts))
                                    overlapping_party_size = sum(b.party_size for b in resource_bookings if b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc)
                                    
                                    avail_cap = 0
                                    if overlapping_party_size > 0 and not (getattr(r, 'shareable', False) or appointment_type.group_booking):
                                        r_avail = False
                                    else:
                                        avail_cap = r.capacity - overlapping_party_size
                                        
                                    if r_avail:
                                        linked_ok, linked_cap, _free = _linked_resources_state(
                                            appointment_type, r, slot_start_utc, slot_end_utc, periods_by_resource,
                                            lambda linked: sum(b.party_size for b in existing_bookings
                                                               if linked.id in b.resource_ids.ids
                                                               and b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc))
                                        if linked_ok:
                                            avail_cap += linked_cap
                                        else:
                                            r_avail = False
                                            
                                    if r_avail and selected_party_size > avail_cap:
                                        r_avail = False
                                        
                                    if r_avail:
                                        available_users_for_slot.append(r)
                                        
                                is_available = len(available_users_for_slot) > 0
                        
                        slots.append({
                            'time': display_str,
                            'val': time_str,
                            'available': is_available,
                            'available_users': [{'id': u.id, 'name': u.name, 'capacity': getattr(u, 'capacity', 1)} for u in available_users_for_slot]
                        })
                        
                        if getattr(avail, 'single', False):
                            break
                        interval_mins = int(round(appointment_type.slot_interval * 60))
                        if interval_mins <= 0:
                            interval_mins = 30 # fallback
                            
                        current_m += interval_mins
                        while current_m >= 60:
                            current_m -= 60
                            current_h += 1
            elif (not appointment_type.availability_ids and not appointment_type.employee_schedule
                  and appointment_type.schedule_type != 'flexible'):
                # Default slots if no availability configured: 9am to 12pm, 2pm to 5pm
                default_times = []
                interval_mins = int(round(appointment_type.slot_interval * 60))
                if interval_mins <= 0: interval_mins = 60
                
                for period_start, period_end in [(9, 17)]:
                    cur_h, cur_m = period_start, 0
                    while cur_h < period_end or (cur_h == period_end and cur_m == 0):
                        ampm = "am" if cur_h < 12 else "pm"
                        display_h = cur_h if cur_h <= 12 else cur_h - 12
                        if display_h == 0: display_h = 12
                        display_str = f"{display_h}:{cur_m:02d} {ampm}"
                        time_str = f"{cur_h:02d}:{cur_m:02d}"
                        default_times.append((display_str, time_str, cur_h, cur_m))
                        
                        cur_m += interval_mins
                        while cur_m >= 60:
                            cur_m -= 60
                            cur_h += 1
                            
                for display_str, time_str, h, m in default_times:
                    local_slot_start = tz.localize(dt.combine(selected_date, dt_time(h, m)))
                    slot_start_utc = local_slot_start.astimezone(pytz.UTC).replace(tzinfo=None)
                    slot_end_utc = slot_start_utc + td(hours=appointment_type.appointment_duration)
                    
                    available_users_for_slot = []
                    
                    if appointment_type.booking_target == 'users':
                        users_to_check = appointment_type.sudo().user_ids
                        if kwargs.get('staff_user_id'):
                            try:
                                staff_user_id = int(kwargs.get('staff_user_id'))
                                users_to_check = users_to_check.filtered(lambda u: u.id == staff_user_id)
                            except ValueError:
                                pass
                                
                        for u in users_to_check:
                            user_bookings = existing_bookings.filtered(lambda b: b.staff_user_id.id == u.id)
                            overlapping_party_size = sum(b.party_size for b in user_bookings if b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc)
                            
                            u_avail = True
                            if appointment_type.sudo()._period_overlaps(slot_start_utc, slot_end_utc, type_periods + periods_by_user.get(u.id, [])):
                                u_avail = False
                            if any(b_start < slot_end_utc and b_stop > slot_start_utc
                                   for b_start, b_stop in busy_by_user.get(u.id, [])):
                                u_avail = False
                            if overlapping_party_size + selected_party_size > (u.capacity if hasattr(u, 'capacity') else appointment_type.capacity):
                                if not appointment_type.group_booking:
                                    u_avail = False
                                elif overlapping_party_size + selected_party_size > (u.capacity if hasattr(u, 'capacity') else appointment_type.capacity):
                                    u_avail = False
                                    
                            if u_avail and hasattr(u, 'capacity') and selected_party_size > u.capacity:
                                u_avail = False
                                
                            if u_avail:
                                available_users_for_slot.append(u)
                                
                        is_available = len(available_users_for_slot) > 0
                    else:
                        resources_to_check = appointment_type.sudo().resource_ids
                        if kwargs.get('staff_user_id'):
                            try:
                                staff_user_id = int(kwargs.get('staff_user_id'))
                                resources_to_check = resources_to_check.filtered(lambda r: r.id == staff_user_id)
                            except ValueError:
                                pass
                                
                        for r in resources_to_check:
                            r_conflicts = _get_resource_conflict_ids(r, request.env)
                            resource_bookings = existing_bookings.filtered(lambda b: bool(set(b.resource_ids.ids) & r_conflicts))
                            overlapping_party_size = sum(b.party_size for b in resource_bookings if b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc)
                            
                            r_avail = True
                            if appointment_type.sudo()._period_overlaps(slot_start_utc, slot_end_utc, type_periods + periods_by_resource.get(r.id, [])):
                                r_avail = False
                            avail_cap = 0
                            if overlapping_party_size > 0 and not (getattr(r, 'shareable', False) or appointment_type.group_booking):
                                r_avail = False
                            else:
                                avail_cap = r.capacity - overlapping_party_size
                                
                            if r_avail:
                                linked_ok, linked_cap, _free = _linked_resources_state(
                                    appointment_type, r, slot_start_utc, slot_end_utc, periods_by_resource,
                                    lambda linked: sum(b.party_size for b in existing_bookings
                                                       if linked.id in b.resource_ids.ids
                                                       and b.start_datetime < slot_end_utc and b.end_datetime > slot_start_utc))
                                if linked_ok:
                                    avail_cap += linked_cap
                                else:
                                    r_avail = False
                                    
                            if r_avail and selected_party_size > avail_cap:
                                r_avail = False
                                
                            if r_avail:
                                available_users_for_slot.append(r)
                                
                        is_available = len(available_users_for_slot) > 0

                    if slot_start_utc <= utc_now:
                        is_available = False
                            
                    slots.append({
                        'time': display_str,
                        'val': time_str,
                        'available': is_available,
                        'available_users': [{'id': u.id, 'name': u.name, 'capacity': getattr(u, 'capacity', 1)} for u in available_users_for_slot]
                    })
            
        # Available party sizes
        if appointment_type.booking_target == 'resources' and appointment_type.resource_ids:
            # If a specific resource is selected, use its capacity. Otherwise use the max of all resources.
            requested_id = kwargs.get('staff_user_id')
            if requested_id:
                try:
                    requested_id = int(requested_id)
                    res = appointment_type.resource_ids.filtered(lambda r: r.id == requested_id)
                    max_cap = res.capacity if res else max(appointment_type.resource_ids.mapped('capacity'))
                except ValueError:
                    max_cap = max(appointment_type.resource_ids.mapped('capacity'))
            else:
                max_cap = max(appointment_type.resource_ids.mapped('capacity'))
            party_sizes = list(range(1, (max_cap or 1) + 1))
        else:
            party_sizes = list(range(1, (appointment_type.capacity or 1) + 1))
        
        # Check for existing booking
        existing_booking = False
        existing_booking_label = ''
        if request.env.user and request.env.user.id != request.env.ref('base.public_user').id:
            # upcoming (start_datetime is naive UTC) and not cancelled
            existing_booking = request.env['appointment.booking'].sudo().search([
                ('appointment_type_id', '=', appointment_type.id),
                ('partner_id', '=', request.env.user.partner_id.id),
                ('state', '!=', 'cancelled'),
                ('start_datetime', '>=', datetime.utcnow())
            ], order='start_datetime asc', limit=1)
            if existing_booking:
                # shown in the appointment's timezone, like the slots
                import pytz
                try:
                    booking_tz = self._get_tz(appointment_type)
                except pytz.UnknownTimeZoneError:
                    booking_tz = pytz.UTC
                existing_booking_label = pytz.UTC.localize(existing_booking.start_datetime).astimezone(
                    booking_tz).strftime('%a, %d %b, %Y, %I:%M %p')
            
        if month == 12:
            next_month = 1
            next_year = year + 1
        else:
            next_month = month + 1
            next_year = year
            
        if month == 1:
            prev_month = 12
            prev_year = year - 1
        else:
            prev_month = month - 1
            prev_year = year
            
        next_month_date = date(next_year, next_month, 1).strftime('%Y-%m-%d')
        prev_month_date = date(prev_year, prev_month, 1).strftime('%Y-%m-%d')
        
        values = {
            'appointment_type': appointment_type,
            'main_object': appointment_type,
            'preview': preview,
            'state': kwargs.get('state'),
            'month_grid': month_grid,
            'slots': slots,
            'party_sizes': party_sizes,
            'month_name': calendar.month_name[month],
            'year': year,
            'selected_date': selected_date.strftime('%Y-%m-%d'),
            'selected_party_size': selected_party_size,
            'prev_month_date': prev_month_date,
            'next_month_date': next_month_date,
            'existing_booking': existing_booking,
            'existing_booking_label': existing_booking_label,
            'invite_token': invite_token,
            'staff_user_id': kwargs.get('staff_user_id'),
            'users_possible': (
                appointment_type.sudo().user_ids.filtered(lambda u: getattr(u, 'capacity', 1) >= selected_party_size)
                if appointment_type.booking_target == 'users'
                else appointment_type.sudo().resource_ids.filtered(lambda r: r.capacity + sum(r.linked_resource_ids.mapped('capacity')) >= selected_party_size)
            ),
            'assign_method': appointment_type.assign_method,
            'schedule_based_on': appointment_type.schedule_based_on,
            'has_multiple_targets': appointment_type.has_multiple_targets,
        }
        
        return request.render('appointment.appointment_preview', values)

    @http.route(['/appointment/<model("appointment.type"):appointment_type>/info'], type='http', auth='public', website=True, methods=['GET', 'POST'])
    def appointment_info(self, appointment_type, **kwargs):
        from datetime import datetime
        
        date_str = kwargs.get('date')
        time_str = kwargs.get('time')
        party_size = kwargs.get('party_size', 1)
        
        if not date_str or not time_str:
            return request.redirect(f'/appointment/{appointment_type.id}?error=missing_datetime')
            
        try:
            start_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
        except ValueError:
            return request.redirect(f'/appointment/{appointment_type.id}?error=invalid_datetime')
            
        values = {
            'appointment_type': appointment_type,
            'selected_date': date_str,
            'selected_time': time_str,
            'party_size': party_size,
            'start_dt': start_dt,
            'user': request.env.user if request.env.user.id != request.env.ref('base.public_user').id else None,
            'invite_token': kwargs.get('invite_token'),
            'linked_warning': self._get_linked_resources_warning(appointment_type, start_dt, kwargs.get('staff_user_id')),
        }
        return request.render('appointment.appointment_info', values)

    def _get_linked_resources_warning(self, appointment_type, start_dt, requested_resource_id=None):
        """Warning for the details page: a resource linked to the resource(s) of
        this slot is not available (information only, the booking stays possible)."""
        appointment_type = appointment_type.sudo()
        if appointment_type.booking_target != 'resources' or not appointment_type.resource_ids:
            return ''
        try:
            import pytz
            tz = self._get_tz(appointment_type)
            start_utc = tz.localize(start_dt).astimezone(pytz.UTC).replace(tzinfo=None)
        except Exception:  # noqa: BLE001 - a warning must never break the booking page
            return ''
        end_utc = start_utc + timedelta(hours=appointment_type.appointment_duration)
        if appointment_type.schedule_type == 'flexible':
            period = next((p for p in appointment_type._get_flexible_periods() if p[0] == start_utc), None)
            if period:
                end_utc = period[1]
        resources = appointment_type.resource_ids
        if requested_resource_id:
            try:
                requested = resources.filtered(lambda r: r.id == int(requested_resource_id))
            except ValueError:
                requested = resources.browse()
            resources = requested or resources
        return _linking_resources_warning(appointment_type, resources, start_utc, end_utc)

    @http.route(['/appointment/<model("appointment.type"):appointment_type>/submit'], type='http', auth='public', website=True, methods=['POST'])
    def appointment_submit(self, appointment_type, **kwargs):
        from datetime import datetime, timedelta
        
        date_str = kwargs.get('date')
        time_str = kwargs.get('time')
        name = kwargs.get('name')
        email = kwargs.get('email')
        phone = kwargs.get('phone')
        party_size = kwargs.get('party_size', 1)
        
        if not date_str or not time_str or not name or not email:
            return request.redirect(f'/appointment/{appointment_type.id}?error=missing_fields')
            
        try:
            start_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
            import pytz
            tz = self._get_tz(appointment_type)
            start_dt_local = tz.localize(start_dt)
            start_dt_utc = start_dt_local.astimezone(pytz.UTC).replace(tzinfo=None)
            end_dt_utc = start_dt_utc + timedelta(hours=appointment_type.appointment_duration)
        except ValueError:
            return request.redirect(f'/appointment/{appointment_type.id}?error=invalid_datetime')

        booking_duration = appointment_type.appointment_duration
        if appointment_type.schedule_type == 'flexible':
            slot_period = next((period for period in appointment_type.sudo()._get_flexible_periods()
                                if period[0] == start_dt_utc), None)
            if not slot_period:
                return request.redirect(f'/appointment/{appointment_type.id}?error=invalid_datetime')
            end_dt_utc = slot_period[1]
            booking_duration = (end_dt_utc - start_dt_utc).total_seconds() / 3600

        type_periods, periods_by_user, periods_by_resource = appointment_type.sudo()._get_closing_periods()
        if appointment_type.sudo()._period_overlaps(start_dt_utc, end_dt_utc, type_periods):
            return request.redirect(f'/appointment/{appointment_type.id}?error=closed_day')
            
        # the phone comes from the type's "Phone Number" question, if any
        if not phone:
            for phone_question in appointment_type.sudo().question_ids.filtered(lambda q: q.question_type == 'phone'):
                answer = (kwargs.get(f'question_{phone_question.id}') or '').strip()
                if answer:
                    phone = answer
                    break

        # Get or create partner
        company = appointment_type.sudo().company_id or request.env.website.company_id or request.env.company
        Partner = request.env['res.partner'].sudo()
        # a contact restricted to another company can't be used on this company's documents
        # Never match company partner (id 1 or company.partner_id.id) as the guest!
        excluded_ids = [1]
        if company and company.partner_id:
            excluded_ids.append(company.partner_id.id)

        partner = Partner.search([
            ('id', 'not in', excluded_ids),
            ('email', '=', email),
            ('company_id', 'in', [False, company.id])
        ], limit=1)
        if not partner and phone:
            partner = Partner.search([
                ('id', 'not in', excluded_ids),
                ('phone', '=', phone),
                ('company_id', 'in', [False, company.id])
            ], limit=1)
        if not partner:
            partner = Partner.create({
                'name': name,
                'email': email,
                'phone': phone,
            })
        else:
            p_vals = {}
            if phone and (not partner.phone or partner.phone != phone):
                p_vals['phone'] = phone
            if name and partner.id not in excluded_ids:
                p_vals['name'] = name
            if p_vals:
                partner.write(p_vals)
            
        # Extract custom questions
        answers_dict = {}
        for key, val in kwargs.items():
            if key.startswith('question_') and val:
                try:
                    q_id_str = key.replace('question_', '').split('_')[0]
                    q_id = int(q_id_str)
                    if q_id not in answers_dict:
                        answers_dict[q_id] = []
                    answers_dict[q_id].append(str(val))
                except ValueError:
                    continue
                    
        answer_vals_list = []
        for q_id, vals in answers_dict.items():
            q = request.env['appointment.question'].sudo().browse(q_id)
            if q.exists():
                answer_vals = {
                    'question_id': q.id,
                    'value_text': ', '.join(vals)
                }
                if q.question_type in ('select', 'radio', 'checkbox'):
                    chosen = q.answer_ids.filtered(lambda a: a.name in vals)
                    if chosen:
                        answer_vals['value_answer_ids'] = [(6, 0, chosen.ids)]
                answer_vals_list.append((0, 0, answer_vals))
            
        booking_vals = {
            'appointment_type_id': appointment_type.id,
            'start_datetime': start_dt_utc,
            'end_datetime': end_dt_utc,
            'duration': booking_duration,
            'state': 'confirmed',
            'partner_id': partner.id,
            'customer_name': name,
            'customer_phone': phone,
            'customer_email': email,
            'party_size': int(party_size),
            'answer_ids': answer_vals_list,
            'name': f"{appointment_type.name} - {start_dt.strftime('%b %d, %Y %H:%M')}"
        }
        
        if appointment_type.booking_target == 'resources' and appointment_type.resource_ids:
            requested_target_id = kwargs.get('staff_user_id')
            if requested_target_id:
                try:
                    requested_target_id = int(requested_target_id)
                except ValueError:
                    requested_target_id = False
                    
            assigned_resources = request.env['appointment.resource'].sudo()
            needed_capacity = int(party_size)
            
            resources_to_check = appointment_type.resource_ids
            if requested_target_id:
                requested_resource = resources_to_check.filtered(lambda r: r.id == requested_target_id)
                if requested_resource:
                    resources_to_check = requested_resource
                    
            # BATCH QUERY BOOKINGS
            time_limit = (datetime.utcnow() - timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
            all_r_ids = set(resources_to_check.ids)
            for r in resources_to_check:
                all_r_ids |= _get_resource_conflict_ids(r, request.env)

            all_bookings = request.env['appointment.booking'].sudo().search([
                ('resource_ids', 'in', list(all_r_ids)),
                ('start_datetime', '<', end_dt_utc),
                ('end_datetime', '>', start_dt_utc),
                '|',
                    ('state', 'in', ['confirmed', 'checked_in']),
                    '&', ('state', '=', 'pending_payment'), ('create_date', '>=', time_limit)
            ])

            bookings_by_resource = {}
            for r in resources_to_check:
                r_conflicts = _get_resource_conflict_ids(r, request.env)
                bookings_by_resource[r.id] = all_bookings.filtered(lambda b: bool(set(b.resource_ids.ids) & r_conflicts))
                    
            # Automatic assignment picks the best fit: the free resource leaving
            # the fewest empty seats for this party (a 2-seat table for 2 people
            # rather than a 3-seat one); a resource combined with its linked
            # resource only when no single resource fits. Ties keep the
            # resources' order. A resource chosen by the customer is kept as is.
            single_candidates = []  # (empty seats, position, resources)
            linked_candidates = []
            for position, resource in enumerate(resources_to_check):
                resource_bookings = bookings_by_resource.get(resource.id, request.env['appointment.booking'].sudo())
                r_avail = True
                if appointment_type.sudo()._period_overlaps(start_dt_utc, end_dt_utc, periods_by_resource.get(resource.id, [])):
                    r_avail = False
                overlapping_party_size = sum(b.party_size for b in resource_bookings)

                avail_cap = 0
                if overlapping_party_size > 0 and not (getattr(resource, 'shareable', False) or appointment_type.group_booking):
                    r_avail = False
                else:
                    avail_cap = resource.capacity - overlapping_party_size
                own_cap = avail_cap

                linked_free = resource.browse()
                if r_avail:
                    linked_ok, linked_cap, linked_free = _linked_resources_state(
                        appointment_type, resource, start_dt_utc, end_dt_utc, periods_by_resource,
                        lambda linked: sum(b.party_size for b in bookings_by_resource.get(linked.id, [])))
                    if linked_ok:
                        avail_cap += linked_cap
                    else:
                        r_avail = False

                if r_avail and int(party_size) > avail_cap:
                    r_avail = False

                if not r_avail:
                    continue
                if requested_target_id:
                    # resource chosen by the customer: unchanged behaviour
                    single_candidates.append((0, position, resource | linked_free))
                elif own_cap >= needed_capacity:
                    single_candidates.append((own_cap - needed_capacity, position, resource))
                else:
                    linked_candidates.append((avail_cap - needed_capacity, position, resource | linked_free))

            candidates = single_candidates or linked_candidates
            if candidates:
                assigned_resources |= min(candidates, key=lambda candidate: candidate[:2])[2]
            if assigned_resources:
                booking_vals['resource_ids'] = [(6, 0, assigned_resources.ids)]
            else:
                return request.redirect(f'/appointment/{appointment_type.id}?error=no_resource_available')
        elif appointment_type.booking_target == 'users' and appointment_type.sudo().user_ids:
            requested_staff_id = kwargs.get('staff_user_id')
            if requested_staff_id:
                try:
                    requested_staff_id = int(requested_staff_id)
                except ValueError:
                    requested_staff_id = False
                    
            time_limit = (datetime.utcnow() - timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
            existing_user_bookings = request.env['appointment.booking'].sudo().search([
                ('appointment_type_id.booking_target', '=', 'users'),
                ('start_datetime', '<', end_dt_utc),
                ('end_datetime', '>', start_dt_utc),
                '|',
                    ('state', 'in', ['confirmed', 'checked_in']),
                    '&', ('state', '=', 'pending_payment'), ('create_date', '>=', time_limit)
            ])
            
            users_to_check = appointment_type.sudo().user_ids

            # Employee Schedule: same free periods as the slot page
            employee_windows = {}
            if appointment_type.employee_schedule:
                employee_windows = appointment_type.sudo()._get_employee_available_windows(
                    users_to_check, start_dt_utc, end_dt_utc)

            busy_by_user = appointment_type.sudo()._get_busy_intervals_by_user(
                users_to_check, start_dt_utc, end_dt_utc)

            available_users = []
            for u in users_to_check:
                u_avail = True
                if busy_by_user.get(u.id) or appointment_type.sudo()._period_overlaps(start_dt_utc, end_dt_utc, periods_by_user.get(u.id, [])):
                    u_avail = False
                if appointment_type.employee_schedule and not any(
                        window_start <= start_dt_utc and end_dt_utc <= window_end
                        for window_start, window_end in employee_windows.get(u.id, [])):
                    u_avail = False

                if u_avail:
                    user_bookings = existing_user_bookings.filtered(lambda b: b.staff_user_id.id == u.id)
                    overlapping_party_size = sum(b.party_size for b in user_bookings)
                    
                    user_cap = u.capacity if hasattr(u, 'capacity') else appointment_type.capacity
                    if overlapping_party_size + int(party_size) > user_cap:
                        if not appointment_type.group_booking:
                            u_avail = False
                        elif overlapping_party_size + int(party_size) > user_cap:
                            u_avail = False
                            
                    if u_avail and hasattr(u, 'capacity') and int(party_size) > u.capacity:
                        u_avail = False
                        
                if u_avail:
                    available_users.append(u.id)
                    
            if not available_users:
                return request.redirect(f'/appointment/{appointment_type.id}?error=no_user_available')
                
            if requested_staff_id and appointment_type.assign_method == 'customer':
                if requested_staff_id in available_users:
                    booking_vals['staff_user_id'] = requested_staff_id
                else:
                    return request.redirect(f'/appointment/{appointment_type.id}?error=user_unavailable')
            else:
                import random
                booking_vals['staff_user_id'] = random.choice(available_users)
                
        if appointment_type.has_payment_step and appointment_type.product_id:
            booking_vals['state'] = 'pending_payment'
            
        try:
            booking = request.env['appointment.booking'].sudo().create(booking_vals)
        except (ValidationError, UserError) as err:
            err_msg = str(err.args[0] if err.args else err)
            return request.redirect(f'/appointment/{appointment_type.id}?error=conflict&msg={quote(err_msg)}')
        
        # Create Sales Order for Upfront Payment
        if appointment_type.has_payment_step and appointment_type.product_id:
            SaleOrder = request.env['sale.order'].sudo().with_company(company)
            so = SaleOrder.create({
                'company_id': company.id,
                'partner_id': partner.id,
                'state': 'draft',
                # paid online: the payment alone confirms the order (and so the booking);
                # a required signature would block that confirmation forever
                'require_signature': False,
                'prepayment_percent': 1.0,
                'order_line': [(0, 0, {
                    'product_id': appointment_type.product_id.id,
                    'name': f"Booking Fees: {appointment_type.name} - {booking.start_datetime.strftime('%b %d, %Y %H:%M')}",
                    'product_uom_qty': 1,
                    'price_unit': appointment_type.product_id.lst_price,
                })]
            })
            booking.sale_order_id = so.id
            
            # Redirect to the custom Appointment Payment page (which embeds payment.form)
            return request.redirect(f'/appointment/{booking.id}/payment?token={booking.access_token}')
        
        # Create Opportunity if configured
        if appointment_type.create_opportunity:
            try:
                request.env['crm.lead'].sudo().with_company(company).create({
                    'company_id': company.id,
                    'name': f"{appointment_type.name} - {partner.name}",
                    'partner_id': partner.id,
                    'email_from': partner.email,
                    'phone': partner.phone,
                    'type': 'opportunity',
                    'description': f"Created from Appointment Booking: {appointment_type.name}\nStart Date: {booking.start_datetime}",
                    'user_id': (booking.staff_user_id or appointment_type.sudo().user_id).id or False,
                })
            except Exception:
                pass
        
        invite_token = kwargs.get('invite_token')
        if invite_token:
            invite = request.env['appointment.invite'].sudo().search([('access_token', '=', invite_token)], limit=1)
            if invite:
                invite.appointment_count += 1
                
        # Trigger confirmation email only if not pending payment
        if booking.state != 'pending_payment':
            template = request.env.ref('appointment.email_template_booking_confirmation', raise_if_not_found=False)
            if template:
                template.sudo().send_mail(booking.id, force_send=False)
        
        values = {
            'appointment_type': appointment_type,
            'booking': booking,
            'start_dt': start_dt,
            'user': request.env.user if request.env.user.id != request.env.ref('base.public_user').id else None,
            'partner_name': name or partner.name,
            'partner_email': email or partner.email,
            'partner_phone': phone or partner.phone,
            'party_size': booking.party_size,
            'guest_details': booking.calendar_contact_details
        }
        
        return request.render('appointment.appointment_confirmation', values)

    @http.route(['/appointment/<model("appointment.booking"):booking>/payment'], type='http', auth='public', website=True)
    def appointment_payment(self, booking, **kwargs):
        token = kwargs.get('token')
        if not token or booking.access_token != token:
            return request.redirect('/?error=invalid_token')
            
        if booking.state != 'pending_payment' or not booking.sale_order_id:
            return request.redirect(f'/appointment/manage/{booking.id}?token={booking.access_token}')
            
        so = request.env['sale.order'].sudo().browse(booking.sale_order_id.id)
        
        # Build payment context for payment.form
        amount = so.amount_total
        currency = so.currency_id
        partner_sudo = so.partner_id
        company_id = so.company_id.id
        
        availability_report = {}
        providers_sudo = request.env['payment.provider'].sudo()._find_available_providers(
            company_id,
            partner_sudo.id,
            amount,
            currency_id=currency.id,
            report=availability_report,
            sale_order_id=so.id
        )
        payment_methods_sudo = providers_sudo._find_available_payment_methods(
            partner_sudo.id,
            currency_id=currency.id,
            report=availability_report,
        )._deduplicate_by_code(report=availability_report)
        tokens_sudo = providers_sudo._find_available_tokens(partner_sudo.id)
        
        # Build show_tokenize_input_mapping for payment.form
        show_tokenize_input_mapping = {
            p.id: p.allow_tokenization and not p._is_tokenization_required(sale_order_id=so.id)
            for p in providers_sudo
        }
        
        # Get checkout configuration
        # pyrefly: ignore [missing-import]
        from odoo.addons.payment.controllers.portal import PaymentPortal
        payment_portal = PaymentPortal()
        
        # Build kwargs expected by payment.form
        payment_context = {
            'booking': booking,
            'amount': amount,
            'currency': currency,
            'partner_id': partner_sudo.id,
            'providers_sudo': providers_sudo,
            'payment_methods_sudo': payment_methods_sudo,
            'tokens_sudo': tokens_sudo,
            'transaction_route': so.get_portal_url(suffix='/transaction'),
            'landing_route': f'/appointment/manage/{booking.id}?token={booking.access_token}',
            'reference_prefix': so.name,
            'access_token': so._portal_ensure_token(),
            
            # Additional required kwargs
            'mode': 'payment',
            'allow_token_selection': True,
            'allow_token_deletion': False,
            'default_token_id': None,
            'show_tokenize_input_mapping': show_tokenize_input_mapping,
            'display_submit_button': True,
            'submit_button_label': 'Pay',
            'assign_token_route': '/payment/assign_token',
        }
        
        return request.render('appointment.appointment_payment', payment_context)

    @http.route(['/appointment/manage/<model("appointment.booking"):booking>'], type='http', auth='public', website=True)
    def appointment_manage(self, booking, **kwargs):
        token = kwargs.get('token')
        if not token or booking.access_token != token:
            return request.redirect('/?error=invalid_token')
            
        import pytz
        tz = self._get_tz(booking.appointment_type_id)
        start_dt = booking.start_datetime.replace(tzinfo=pytz.UTC).astimezone(tz).replace(tzinfo=None)
        
        values = {
            'appointment_type': booking.appointment_type_id,
            'booking': booking,
            'start_dt': start_dt,
            'user': request.env.user if request.env.user.id != request.env.ref('base.public_user').id else None,
            'partner_name': booking.partner_id.name if booking.partner_id else booking.guest_details,
            'partner_email': booking.partner_id.email if booking.partner_id else '',
            'partner_phone': booking.partner_id.phone if booking.partner_id else '',
        }
        return request.render('appointment.appointment_confirmation', values)

    @http.route(['/appointment/<int:booking_id>/ics'], type='http', auth='public', website=True, sitemap=False)
    def appointment_ics(self, booking_id, token=None, **kwargs):
        import hmac
        from odoo.http.stream import content_disposition
        booking = request.env['appointment.booking'].sudo().browse(booking_id).exists()
        if not booking or not token or not booking.access_token \
                or not hmac.compare_digest(str(booking.access_token), str(token)):
            return request.not_found()
        return request.make_response(booking._get_ics_content(), headers=[
            ('Content-Type', 'text/calendar; charset=utf-8'),
            ('Content-Disposition', content_disposition('appointment.ics')),
        ])

    @http.route(['/appointment/cancel/<model("appointment.booking"):booking>'], type='http', auth='public', website=True)
    def appointment_cancel(self, booking, **kwargs):
        token = kwargs.get('token')
        if not token or booking.access_token != token:
            return request.redirect('/?error=invalid_token')
            
        from datetime import datetime, timedelta
        import pytz
        
        tz = self._get_tz(booking.appointment_type_id)
        now_utc = datetime.now()
        
        # Check cancellation policy
        min_hours = booking.appointment_type_id.min_cancellation_hours or 0.0
        deadline_utc = booking.start_datetime - timedelta(hours=min_hours)
        
        if now_utc > deadline_utc:
            # Too late to cancel
            return request.redirect(f'/appointment/{booking.appointment_type_id.id}?error=cancel_too_late')
            
        booking.sudo().write({'state': 'cancelled'})
        
        # Send cancellation email if configured
        if booking.appointment_type_id.cancel_template_id:
            booking.appointment_type_id.cancel_template_id.sudo().send_mail(booking.id, force_send=True)
        
        # Render a simple cancellation success page (or redirect to type with success message)
        return request.redirect(f'/appointment/{booking.appointment_type_id.id}?state=cancel-success')
