# pyrefly: ignore [missing-import]
from odoo import fields, models


class IrActionsAct_WindowView(models.Model):
    _inherit = 'ir.actions.act_window.view'

    view_mode = fields.Selection(selection_add=[('appointment_schedule', "Schedule")],
                                 ondelete={'appointment_schedule': 'cascade'})
