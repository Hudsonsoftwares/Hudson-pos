# pyrefly: ignore [missing-import]
from odoo import models, fields, api, _
# pyrefly: ignore [missing-import]
from odoo.exceptions import ValidationError

class AppointmentResource(models.Model):
    _name = 'appointment.resource'
    _description = 'Appointment Resource'
    _inherit = ['image.mixin']
    
    _check_company_auto = True

    name = fields.Char('Resource Name', required=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        'res.company', string='Company', index=True,
        default=lambda self: self.env.company,
        help="Leave empty to share this resource between all companies.")
    capacity = fields.Integer('Capacity', default=1)
    
    shareable = fields.Boolean('Shareable', help="Can be shared with other appointments")
    linked_resource_ids = fields.Many2many(
        'appointment.resource', 'appointment_resource_linked_rel', 'resource_id', 'linked_resource_id',
        string="Linked Resources", check_company=True,
        help="Resources combined with this one when a group is too big for it alone. This resource is "
             "only offered when they are free; booking one of them shows a warning while this one is busy.")
    timezone = fields.Selection('_tz_get', string='Timezone', default=lambda self: self.env.user.tz or 'UTC')
    description = fields.Html('Description')
    opening_hours_id = fields.Many2one('resource.calendar', string='Opening Hours', check_company=True,
                                       default=lambda self: self.env.company.resource_calendar_id)

    appointment_type_ids = fields.Many2many('appointment.type', string='Appointment Types', check_company=True)

    @api.constrains('linked_resource_ids')
    def _check_linked_resources(self):
        for resource in self:
            if resource in resource.linked_resource_ids:
                raise ValidationError(_("%s cannot be linked to itself.", resource.name))

    def _get_linking_resources(self):
        """Resources having one of these resources among their linked resources."""
        return self.sudo().search([('linked_resource_ids', 'in', self.ids)]) - self

    @api.model
    def _tz_get(self):
        import pytz
        return [(x, x) for x in pytz.all_timezones]

    @api.depends('name', 'capacity')
    def _compute_display_name(self):
        for resource in self:
            name = resource.name or ''
            if name and resource.capacity:
                if 'table' in name.lower():
                    resource.display_name = f"{name} (🪑 {resource.capacity})"
                else:
                    resource.display_name = f"{name} ({resource.capacity})"
            else:
                resource.display_name = name
