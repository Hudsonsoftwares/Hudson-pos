# pyrefly: ignore [missing-import]
import logging
from odoo import models, api

_logger = logging.getLogger(__name__)

class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    @api.model_create_multi
    def create(self, vals_list):
        references = [vals.get('reference') for vals in vals_list if vals.get('reference')]
        
        if references:
            sale_orders = self.env['sale.order'].search([('name', 'in', references)])
            so_by_ref = {so.name: so for so in sale_orders}
            
            if sale_orders:
                bookings = self.env['appointment.booking'].search([('sale_order_id', 'in', sale_orders.ids)])
                booking_by_so = {booking.sale_order_id.id: booking for booking in bookings}
            else:
                booking_by_so = {}
                
            for vals in vals_list:
                ref = vals.get('reference')
                if ref and ref in so_by_ref:
                    so = so_by_ref[ref]
                    vals['sale_order_ids'] = [(4, so.id)]
                    
                    booking = booking_by_so.get(so.id)
                    if booking:
                        vals['landing_route'] = f'/appointment/manage/{booking.id}?token={booking.access_token}'
        
        return super().create(vals_list)

    def _post_process(self):
        super()._post_process()
        for tx in self.filtered(lambda t: t.state == 'done'):
            for so in tx.sale_order_ids:
                so_sudo = so.sudo().with_context(mail_activity_automation_skip=True, tracking_disable=True)
                if so_sudo.state in ('draft', 'sent'):
                    try:
                        so_sudo.action_confirm()
                    except Exception as err:
                        _logger.warning("Error confirming SO %s on payment transaction %s: %s", so_sudo.id, tx.id, err)
                if not so_sudo.invoice_ids:
                    try:
                        for line in so_sudo.order_line:
                            if not line.qty_delivered:
                                line.qty_delivered = line.product_uom_qty
                        invoices = so_sudo._create_invoices()
                        invoices.action_post()
                    except Exception as err:
                        _logger.warning("Error invoicing SO %s on payment transaction %s: %s", so_sudo.id, tx.id, err)
                # Confirm booking state to confirmed
                booking = self.env['appointment.booking'].search([('sale_order_id', '=', so.id)], limit=1)
                if booking and booking.state == 'pending_payment':
                    try:
                        booking.sudo().write({'state': 'confirmed'})
                    except Exception as b_err:
                        _logger.error("Error confirming booking %s after payment: %s", booking.id, b_err)

