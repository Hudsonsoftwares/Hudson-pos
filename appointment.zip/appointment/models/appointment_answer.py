# pyrefly: ignore [missing-import]
from odoo import api, models, fields


class AppointmentAnswer(models.Model):
    _name = 'appointment.answer'
    _description = 'Appointment Answer'
    _rec_name = 'question_id'

    booking_id = fields.Many2one('appointment.booking', string='Booking', required=True, ondelete='cascade')
    question_id = fields.Many2one('appointment.question', string='Question', required=True)
    question_type = fields.Selection(related='question_id.question_type', string='Type')

    value_text = fields.Text('Answer')
    value_date = fields.Date('Date Answer')
    value_answer_ids = fields.Many2many(
        'appointment.question.answer', string='Selected Answer',
        domain="[('question_id', '=', question_id)]",
        help="Chosen option(s) of a dropdown, radio or checkbox question.")
    appointment_type_id = fields.Many2one('appointment.type', related='booking_id.appointment_type_id', string='Appointment Type', store=True)
    company_id = fields.Many2one('res.company', related='booking_id.company_id', store=True, index=True, string='Company')

    @api.model
    def _parse_date_value(self, raw_val):
        if not raw_val:
            return False
        if isinstance(raw_val, str):
            raw_val = raw_val.strip()
            if not raw_val:
                return False
        try:
            return fields.Date.to_date(raw_val)
        except Exception:
            return False

    def _prepare_date_answer_vals(self, vals, question=None):
        vals = dict(vals)
        q = question or (vals.get('question_id') and self.env['appointment.question'].browse(vals['question_id']))
        is_date_q = q and q.question_type == 'date'
        if 'value_date' in vals:
            parsed = self._parse_date_value(vals.get('value_date'))
            vals['value_date'] = parsed
            if parsed and 'value_text' not in vals:
                vals['value_text'] = fields.Date.to_string(parsed)
        elif is_date_q and 'value_text' in vals:
            parsed = self._parse_date_value(vals.get('value_text'))
            vals['value_date'] = parsed
            if parsed:
                vals['value_text'] = fields.Date.to_string(parsed)
        return vals

    @api.model_create_multi
    def create(self, vals_list):
        prepared = [self._prepare_date_answer_vals(vals) for vals in vals_list]
        answers = super().create(prepared)
        if not self.env.context.get('skip_event_sync'):
            answers.mapped('booking_id')._sync_event_fields_from_answers()
        return answers

    def write(self, vals):
        res = True
        if 'value_date' in vals or 'value_text' in vals or 'value_answer_ids' in vals:
            if 'value_date' in vals or 'value_text' in vals:
                for answer in self:
                    prepared_vals = self._prepare_date_answer_vals(vals, question=answer.question_id)
                    res = super(AppointmentAnswer, answer).write(prepared_vals) and res
            else:
                res = super().write(vals)
            if not self.env.context.get('skip_event_sync'):
                self.mapped('booking_id')._sync_event_fields_from_answers()
            return res
        return super().write(vals)
