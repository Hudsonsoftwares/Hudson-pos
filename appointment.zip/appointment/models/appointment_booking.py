# pyrefly: ignore [missing-import]
from odoo import models, fields, api, _

# pyrefly: ignore [missing-import]
from odoo.exceptions import UserError, ValidationError
# pyrefly: ignore [missing-import]
from odoo.tools import format_datetime
import calendar
import hmac
import logging
import re
import uuid
from datetime import date, datetime, timedelta
from urllib.parse import urlencode
import pytz

_logger = logging.getLogger(__name__)


class AppointmentBooking(models.Model):
    _name = 'appointment.booking'
    _description = 'Appointment Booking'
    _inherit = ['mail.activity.mixin', 'rating.mixin']  # rating.mixin includes mail.thread
    
    name = fields.Char('Reference', required=True, copy=False, readonly=True, default='New')
    appointment_type_id = fields.Many2one('appointment.type', string='Appointment Type', required=True)
    company_id = fields.Many2one(
        'res.company', related='appointment_type_id.company_id', store=True, index=True, string='Company')

    def _compute_display_name(self):
        for booking in self:
            guest_name = booking._get_guest_display_name()
            booking.display_name = guest_name or booking.name

    partner_id = fields.Many2one('res.partner', string='Customer')
    customer_name = fields.Char('Customer Name')
    customer_phone = fields.Char('Customer Phone')
    customer_email = fields.Char('Customer Email')
    celebrant_name = fields.Char('Celebrant / Honoree Name', tracking=True)
    occasion_title = fields.Char('Occasion / Celebration Details', tracking=True)
    occasion_date = fields.Date('Special Day / Occasion Date', tracking=True, index=True)
    event_category = fields.Selection(
        related='appointment_type_id.event_category', store=True, readonly=True)
    confirmation_sent = fields.Boolean('Confirmation Sent', copy=False, default=False)
    wish_last_advance_year = fields.Integer('Last Advance Wish Year', copy=False, default=0)
    wish_last_day_year = fields.Integer('Last Special Day Wish Year', copy=False, default=0)

    staff_user_id = fields.Many2one('res.users', string='Staff')
    resource_ids = fields.Many2many('appointment.resource', string='Resource')
    party_size = fields.Integer('Party Size', default=1)
    
    subject = fields.Char('Subject', compute='_compute_subject', store=True, readonly=False)
    asked_capacity = fields.Integer('Total Capacity Asked', compute='_compute_capacities')
    total_capacity_reserved = fields.Integer('Total Capacity Reserved', compute='_compute_capacities')

    guest_details = fields.Text('Guest Details / Answers')
    
    start_datetime = fields.Datetime('Start Datetime', required=True)
    end_datetime = fields.Datetime('End Datetime', required=True)
    duration = fields.Float('Duration', compute='_compute_duration', inverse='_inverse_duration', store=True)
    
    access_token = fields.Char('Access Token', default=lambda self: str(uuid.uuid4()))
    
    @api.depends('start_datetime', 'end_datetime')
    def _compute_duration(self):
        for booking in self:
            if booking.start_datetime and booking.end_datetime:
                diff = booking.end_datetime - booking.start_datetime
                booking.duration = diff.total_seconds() / 3600.0
            else:
                booking.duration = 0.0

    def _inverse_duration(self):
        from datetime import timedelta
        for booking in self:
            if booking.start_datetime and booking.duration:
                booking.end_datetime = booking.start_datetime + timedelta(hours=booking.duration)
    
    @api.depends('customer_name', 'partner_id', 'partner_id.name', 'appointment_type_id',
                 'appointment_type_id.name', 'appointment_type_id.is_event_booking', 'celebrant_name', 'name')
    def _compute_subject(self):
        for booking in self:
            guest_name = booking._get_guest_display_name() or booking.name
            type_name = booking.appointment_type_id.name if booking.appointment_type_id else ''
            if booking.celebrant_name and booking.appointment_type_id.is_event_booking:
                booking.subject = f"{booking.celebrant_name} - {type_name}" if type_name else booking.celebrant_name
            else:
                booking.subject = f"{guest_name} - {type_name}" if guest_name and type_name else (guest_name or type_name or '')

    @api.model
    def _phone_get_number_fields(self):
        return ['customer_phone']

    @api.model
    def _normalize_phone_digits(self, phone):
        return re.sub(r'\D+', '', str(phone or ''))

    def _get_guest_display_name(self):
        self.ensure_one()
        if self.customer_name and self.customer_name.strip():
            return self.customer_name.strip()
        partner = self.partner_id
        company = self.company_id or self.appointment_type_id.company_id or self.env.company
        if partner and partner.id != 1 and not partner.is_company and (not company or partner.id != company.partner_id.id):
            if partner.name and (not company or partner.name != company.name):
                return partner.name.strip()
        return ''

    def _get_recipient_email(self):
        self.ensure_one()
        email = (self.customer_email or '').strip()
        if not email and self.partner_id:
            email = (self.partner_id.email or '').strip()
        return email if ('@' in email and '.' in email.split('@', 1)[-1]) else False

    def _get_recipient_phone(self):
        self.ensure_one()
        phone = (self.customer_phone or '').strip()
        if not phone and self.partner_id:
            phone = (self.partner_id.phone or (getattr(self.partner_id, 'mobile', '') if hasattr(self.partner_id, 'mobile') else '') or '').strip()
        return phone or False

    def _sync_event_fields_from_answers(self):
        Answer = self.env['appointment.answer']
        for booking in self.sudo():
            vals = {}
            for answer in booking.answer_ids:
                q = answer.question_id
                if not q:
                    continue
                role = q.question_role or 'none'
                if q.is_occasion_date or role == 'occasion_date':
                    parsed = answer.value_date or Answer._parse_date_value(answer.value_text)
                    if parsed:
                        vals['occasion_date'] = parsed
                        if not answer.value_date:
                            answer.with_context(skip_event_sync=True).write({'value_date': parsed})
                elif role == 'celebrant_name':
                    text = (answer.value_text or '').strip()
                    if text:
                        vals['celebrant_name'] = text
                elif role == 'occasion_title':
                    text = (answer.value_text or '').strip()
                    if text:
                        vals['occasion_title'] = text
            if vals:
                booking.with_context(skip_event_sync=True).write(vals)

    @api.depends('party_size', 'resource_ids', 'resource_ids.capacity', 'appointment_type_id.booking_target')
    def _compute_capacities(self):
        for booking in self:
            if booking.appointment_type_id.booking_target == 'resources':
                booking.asked_capacity = booking.party_size
                booking.total_capacity_reserved = sum(booking.resource_ids.mapped('capacity'))
            else:
                booking.asked_capacity = booking.party_size
                booking.total_capacity_reserved = booking.party_size

    @api.constrains('start_datetime', 'end_datetime')
    def _check_date_integrity(self):
        for booking in self:
            if booking.start_datetime and booking.end_datetime:
                if booking.end_datetime <= booking.start_datetime:
                    raise ValidationError("The end date and time must be later than the start date and time.")

    booking_target = fields.Selection(related='appointment_type_id.booking_target')
    appointment_user_ids = fields.Many2many(related='appointment_type_id.user_ids', string='Appointment Staff')
    appointment_question_ids = fields.Many2many(related='appointment_type_id.question_ids', string='Appointment Questions')

    unavailable_user_ids = fields.Many2many(
        'res.users', string='Unavailable Staff', compute='_compute_unavailable_targets')
    unavailable_resource_ids = fields.Many2many(
        'appointment.resource', string='Unavailable Resources', compute='_compute_unavailable_targets')

    @api.depends('appointment_type_id', 'staff_user_id', 'resource_ids', 'start_datetime', 'end_datetime',
                 'party_size', 'state')
    def _compute_unavailable_targets(self):
        """Who / what is not available at the selected time, shown as a warning
        before saving (the save itself is refused by the constraints)."""
        for booking in self:
            booking.unavailable_user_ids = False
            booking.unavailable_resource_ids = False
            appointment_type = booking.appointment_type_id.sudo()
            start, end = booking.start_datetime, booking.end_datetime
            if not appointment_type or booking.state == 'cancelled' or not start or not end or end <= start:
                continue
            exclude_ids = [booking._origin.id] if booking._origin.id else []
            party_size = booking.party_size or 1
            if appointment_type.booking_target == 'users':
                if booking.staff_user_id:
                    if not booking._is_staff_available(appointment_type, booking.staff_user_id, start, end,
                                                       party_size, exclude_ids):
                        booking.unavailable_user_ids = booking.staff_user_id
                elif appointment_type.user_ids and not any(
                        booking._is_staff_available(appointment_type, user, start, end, party_size, exclude_ids)
                        for user in appointment_type.user_ids):
                    # no staff chosen: only a problem when nobody can be assigned
                    booking.unavailable_user_ids = appointment_type.user_ids
            elif booking.resource_ids:
                unavailable = self.env['appointment.resource']
                for resource in booking.resource_ids:
                    overlapping = self.sudo().search([
                        ('resource_ids', 'in', [resource._origin.id or resource.id]),
                        ('id', 'not in', exclude_ids),
                        ('state', '!=', 'cancelled'),
                        ('start_datetime', '<', end),
                        ('end_datetime', '>', start),
                    ])
                    closed = self.env['appointment.closing.day'].sudo().search_count(
                        appointment_type._get_closing_day_domain(users=self.env['res.users'], resources=resource) + [
                            ('start_datetime', '<', end), ('end_datetime', '>', start)], limit=1)
                    if closed or (overlapping and (
                            not resource.shareable
                            or party_size + sum(overlapping.mapped('party_size')) > resource.capacity)):
                        unavailable |= resource
                booking.unavailable_resource_ids = unavailable

    linked_resource_warning = fields.Text('Linked Resources Warning', compute='_compute_linked_resource_warning')

    @api.depends('resource_ids', 'start_datetime', 'end_datetime', 'state')
    def _compute_linked_resource_warning(self):
        """Information only: a resource having a selected resource among its
        linked resources (e.g. a projector linked to this conference room) is
        booked or closed at the selected time. The booking stays possible."""
        for booking in self:
            booking.linked_resource_warning = False
            start, end = booking.start_datetime, booking.end_datetime
            if booking.state == 'cancelled' or not booking.resource_ids or not start or not end or end <= start:
                continue
            exclude_ids = [booking._origin.id] if booking._origin.id else []
            selected = booking.resource_ids._origin
            lines = []
            for resource in selected:
                for linking in resource._get_linking_resources() - selected:
                    closing = self.env['appointment.closing.day'].sudo().search([
                        ('closing_type', '=', 'resources'), ('resource_id', '=', linking.id),
                        ('start_datetime', '<', end), ('end_datetime', '>', start)], limit=1)
                    if closing:
                        lines.append(_(
                            "%(linked)s (linked to %(resource)s) is not available during this period: "
                            "closed (%(reason)s) from %(start)s to %(end)s.",
                            linked=linking.name, resource=resource.name, reason=closing.name,
                            start=booking._format_booking_time(closing.start_datetime),
                            end=booking._format_booking_time(closing.end_datetime)))
                        continue
                    overlapping = self.sudo().search([
                        ('resource_ids', 'in', linking.ids),
                        ('id', 'not in', exclude_ids),
                        ('state', 'in', ('confirmed', 'checked_in')),
                        ('start_datetime', '<', end),
                        ('end_datetime', '>', start),
                    ], order='start_datetime')
                    booked = sum(overlapping.mapped('party_size'))
                    if overlapping and (not linking.shareable or booked >= linking.capacity):
                        lines.append(_(
                            "%(linked)s (linked to %(resource)s) is not available during this period: "
                            "already booked from %(start)s to %(end)s.",
                            linked=linking.name, resource=resource.name,
                            start=booking._format_booking_time(min(overlapping.mapped('start_datetime'))),
                            end=booking._format_booking_time(max(overlapping.mapped('end_datetime')))))
            booking.linked_resource_warning = "\n".join(lines) or False

    @api.model
    def default_get(self, fields):
        res = super().default_get(fields)
        # Schedule > Staff / Resource Bookings: preselect the appointment type
        # when there is only one of that kind
        target = self.env.context.get('appointment_booking_target')
        if target and 'appointment_type_id' in fields and not res.get('appointment_type_id'):
            appointment_types = self.env['appointment.type'].search([('booking_target', '=', target)], limit=2)
            if len(appointment_types) == 1:
                res['appointment_type_id'] = appointment_types.id
        return res

    @api.onchange('appointment_type_id')
    def _onchange_appointment_type_reminders(self):
        if self.appointment_type_id and not self.alarm_ids:
            self.alarm_ids = self.appointment_type_id.reminder_ids

    @api.onchange('appointment_type_id')
    def _onchange_appointment_type_location(self):
        appointment_type = self.appointment_type_id
        if (appointment_type and not self.location and appointment_type.location in ('office', 'custom')
                and appointment_type.location_details):
            self.location = appointment_type.location_details

    @api.onchange('appointment_type_id')
    def _onchange_appointment_type_staff(self):
        # a staff member must belong to the appointment type
        if self.staff_user_id and self.appointment_type_id and self.staff_user_id not in self.appointment_type_id.user_ids:
            self.staff_user_id = False

    def _is_staff_available(self, appointment_type, user, start, end, party_size, exclude_ids=()):
        """Whether ``user`` can take a booking of ``appointment_type`` from
        ``start`` to ``end`` (naive UTC): no conflicting booking, closing day
        or busy calendar event. Same rules as the booking constraints."""
        appointment_type = appointment_type.sudo()
        overlapping = self.sudo().search([
            ('staff_user_id', '=', user.id),
            ('id', 'not in', list(exclude_ids)),
            ('state', '!=', 'cancelled'),
            ('start_datetime', '<', end),
            ('end_datetime', '>', start),
            ('appointment_type_id.booking_target', '=', 'users'),
        ])
        if overlapping:
            same_group = appointment_type.group_booking and all(
                o.appointment_type_id == appointment_type for o in overlapping)
            if not same_group or party_size + sum(overlapping.mapped('party_size')) > appointment_type.capacity:
                return False
        if self.env['appointment.closing.day'].sudo().search_count(
                appointment_type._get_closing_day_domain(users=user, resources=self.env['appointment.resource']) + [
                    ('start_datetime', '<', end), ('end_datetime', '>', start)], limit=1):
            return False
        return not appointment_type._get_busy_intervals_by_user(user, start, end).get(user.id)

    @api.model
    def _assign_available_staff(self, vals):
        """Backend booking of a staff-based type without staff: assign a free
        staff member of the type, like the website does."""
        appointment_type = self.env['appointment.type'].browse(vals.get('appointment_type_id')).sudo().exists()
        start = fields.Datetime.to_datetime(vals.get('start_datetime'))
        end = fields.Datetime.to_datetime(vals.get('end_datetime'))
        if (not appointment_type or appointment_type.booking_target != 'users' or vals.get('staff_user_id')
                or vals.get('state') == 'cancelled' or not start or not end or end <= start
                or not appointment_type.user_ids):
            return
        party_size = vals.get('party_size') or 1
        free_users = [user for user in appointment_type.user_ids
                      if self._is_staff_available(appointment_type, user, start, end, party_size)]
        if not free_users:
            tz = self.env.user.tz or appointment_type.appointment_tz or 'UTC'
            raise ValidationError(_(
                "This slot is already booked: no staff member of \"%(type)s\" is available "
                "from %(start)s to %(end)s.\n\nPlease choose another time.",
                type=appointment_type.name,
                start=format_datetime(self.env, start, tz=tz, dt_format='short'),
                end=format_datetime(self.env, end, tz=tz, dt_format='short'),
            ))
        if appointment_type.assign_method == 'random':
            import random
            vals['staff_user_id'] = random.choice(free_users).id
        else:
            vals['staff_user_id'] = free_users[0].id

    def _format_booking_time(self, value):
        """``value`` (naive UTC) as readable date & time in the user's timezone."""
        tz = self.env.user.tz or self.appointment_type_id.appointment_tz or 'UTC'
        return format_datetime(self.env, value, tz=tz, dt_format='short')

    def _conflict_message(self, who, conflicts):
        """Message telling ``who`` is not available because of the ``conflicts`` bookings."""
        details = "\n".join(
            _("- %(name)s (%(type)s), %(start)s to %(end)s",
              name=conflict.subject or conflict.name,
              type=conflict.appointment_type_id.name,
              start=self._format_booking_time(conflict.start_datetime),
              end=self._format_booking_time(conflict.end_datetime))
            for conflict in conflicts[:5]
        )
        return _(
            "%(who)s is not available from %(start)s to %(end)s: this slot is already booked.\n\n"
            "Existing booking(s):\n%(details)s\n\n"
            "Please choose another time or another staff member / resource.",
            who=who,
            start=self._format_booking_time(self.start_datetime),
            end=self._format_booking_time(self.end_datetime),
            details=details,
        )

    @api.constrains('staff_user_id', 'resource_ids', 'start_datetime', 'end_datetime', 'state', 'party_size')
    def _check_overlapping_appointments(self):
        for booking in self:
            if not booking.appointment_type_id or booking.state in ('cancelled', 'no_show', 'checked_out', 'draft') or not booking.start_datetime or not booking.end_datetime:
                continue

            if booking.appointment_type_id.booking_target == 'users' and booking.staff_user_id:
                overlapping = self.search([
                    ('staff_user_id', '=', booking.staff_user_id.id),
                    ('id', '!=', booking.id),
                    ('state', 'in', ('confirmed', 'checked_in')),
                    ('start_datetime', '<', booking.end_datetime),
                    ('end_datetime', '>', booking.start_datetime),
                    ('appointment_type_id.booking_target', '=', 'users')
                ])
                if overlapping:
                    # Allow overlaps ONLY if they are the exact same group booking type and within capacity
                    if booking.appointment_type_id.group_booking and all(o.appointment_type_id.id == booking.appointment_type_id.id for o in overlapping):
                        user_capacity = getattr(booking.staff_user_id, 'capacity', booking.appointment_type_id.capacity)
                        total_party = booking.party_size + sum(overlapping.mapped('party_size'))
                        if total_party <= user_capacity:
                            continue
                        raise ValidationError(_(
                            "%(staff)s is fully booked from %(start)s to %(end)s: %(total)s attendees requested "
                            "for a capacity of %(capacity)s.\n\nPlease choose another time or another staff member.",
                            staff=booking.staff_user_id.name,
                            start=booking._format_booking_time(booking.start_datetime),
                            end=booking._format_booking_time(booking.end_datetime),
                            total=total_party,
                            capacity=user_capacity,
                        ))
                    raise ValidationError(booking._conflict_message(booking.staff_user_id.name, overlapping))

            elif booking.appointment_type_id.booking_target == 'resources' and booking.resource_ids:
                for resource in booking.resource_ids:
                    overlapping = self.search([
                        ('resource_ids', 'in', [resource.id]),
                        ('id', '!=', booking.id),
                        ('state', 'in', ('confirmed', 'checked_in')),
                        ('start_datetime', '<', booking.end_datetime),
                        ('end_datetime', '>', booking.start_datetime),
                    ])
                    if overlapping:
                        if not resource.shareable:
                            raise ValidationError(booking._conflict_message(resource.name, overlapping))

                        total_party = booking.party_size + sum(overlapping.mapped('party_size'))
                        if total_party > resource.capacity:
                            raise ValidationError(_(
                                "%(resource)s is fully booked from %(start)s to %(end)s: %(total)s people requested "
                                "for a capacity of %(capacity)s.\n\nPlease choose another time or another resource.",
                                resource=resource.name,
                                start=booking._format_booking_time(booking.start_datetime),
                                end=booking._format_booking_time(booking.end_datetime),
                                total=total_party,
                                capacity=resource.capacity,
                            ))

    @api.constrains('staff_user_id', 'appointment_type_id')
    def _check_staff_of_type(self):
        for booking in self:
            appointment_type = booking.appointment_type_id.sudo()
            if (booking.state != 'cancelled' and appointment_type.booking_target == 'users'
                    and booking.staff_user_id and booking.staff_user_id not in appointment_type.user_ids):
                raise ValidationError(_(
                    "%(staff)s is not a staff member of the appointment type \"%(type)s\".\n\n"
                    "Please choose one of: %(allowed)s.",
                    staff=booking.staff_user_id.name,
                    type=appointment_type.name,
                    allowed=", ".join(appointment_type.user_ids.mapped('name')) or _("(no staff configured)"),
                ))

    @api.constrains('staff_user_id', 'resource_ids', 'start_datetime', 'end_datetime')
    def _check_availability(self):
        """The staff member / resources must not be busy in their calendar or
        closed by a closing day. Only checked when the time or the assignee is
        set or changed, so status changes (e.g. payment confirmation) still work."""
        for booking in self:
            if not booking.appointment_type_id or booking.state == 'cancelled' or not booking.start_datetime or not booking.end_datetime:
                continue
            appointment_type = booking.appointment_type_id.sudo()
            start, end = booking.start_datetime, booking.end_datetime
            staff = booking.staff_user_id if appointment_type.booking_target == 'users' else self.env['res.users']
            resources = booking.resource_ids if appointment_type.booking_target == 'resources' else self.env['appointment.resource']

            closing = self.env['appointment.closing.day'].sudo().search(
                appointment_type._get_closing_day_domain(users=staff, resources=resources) + [
                    ('start_datetime', '<', end),
                    ('end_datetime', '>', start),
                ], limit=1)
            if closing:
                if closing.closing_type == 'users':
                    closed = closing.user_id.name
                elif closing.closing_type == 'resources':
                    closed = closing.resource_id.name
                else:
                    closed = appointment_type.name
                raise ValidationError(_(
                    "%(closed)s is not available from %(start)s to %(end)s: closed (%(reason)s) "
                    "from %(closed_start)s to %(closed_end)s.\n\nPlease choose another time.",
                    closed=closed,
                    start=booking._format_booking_time(start),
                    end=booking._format_booking_time(end),
                    reason=closing.name,
                    closed_start=booking._format_booking_time(closing.start_datetime),
                    closed_end=booking._format_booking_time(closing.end_datetime),
                ))

            if staff:
                own_event = booking.calendar_event_id
                busy = [
                    period for period in appointment_type._get_busy_intervals_by_user(staff, start, end).get(staff.id, [])
                    # the booking's own calendar event never counts
                    if not (own_event and period == (own_event.start, own_event.stop))
                ]
                if busy:
                    raise ValidationError(_(
                        "%(staff)s is not available from %(start)s to %(end)s: busy in their calendar "
                        "from %(busy_start)s to %(busy_end)s.\n\nPlease choose another time or another staff member.",
                        staff=staff.name,
                        start=booking._format_booking_time(start),
                        end=booking._format_booking_time(end),
                        busy_start=booking._format_booking_time(busy[0][0]),
                        busy_end=booking._format_booking_time(busy[0][1]),
                    ))

    calendar_contact_details = fields.Html('Contact Details', compute='_compute_calendar_contact_details')
    
    @api.depends('customer_name', 'customer_phone', 'customer_email', 'partner_id', 'partner_id.name',
                 'partner_id.email', 'partner_id.phone', 'guest_details', 'celebrant_name',
                 'occasion_title', 'occasion_date', 'appointment_type_id.name')
    def _compute_calendar_contact_details(self):
        for booking in self:
            details = ""
            guest_name = booking._get_guest_display_name()
            guest_email = booking._get_recipient_email()
            guest_phone = booking._get_recipient_phone()
            if guest_name:
                details += f"<b>{guest_name}</b><br/>"
            if guest_email:
                details += f"<span style='color: #28a745;'>{guest_email}</span><br/>"
            if guest_phone:
                details += f"<span style='color: #28a745;'>{guest_phone}</span><br/>"
            if booking.celebrant_name:
                details += f"<span><b>Celebrant:</b> {booking.celebrant_name}</span><br/>"
            if booking.occasion_title:
                details += f"<span><b>Occasion:</b> {booking.occasion_title}</span><br/>"
            if booking.occasion_date:
                details += f"<span><b>Special Day:</b> {booking.occasion_date.strftime('%d %b %Y')}</span><br/>"
            if booking.guest_details:
                details += f"<br/>{booking.guest_details.replace(chr(10), '<br/>')}"
            booking.calendar_contact_details = details
    
    sale_order_id = fields.Many2one('sale.order', string="Sales Order", readonly=True)
    
    state = fields.Selection([
        ('draft', 'Request'),
        ('pending_payment', 'Pending Payment'),
        ('confirmed', 'Booked'),
        ('checked_in', 'Checked-In'),
        ('checked_out', 'Completed'),
        ('no_show', 'No Show'),
        ('cancelled', 'Cancelled')
    ], string='Status', default='confirmed', required=True, tracking=True)

    allday = fields.Boolean('All Day', default=False)
    location = fields.Char('Location')
    videocall_location = fields.Char('Video Link')
    show_as = fields.Selection([('busy', 'Busy'), ('free', 'Free')], string='Status', default='busy')
    privacy = fields.Selection([('public', 'Public'), ('private', 'Private'), ('confidential', 'Only internal users')], string='Visibility', default='public')
    attendee_ids = fields.Many2many('res.partner', string='Attendees')
    description = fields.Html(related='calendar_event_id.description', string='Description', readonly=False)
    answer_ids = fields.One2many('appointment.answer', 'booking_id', string='Answers')

    calendar_event_id = fields.Many2one('calendar.event', string='Calendar Event')
    tag_ids = fields.Many2many(
        'calendar.event.type', 'appointment_booking_calendar_event_type_rel', 'booking_id', 'type_id',
        string='Tags')
    alarm_ids = fields.Many2many(
        'calendar.alarm', 'appointment_booking_calendar_alarm_rel', 'booking_id', 'alarm_id',
        string='Reminders', help="Reminders of the meeting; by default those of the appointment type.")
    notes = fields.Html('Notes', help="Internal notes, copied to the calendar event.")
    feedback_sent = fields.Boolean('Feedback Requested', copy=False, readonly=True,
                                   help="The feedback email has been sent to the customer.")

    def _rating_get_operator(self):
        """The rated person: the staff member (or organizer) of the appointment."""
        self.ensure_one()
        return self._get_calendar_event_organizer().partner_id

    @api.model
    def _cron_send_feedback_requests(self):
        """Ask the customer to rate the appointment once it is over (booked or
        checked-in appointments only, once per booking)."""
        import logging
        from datetime import timedelta
        now = fields.Datetime.now()
        bookings = self.search([
            ('state', 'in', ('confirmed', 'checked_in')),
            ('feedback_sent', '=', False),
            ('end_datetime', '<=', now),
            # never ask for old appointments (e.g. after a long server downtime)
            ('end_datetime', '>=', now - timedelta(days=2)),
            ('appointment_type_id.feedback_template_id', '!=', False),
            ('partner_id', '!=', False),
        ], limit=200)
        requested = False
        for booking in bookings:
            booking.feedback_sent = True
            if not booking.partner_id.email:
                continue
            try:
                with self.env.cr.savepoint():
                    booking.rating_send_request(
                        booking.appointment_type_id.feedback_template_id,
                        lang=booking.partner_id.lang, force_send=False)
                requested = True
            except Exception:
                logging.getLogger(__name__).exception(
                    "Appointment feedback request failed for booking %s", booking.id)
        if requested:
            # deliver now instead of at the next (hourly) run of the mail queue
            mail_queue = self.env.ref('mail.ir_cron_mail_scheduler_action', raise_if_not_found=False)
            if mail_queue:
                mail_queue._trigger()
    res_model_id = fields.Many2one('ir.model', 'Document Model', ondelete='set null', index=True)
    res_model = fields.Char('Document Model Name', related='res_model_id.model', store=True)
    res_id = fields.Many2oneReference('Document ID', model_field='res_model')
    res_record = fields.Reference(
        string='Linked to', selection='_get_linked_model_selection',
        compute='_compute_res_record', inverse='_inverse_res_record',
        help="Document this meeting is about (e.g. an opportunity), as on calendar events.")

    @api.model
    def _get_linked_model_selection(self):
        # same documents as the "Linked to" of calendar events
        return self.env['calendar.event']._get_model_selection()

    @api.depends('res_model', 'res_id')
    def _compute_res_record(self):
        for booking in self:
            booking.res_record = (
                f"{booking.res_model},{booking.res_id}"
                if booking.res_model and booking.res_id else False
            )

    def _inverse_res_record(self):
        for booking in self:
            record = booking.res_record
            if not record:
                booking.res_model_id = False
                booking.res_id = False
                continue
            booking.res_model_id = self.env['ir.model']._get_id(record._name)
            booking.res_id = record.id
    recurrency = fields.Boolean(related='calendar_event_id.recurrency', string='Recurrent', readonly=False)
    event_attendee_ids = fields.One2many(related='calendar_event_id.attendee_ids', string='Event Attendees', readonly=True)

    # ------------------------------------------------------------------
    # "Add to calendar" (website confirmation page)
    # ------------------------------------------------------------------

    def _get_duration_label(self):
        """Human readable length of the appointment, e.g. "1 hour", "1 h 30 min"."""
        self.ensure_one()
        if not self.start_datetime or not self.end_datetime:
            return ''
        minutes = int(round((self.end_datetime - self.start_datetime).total_seconds() / 60))
        hours, minutes = divmod(minutes, 60)
        if hours and minutes:
            return _("%(hours)s h %(minutes)s min", hours=hours, minutes=minutes)
        if hours:
            return _("1 hour") if hours == 1 else _("%s hours", hours)
        return _("%s min", minutes)

    def _get_calendar_location(self):
        self.ensure_one()
        appointment_type = self.appointment_type_id
        return (self.location or self.videocall_location
                or (appointment_type.location in ('office', 'custom') and appointment_type.location_details)
                or (appointment_type.location == 'online' and _("Online Meeting"))
                or '')

    def _get_calendar_title(self):
        self.ensure_one()
        company = self.appointment_type_id.company_id or self.env.company
        return f"{self.appointment_type_id.name} - {company.name}"

    def _get_calendar_description(self):
        self.ensure_one()
        lines = [self.appointment_type_id.name or '']
        if self.videocall_location:
            lines.append(_("Join: %s", self.videocall_location))
        lines.append(_("Manage your appointment: %s",
                       f"{self.get_base_url()}/appointment/manage/{self.id}?token={self.access_token}"))
        return "\n".join(line for line in lines if line)

    def _get_google_calendar_url(self):
        """Link opening Google Calendar's "new event" page pre-filled with the appointment."""
        self.ensure_one()
        from urllib.parse import urlencode
        fmt = '%Y%m%dT%H%M%SZ'
        return 'https://calendar.google.com/calendar/render?' + urlencode({
            'action': 'TEMPLATE',
            'text': self._get_calendar_title(),
            'dates': f"{self.start_datetime.strftime(fmt)}/{self.end_datetime.strftime(fmt)}",
            'details': self._get_calendar_description(),
            'location': self._get_calendar_location(),
        })

    def _get_ics_url(self):
        self.ensure_one()
        return f"/appointment/{self.id}/ics?token={self.access_token}"

    def _get_ics_content(self):
        """The appointment as an iCalendar (.ics) file, for Outlook / Apple Calendar / others."""
        self.ensure_one()
        fmt = '%Y%m%dT%H%M%SZ'

        def escape(text):
            return (str(text or '').replace('\\', '\\\\').replace(';', '\\;')
                    .replace(',', '\\,').replace('\n', '\\n'))

        def fold(line):
            # RFC 5545: lines of at most 75 octets, continued with a leading space
            data = line.encode('utf-8')
            parts = []
            while len(data) > 75:
                cut = 75
                while cut and (data[cut] & 0xC0) == 0x80:  # never split a UTF-8 character
                    cut -= 1
                parts.append(data[:cut].decode('utf-8'))
                data = b' ' + data[cut:]
            parts.append(data.decode('utf-8'))
            return '\r\n'.join(parts)

        lines = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Odoo//Appointment//EN',
            'METHOD:PUBLISH',
            'BEGIN:VEVENT',
            f"UID:appointment-booking-{self.id}-{self.access_token}",
            f"DTSTAMP:{fields.Datetime.now().strftime(fmt)}",
            f"DTSTART:{self.start_datetime.strftime(fmt)}",
            f"DTEND:{self.end_datetime.strftime(fmt)}",
            f"SUMMARY:{escape(self._get_calendar_title())}",
            f"DESCRIPTION:{escape(self._get_calendar_description())}",
        ]
        location = self._get_calendar_location()
        if location:
            lines.append(f"LOCATION:{escape(location)}")
        lines += ['END:VEVENT', 'END:VCALENDAR']
        return '\r\n'.join(fold(line) for line in lines) + '\r\n'

    def action_send_email(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': {
                'default_model': 'appointment.booking',
                'default_res_ids': self.ids,
                'default_composition_mode': 'comment',
                'default_partner_ids': self.partner_id.ids if self.partner_id else [],
            },
        }

    def action_send_sms(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'sms.composer',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': {
                'default_res_model': 'appointment.booking',
                'default_res_id': self.id,
                'default_composition_mode': 'comment',
                'default_recipient_single_number_itf': self._get_recipient_phone() or False,
            },
        }

    def action_set_booked(self):
        for booking in self:
            if booking.state != 'confirmed':
                booking.state = 'confirmed'

    def action_check_in(self):
        for booking in self:
            booking.state = 'checked_in'

    def action_check_out(self):
        now = fields.Datetime.now()
        for booking in self:
            vals = {'state': 'checked_out'}
            if booking.end_datetime and booking.end_datetime > now:
                vals['end_datetime'] = now
            booking.write(vals)

    def action_no_show(self):
        if self.filtered(lambda b: b.state == 'checked_in'):
            raise UserError(_("A checked-in appointment cannot be marked as no show."))
        for booking in self:
            booking.state = 'no_show'

    def action_cancel(self):
        for booking in self:
            booking.state = 'cancelled'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._assign_available_staff(vals)
            if 'alarm_ids' not in vals and vals.get('appointment_type_id'):
                reminders = self.env['appointment.type'].browse(vals['appointment_type_id']).sudo().reminder_ids
                if reminders:
                    vals['alarm_ids'] = [(6, 0, reminders.ids)]
            if not vals.get('name') or vals.get('name') == 'New':
                seq = self.env['ir.sequence'].next_by_code('appointment.booking')
                vals['name'] = seq or 'APT/MISSING-SEQ'
                
            attendee_ids = vals.get('attendee_ids', [])
            if isinstance(attendee_ids, list) and not attendee_ids:
                partners = []
                if vals.get('partner_id'):
                    partners.append(vals['partner_id'])
                if vals.get('staff_user_id'):
                    staff = self.env['res.users'].browse(vals['staff_user_id'])
                    if staff.partner_id:
                        partners.append(staff.partner_id.id)
                if partners:
                    vals['attendee_ids'] = [(6, 0, partners)]
        
        bookings = super(AppointmentBooking, self).create(vals_list)
        bookings._sync_event_fields_from_answers()
        for booking in bookings:
            if booking.state == 'confirmed':
                booking._create_calendar_event()
        return bookings

    def write(self, vals):
        old_partners = {}
        if 'staff_user_id' in vals or 'partner_id' in vals:
            old_partners = {booking.id: booking.staff_user_id.partner_id | booking.partner_id for booking in self}
        res = super(AppointmentBooking, self).write(vals)
        if 'state' in vals and vals['state'] == 'confirmed':
            for booking in self:
                if not booking.calendar_event_id:
                    booking._create_calendar_event()
        if self._EVENT_SYNC_FIELDS & set(vals):
            self._sync_calendar_event(old_partners)
        return res

    def unlink(self):
        events = self.calendar_event_id.sudo().filtered('active')
        res = super().unlink()
        # archiving (not deleting) also removes the event from synced Google calendars
        events.exists().write({'active': False})
        return res

    _EVENT_SYNC_FIELDS = {'state', 'start_datetime', 'end_datetime', 'duration', 'staff_user_id', 'partner_id',
                          'attendee_ids', 'tag_ids', 'alarm_ids', 'notes', 'location', 'show_as', 'privacy',
                          'res_model_id', 'res_id'}

    def _get_calendar_event_details(self):
        """Values of the calendar event coming from fields edited on the booking."""
        self.ensure_one()
        details = {
            'categ_ids': [(6, 0, self.tag_ids.ids)],
            'alarm_ids': [(6, 0, self.alarm_ids.ids)],
            'notes': self.notes or False,
            'show_as': self.show_as or 'busy',
            'res_model_id': self.res_model_id.id or False,
            'res_id': self.res_id or False,
        }
        if self.privacy:
            details['privacy'] = self.privacy
        if self.location:
            details['location'] = self.location
        return details

    def _get_calendar_event_organizer(self):
        """User owning the booking's calendar event: the assigned staff member,
        else the type's responsible, else a user of the appointment type,
        never the website's public user."""
        self.ensure_one()
        if self.staff_user_id:
            return self.staff_user_id
        responsible = self.appointment_type_id.sudo().user_id
        if responsible and responsible.active and not responsible.share:
            return responsible
        type_users = self.appointment_type_id.sudo().user_ids.filtered(lambda u: not u.share)
        if type_users:
            return type_users[:1]
        if not self.env.user.share:
            return self.env.user
        return self.appointment_type_id.sudo().create_uid

    def _sync_calendar_event(self, old_partners=None):
        """Keep the calendar event (and so Google Calendar) in line with the booking.

        :param old_partners: {booking_id: res.partner} staff and customer
            partners before the write, removed from the event if replaced
        """
        old_partners = old_partners or {}
        for booking in self:
            event = booking.calendar_event_id.sudo()
            if not event:
                continue
            if booking.state == 'cancelled':
                if event.active:
                    event.write({'active': False})
                continue
            event_vals = {}
            if not event.active and booking.state in ('confirmed', 'checked_in'):
                event_vals['active'] = True
            if booking.start_datetime and booking.end_datetime and (
                    event.start != booking.start_datetime or event.stop != booking.end_datetime):
                event_vals.update({'start': booking.start_datetime, 'stop': booking.end_datetime})
            organizer = booking._get_calendar_event_organizer()
            if organizer and event.user_id != organizer:
                event_vals['user_id'] = organizer.id
            current_partners = booking.partner_id | organizer.partner_id | booking.attendee_ids
            details = booking._get_calendar_event_details()
            if event.categ_ids != booking.tag_ids:
                event_vals['categ_ids'] = details['categ_ids']
            if event.alarm_ids != booking.alarm_ids:
                event_vals['alarm_ids'] = details['alarm_ids']
            for field_name in ('notes', 'show_as', 'privacy', 'location'):
                if field_name in details and (event[field_name] or False) != details[field_name]:
                    event_vals[field_name] = details[field_name]
            if event.res_model_id != booking.res_model_id or (event.res_id or False) != (booking.res_id or False):
                event_vals.update({'res_model_id': details['res_model_id'], 'res_id': details['res_id']})
            partner_commands = []
            for partner in old_partners.get(booking.id, self.env['res.partner']) - current_partners:
                if partner in event.partner_ids:
                    partner_commands.append((3, partner.id))
            for partner in current_partners:
                if partner not in event.partner_ids:
                    partner_commands.append((4, partner.id))
            if partner_commands:
                event_vals['partner_ids'] = partner_commands
            if event_vals:
                event.write(event_vals)

    def _create_calendar_event(self):
        for booking in self:
            if not booking.calendar_event_id:
                organizer = booking._get_calendar_event_organizer()
                partner_ids = []
                if booking.partner_id:
                    partner_ids.append(booking.partner_id.id)
                if organizer.partner_id and organizer.partner_id.id not in partner_ids:
                    partner_ids.append(organizer.partner_id.id)
                
                desc = []
                desc.append("<b>Description of the event</b>")
                if booking.appointment_type_id and booking.appointment_type_id.message_intro:
                    desc.append(booking.appointment_type_id.message_intro)
                desc.append("<br/>")
                
                guest_name = booking._get_guest_display_name()
                guest_email = booking._get_recipient_email()
                guest_phone = booking._get_recipient_phone()
                if guest_name or guest_email or guest_phone:
                    desc.append("<b>Contact Details</b>")
                    if guest_name:
                        desc.append(f"{guest_name}")
                    if guest_email:
                        desc.append(f"<a href='mailto:{guest_email}'>{guest_email}</a>")
                    if guest_phone:
                        desc.append(f"<a href='tel:{guest_phone}'>{guest_phone}</a>")

                if booking.celebrant_name:
                    desc.append(f"<b>Celebrant / Honoree:</b> {booking.celebrant_name}")
                if booking.occasion_title:
                    desc.append(f"<b>Occasion:</b> {booking.occasion_title}")
                if booking.occasion_date:
                    desc.append(f"<b>Special Day:</b> {booking.occasion_date.strftime('%Y-%m-%d')}")

                if booking.answer_ids:
                    for answer in booking.answer_ids:
                        ans_val = answer.value_date.strftime('%Y-%m-%d') if answer.value_date else (answer.value_text or '')
                        desc.append(f"<br/>{answer.question_id.name} -<br/>{ans_val}")
                elif booking.guest_details:
                    desc.append("<br/>" + booking.guest_details.replace('\n', '<br/>'))
                    
                description_html = "<br/>".join(desc)
                
                event_vals = {
                    'name': booking.subject or booking.name or booking.appointment_type_id.name,
                    'start': booking.start_datetime,
                    'stop': booking.end_datetime,
                    'allday': False,
                    'partner_ids': [(6, 0, partner_ids)],
                    'user_id': organizer.id or self.env.user.id,
                    'description': description_html,
                }
                for partner in booking.attendee_ids:
                    if partner.id not in partner_ids:
                        event_vals['partner_ids'][0][2].append(partner.id)
                event_vals.update(booking._get_calendar_event_details())
                appointment_type = booking.appointment_type_id
                # Google only adds a Meet link to events without a location,
                # so a physical location is set only when Meet is not wanted.
                if ('location' not in event_vals and appointment_type.video_link != 'meet'
                        and appointment_type.location in ('office', 'custom')
                        and appointment_type.location_details):
                    event_vals['location'] = appointment_type.location_details
                event = self.env['calendar.event'].sudo().create(event_vals)
                if appointment_type.video_link == 'discuss':
                    event._set_discuss_videocall_location()
                booking_vals = {'calendar_event_id': event.id}
                if event.videocall_location:
                    booking_vals['videocall_location'] = event.videocall_location
                booking.write(booking_vals)

    # ------------------------------------------------------------------
    # Confirmation Notifications & Next-Year Celebration Wishes
    # ------------------------------------------------------------------

    def _format_booking_confirmation_sms(self):
        self.ensure_one()
        guest_name = self._get_guest_display_name() or _("Guest")
        appt = self.appointment_type_id
        company = self.company_id or appt.company_id or self.env.company
        tz_name = appt.appointment_tz or company.partner_id.tz or self.env.user.tz or 'Asia/Calcutta'
        try:
            tz = pytz.timezone(tz_name)
        except Exception:
            tz = pytz.UTC
        start_local = ''
        if self.start_datetime:
            utc_dt = pytz.UTC.localize(self.start_datetime) if not self.start_datetime.tzinfo else self.start_datetime.astimezone(pytz.UTC)
            start_local = utc_dt.astimezone(tz).strftime('%d %b %Y, %I:%M %p')
        emoji = f"{appt.event_emoji} " if appt.event_emoji else ""
        manage_url = f"{self.get_base_url()}/appointment/manage/{self.id}?token={self.access_token}"
        parts = [
            f"Hi {guest_name}, your {emoji}{appt.name} at {company.name} is confirmed for {start_local} ({self.party_size or 1} guests)."
        ]
        if self.celebrant_name:
            parts.append(f"Celebrant: {self.celebrant_name}.")
        if self.occasion_title:
            parts.append(f"Occasion: {self.occasion_title}.")
        parts.append(f"Manage booking: {manage_url}")
        return " ".join(parts)

    def _send_booking_confirmation_notifications(self):
        mail_template_fallback = self.env.ref('appointment.email_template_booking_confirmation', raise_if_not_found=False)
        for booking in self.sudo():
            if booking.confirmation_sent or booking.state not in ('confirmed', 'checked_in'):
                continue
            if not booking.access_token:
                booking.with_context(skip_event_sync=True).write({'access_token': str(uuid.uuid4())})
            template = booking.appointment_type_id.booking_template_id or mail_template_fallback
            email = booking._get_recipient_email()
            if template and email:
                try:
                    with self.env.cr.savepoint():
                        template.sudo().send_mail(booking.id, force_send=False)
                except Exception:
                    _logger.exception("Booking confirmation email failed for booking %s", booking.id)

            phone = booking._get_recipient_phone()
            if phone:
                try:
                    with self.env.cr.savepoint():
                        sms_body = booking._format_booking_confirmation_sms()
                        booking.sudo()._message_sms(
                            sms_body,
                            partner_ids=[],
                            sms_numbers=[phone],
                            sms_content=sms_body,
                            put_in_queue=True,
                            sms_type='alert',
                        )
                except Exception:
                    _logger.exception("Booking confirmation SMS failed for booking %s", booking.id)

            booking.with_context(skip_event_sync=True).write({'confirmation_sent': True})

    def _get_celebration_wish_booking_url(self):
        self.ensure_one()
        if not self.access_token:
            self.with_context(skip_event_sync=True).write({'access_token': str(uuid.uuid4())})
        base_url = self.get_base_url()
        query = urlencode({
            'wish_ref': self.id,
            'wish_token': self.access_token,
        })
        return f"{base_url}/appointment/{self.appointment_type_id.id}?{query}"

    @api.model
    def _get_anniversary_date_for_year(self, occ_date, year):
        if not occ_date or not year:
            return False
        max_day = calendar.monthrange(year, occ_date.month)[1]
        return date(year, occ_date.month, min(occ_date.day, max_day))

    def _format_celebration_wish_message(self, kind='day', target_year=None):
        self.ensure_one()
        appt = self.appointment_type_id
        company = self.company_id or appt.company_id or self.env.company
        guest_name = self._get_guest_display_name() or _("Guest")
        celebrant_name = (self.celebrant_name or '').strip() or guest_name
        occasion_title = (self.occasion_title or '').strip() or appt.name
        if self.occasion_date:
            yr = target_year or self.occasion_date.year
            anniv = self._get_anniversary_date_for_year(self.occasion_date, yr)
            special_day_str = anniv.strftime('%d %b %Y') if anniv else ''
        else:
            special_day_str = ''
        booking_url = self._get_celebration_wish_booking_url()
        emoji_prefix = f"{appt.event_emoji} " if appt.event_emoji else ""

        if kind == 'advance':
            raw_tpl = (appt.wish_advance_sms_text or '').strip() or (
                "Hi {guest_name}! {celebrant_name}'s {event_name} celebration is coming up on {special_day}. "
                "Reserve a table with us at {company_name}! Grab a party here: {booking_url}"
            )
        else:
            raw_tpl = (appt.wish_day_sms_text or '').strip() or (
                "Happy celebration wishes for {celebrant_name}'s {event_name} from {company_name}! "
                "Celebrate with family & friends — Grab a party here: {booking_url}"
            )

        tokens = {
            'guest_name': guest_name,
            'celebrant_name': celebrant_name,
            'event_name': f"{emoji_prefix}{appt.name}".strip(),
            'occasion_title': occasion_title,
            'special_day': special_day_str,
            'company_name': company.name or '',
            'booking_url': booking_url,
        }
        pattern = re.compile(r'\{(' + '|'.join(re.escape(k) for k in tokens.keys()) + r')\}')
        return pattern.sub(lambda m: tokens[m.group(1)], raw_tpl)

    def _send_celebration_wish(self, kind='day', target_year=None):
        self.ensure_one()
        booking = self.sudo()
        if not booking.access_token:
            booking.with_context(skip_event_sync=True).write({'access_token': str(uuid.uuid4())})

        sent_email = False
        sent_sms = False
        email = booking._get_recipient_email()
        if email:
            if kind == 'advance':
                template = (
                    booking.appointment_type_id.wish_advance_email_template_id
                    or self.env.ref('appointment.email_template_celebration_advance', raise_if_not_found=False)
                )
            else:
                template = (
                    booking.appointment_type_id.wish_day_email_template_id
                    or self.env.ref('appointment.email_template_celebration_day', raise_if_not_found=False)
                )
            if template:
                try:
                    with self.env.cr.savepoint():
                        template.sudo().with_context(
                            wish_kind=kind,
                            wish_target_year=target_year,
                        ).send_mail(booking.id, force_send=False)
                    sent_email = True
                except Exception:
                    _logger.exception("Celebration wish email (%s) failed for booking %s", kind, booking.id)

        phone = booking._get_recipient_phone()
        if phone:
            try:
                with self.env.cr.savepoint():
                    sms_body = booking._format_celebration_wish_message(kind=kind, target_year=target_year)
                    booking._message_sms(
                        sms_body,
                        partner_ids=[],
                        sms_numbers=[phone],
                        sms_content=sms_body,
                        put_in_queue=True,
                        sms_type='alert',
                    )
                sent_sms = True
            except Exception:
                _logger.exception("Celebration wish SMS (%s) failed for booking %s", kind, booking.id)

        sent_any = bool(sent_email or sent_sms)
        if sent_any and target_year:
            field_name = 'wish_last_advance_year' if kind == 'advance' else 'wish_last_day_year'
            if booking[field_name] < target_year:
                booking.with_context(skip_event_sync=True).write({field_name: target_year})
        return {'sent': sent_any, 'email': sent_email, 'sms': sent_sms}

    def action_send_celebration_wish(self):
        self.ensure_one()
        if not self._get_recipient_email() and not self._get_recipient_phone():
            raise UserError(_("Please set a guest phone number or email address before sending celebration wishes."))
        appt = self.appointment_type_id
        kind = 'day' if appt.wish_send_on_day or not appt.wish_send_advance_invite else 'advance'
        target_year = fields.Date.context_today(self).year
        res = self._send_celebration_wish(kind=kind, target_year=target_year)
        if not res['sent']:
            raise UserError(_("No celebration wish could be queued. Check email/phone details and templates."))
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Celebration Wish Queued'),
                'message': _('Email / SMS celebration wish has been queued for %s.') % (self._get_guest_display_name() or self.name),
                'type': 'success',
                'sticky': False,
            },
        }

    @api.model
    def _cron_send_celebration_wishes(self, reference_date=None):
        """Daily job to send next-year pre-celebration invites (T-N days) and/or Special Day wishes."""
        explicit_ref_date = fields.Date.to_date(reference_date) if reference_date else False
        now_utc = fields.Datetime.now()
        bookings = self.sudo().search([
            ('state', 'in', ('confirmed', 'checked_in', 'checked_out')),
            ('occasion_date', '!=', False),
            ('appointment_type_id.enable_anniversary_wishes', '=', True),
        ])
        email_queued = False
        stats = {'advance_sent': 0, 'day_sent': 0}

        for booking in bookings:
            appt = booking.appointment_type_id
            company = booking.company_id or appt.company_id or self.env.company
            tz_name = appt.appointment_tz or company.partner_id.tz or self.env.user.tz or 'Asia/Calcutta'
            try:
                tz = pytz.timezone(tz_name)
            except Exception:
                tz = pytz.UTC

            if explicit_ref_date:
                today_local = explicit_ref_date
            else:
                utc_now = pytz.UTC.localize(now_utc) if not now_utc.tzinfo else now_utc.astimezone(pytz.UTC)
                today_local = utc_now.astimezone(tz).date()

            booked_ref = booking.start_datetime or booking.create_date or now_utc
            booked_utc = pytz.UTC.localize(booked_ref) if not booked_ref.tzinfo else booked_ref.astimezone(pytz.UTC)
            booked_local_date = booked_utc.astimezone(tz).date()

            occ_date = booking.occasion_date
            if not occ_date:
                continue

            # 1. Advance invite (T - wish_advance_days)
            if appt.wish_send_advance_invite:
                adv_days = appt.wish_advance_days or 0
                if adv_days >= 1:
                    target_anniv = today_local + timedelta(days=adv_days)
                    target_year = target_anniv.year
                    expected_anniv = self._get_anniversary_date_for_year(occ_date, target_year)
                    if (
                        expected_anniv == target_anniv
                        and target_year > booked_local_date.year
                        and (target_anniv - booked_local_date).days >= 14
                        and booking.wish_last_advance_year < target_year
                    ):
                        res = booking._send_celebration_wish(kind='advance', target_year=target_year)
                        if res['sent']:
                            stats['advance_sent'] += 1
                        if res['email']:
                            email_queued = True

            # 2. On Special Day wish (exact anniversary date)
            if appt.wish_send_on_day:
                target_year = today_local.year
                expected_anniv = self._get_anniversary_date_for_year(occ_date, target_year)
                if (
                    expected_anniv == today_local
                    and target_year > booked_local_date.year
                    and (today_local - booked_local_date).days >= 14
                    and booking.wish_last_day_year < target_year
                ):
                    res = booking._send_celebration_wish(kind='day', target_year=target_year)
                    if res['sent']:
                        stats['day_sent'] += 1
                    if res['email']:
                        email_queued = True

        if email_queued:
            mail_queue = self.env.ref('mail.ir_cron_mail_scheduler_action', raise_if_not_found=False)
            if mail_queue:
                mail_queue._trigger()
        return stats
