# pyrefly: ignore [missing-import]
from odoo import models, fields


class CalendarEvent(models.Model):
    _inherit = 'calendar.event'

    appointment_booking_ids = fields.One2many(
        'appointment.booking', 'calendar_event_id', string='Appointment Bookings')
