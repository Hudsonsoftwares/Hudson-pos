# pyrefly: ignore [missing-import]
from odoo import models, fields, api

class AppointmentQuestion(models.Model):
    _name = 'appointment.question'
    _description = 'Appointment Question'
    _order = 'sequence, id'
    _check_company_auto = True

    sequence = fields.Integer('Sequence', default=10)
    name = fields.Char('Question', required=True, translate=True)
    company_id = fields.Many2one(
        'res.company', string='Company', index=True,
        default=lambda self: self.env.company,
        help="Leave empty to share this question between all companies.")
    appointment_type_ids = fields.Many2many(
        'appointment.type', 'appointment_type_question_rel',
        'question_id', 'appointment_type_id',
        string='Appointment Types', check_company=True,
    )
    
    question_type = fields.Selection([
        ('char', 'Single line text'),
        ('text', 'Multi-line text'),
        ('phone', 'Phone Number'),
        ('date', 'Date'),
        ('select', 'Dropdown (one answer)'),
        ('radio', 'Radio (one answer)'),
        ('checkbox', 'Checkboxes (multiple answers)'),
    ], string='Question Type', required=True, default='char')

    question_role = fields.Selection([
        ('none', 'Standard Question'),
        ('celebrant_name', 'Celebrant / Honoree Name'),
        ('occasion_title', 'Occasion / Celebration Details'),
        ('occasion_date', 'Special Day / Anniversary Date'),
    ], string='Celebration Field Mapping', default='none', required=True,
       help="Maps answers on the website booking form to structured Celebration fields used for yearly wishes.")
    is_occasion_date = fields.Boolean(
        'Is Special Day / Occasion Date', default=False,
        help="Mark this Date question as the Special Day used to schedule next-year celebration wishes.")

    is_required = fields.Boolean('Mandatory Answer', default=False)
    is_reusable = fields.Boolean('Is Reusable', default=False)
    default_question = fields.Boolean('Default question', default=False)
    placeholder = fields.Char('Placeholder', help="Displayed when the field is empty")
    extra_comments = fields.Text('Extra comments')
    answer_ids = fields.One2many('appointment.question.answer', 'question_id', string='Answers')
    
    appointment_usage_count = fields.Integer('Usage Count', compute='_compute_appointment_usage_count')

    @api.onchange('question_role')
    def _onchange_question_role(self):
        for question in self:
            question.is_occasion_date = (question.question_role == 'occasion_date')

    @api.onchange('is_occasion_date')
    def _onchange_is_occasion_date(self):
        for question in self:
            if question.is_occasion_date:
                question.question_role = 'occasion_date'
            elif question.question_role == 'occasion_date':
                question.question_role = 'none'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if 'question_role' in vals and 'is_occasion_date' not in vals:
                vals['is_occasion_date'] = (vals['question_role'] == 'occasion_date')
            elif vals.get('is_occasion_date') and 'question_role' not in vals:
                vals['question_role'] = 'occasion_date'
        return super().create(vals_list)

    def write(self, vals):
        if 'question_role' in vals and 'is_occasion_date' not in vals:
            vals = dict(vals, is_occasion_date=(vals['question_role'] == 'occasion_date'))
        elif 'is_occasion_date' in vals and 'question_role' not in vals:
            vals = dict(vals)
            if vals['is_occasion_date']:
                vals['question_role'] = 'occasion_date'
            else:
                res = True
                for question in self:
                    per_vals = dict(vals)
                    if question.question_role == 'occasion_date':
                        per_vals['question_role'] = 'none'
                    res = super(AppointmentQuestion, question).write(per_vals) and res
                return res
        return super().write(vals)

    @api.depends('answer_ids')
    def _compute_appointment_usage_count(self):
        for question in self:
            question.appointment_usage_count = 0
            
        if self.ids:
            answer_data = self.env['appointment.answer']._read_group(
                [('question_id', 'in', self.ids)],
                ['question_id'],
                ['__count']
            )
            mapped_data = {q.id: count for q, count in answer_data}
            for question in self:
                question.appointment_usage_count = mapped_data.get(question.id, 0)

    def action_view_answers(self):
        self.ensure_one()
        return {
            'name': 'Answer Breakdown',
            'type': 'ir.actions.act_window',
            'res_model': 'appointment.answer',
            'view_mode': 'list',
            'domain': [('question_id', '=', self.id)],
            'context': {
                'default_question_id': self.id,
                'search_default_question_id': self.id,
            },
        }

class AppointmentQuestionAnswer(models.Model):
    _name = 'appointment.question.answer'
    _description = 'Appointment Question Answer'
    _order = 'sequence, id'

    sequence = fields.Integer('Sequence', default=10)
    name = fields.Char('Answer', required=True, translate=True)
    question_id = fields.Many2one('appointment.question', ondelete='cascade', required=True)

