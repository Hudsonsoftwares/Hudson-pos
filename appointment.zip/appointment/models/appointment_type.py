# pyrefly: ignore [missing-import]
from odoo import models, fields, api, _
# pyrefly: ignore [missing-import]
from odoo.exceptions import ValidationError

class AppointmentType(models.Model):
    _name = 'appointment.type'
    _description = 'Appointment Type'
    _inherit = ['mail.thread', 'website.published.mixin', 'image.mixin']
    _check_company_auto = True

    name = fields.Char(string='Name', required=True, translate=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        'res.company', string='Company', index=True,
        default=lambda self: self.env.company,
        help="Leave empty to share this appointment type between all companies.")
    appointment_duration = fields.Float('Duration', default=1.0, required=True, help="Duration in hours")
    location = fields.Selection([
        ('office', 'Office'),
        ('online', 'Online Meeting'),
        ('custom', 'Custom Location')
    ], string='Location', default='online', help="Location of the appointments")
    location_details = fields.Char("Location Details", help="Enter the custom location address or details")
    video_link = fields.Selection([
        ('none', 'None'),
        ('discuss', 'Odoo Discuss'),
        ('meet', 'Google Meet')
    ], string='Video Link', default='none', help="Link for the video conference")
    @api.depends('name')
    def _compute_website_url(self):
        for appointment_type in self:
            appointment_type.website_url = f'/appointment/{appointment_type.id}'
            

    availability_ids = fields.One2many('appointment.availability', 'appointment_type_id', string='Availabilities')
    flexible_slot_ids = fields.One2many('appointment.slot', 'appointment_type_id', string='Slots',
                                        help="Bookable slots of the \"Flexible\" schedule.")
    
    # Booking targets
    booking_target = fields.Selection([
        ('users', 'Users'),
        ('resources', 'Resources')
    ], string='Book', default='users', required=True)
    
    user_ids = fields.Many2many('res.users', string='Users', default=lambda self: self.env.user, check_company=True)
    user_id = fields.Many2one(
        'res.users', string='Responsible', index=True, tracking=True, check_company=True,
        domain="[('share', '=', False)]",
        # the system user (e.g. during module upgrades) is never a sensible responsible
        default=lambda self: self.env.user if not self.env.user._is_superuser() else False,
        help="Person in charge of this appointment type. Organizer of the meetings booked without a "
             "staff member (e.g. resource bookings) and salesperson of the opportunities they create.")
    resource_ids = fields.Many2many('appointment.resource', string='Resources', check_company=True)
    
    assign_method = fields.Selection([
        ('random', 'Automatically'),
        ('customer', 'By visitor')
    ], string='Assign', default='random')
    
    schedule_based_on = fields.Selection([
        ('website', 'Date'),
        ('users', 'User / Resource')
    ], string='Starts with', default='website', required=True)
    
    group_booking = fields.Boolean('Group Bookings', help="Allow multiple people to book the same time slot")
    capacity = fields.Integer('Up to', default=1, help="Maximum number of simultaneous appointments per user/resource")
    appointment_count = fields.Integer(compute='_compute_appointment_count')
    resource_count = fields.Integer(compute='_compute_appointment_count')

    appointment_tz = fields.Selection('_tz_get', string='Timezone', default=lambda self: self.env.user.tz or self.env.company.partner_id.tz or 'Asia/Calcutta')
    country_ids = fields.Many2many('res.country', string='Allowed Countries')

    @api.model
    def _tz_get(self):
        import pytz
        return [(x, x) for x in pytz.all_timezones]

    @api.depends('resource_ids')
    def _compute_appointment_count(self):
        for record in self:
            record.appointment_count = 0
            record.resource_count = len(record.resource_ids)
            
        if self.ids:
            appointment_data = self.env['appointment.booking']._read_group(
                [
                    ('appointment_type_id', 'in', self.ids),
                    ('start_datetime', '>=', fields.Datetime.now()),
                    ('state', 'in', ['confirmed', 'checked_in'])
                ],
                ['appointment_type_id'],
                ['__count']
            )
            mapped_data = {app_type.id: count for app_type, count in appointment_data}
            for record in self:
                record.appointment_count = mapped_data.get(record.id, 0)

    resource_total_capacity = fields.Integer(compute='_compute_resource_total_capacity')

    @api.depends('resource_ids', 'resource_ids.capacity')
    def _compute_resource_total_capacity(self):
        for record in self:
            record.resource_total_capacity = sum(record.resource_ids.mapped('capacity'))

    has_multiple_targets = fields.Boolean(compute='_compute_has_multiple_targets')

    @api.depends('user_ids', 'resource_ids')
    def _compute_has_multiple_targets(self):
        for record in self:
            if record.booking_target == 'resources':
                record.has_multiple_targets = len(record.resource_ids) > 1
            else:
                record.has_multiple_targets = len(record.user_ids) > 1

    def action_view_resources(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Resources',
            'res_model': 'appointment.resource',
            'view_mode': 'list,form',
            'domain': [('id', 'in', self.resource_ids.ids)],
            'context': {
                'default_appointment_type_ids': [(4, self.id)],
                'default_company_id': self.company_id.id,
            },
        }


    def action_preview(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/appointment/{self.id}?preview=True',
            'target': 'self',
        }

    def action_open_bookings(self):
        self.ensure_one()
        # Schedule (Gantt-like) view: one row per resource or per staff member
        schedule_view = self.env.ref(
            'appointment.appointment_booking_view_schedule_resource' if self.booking_target == 'resources'
            else 'appointment.appointment_booking_view_schedule_staff', raise_if_not_found=False)
        # the Schedule opens first, then Calendar / List / Form as before
        views = [(False, 'calendar'), (False, 'list'), (False, 'form')]
        if schedule_view:
            views.insert(0, (schedule_view.id, 'appointment_schedule'))
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Staff Bookings',
            'res_model': 'appointment.booking',
            'view_mode': ','.join(view_type for _view_id, view_type in views),
            'views': views,
            'domain': [('appointment_type_id', '=', self.id)],
            'context': {
                'default_appointment_type_id': self.id,
            },
        }
        return action

    def action_open_form(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Configure Appointment Type',
            'res_model': 'appointment.type',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_share(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Create a Share Link',
            'res_model': 'appointment.invite',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_appointment_type_ids': [(4, self.id)],
                'default_company_id': self.company_id.id,
            },
        }

    google_calendar_connected = fields.Boolean(compute='_compute_google_calendar_connected')

    @api.depends_context('uid')
    def _compute_google_calendar_connected(self):
        user = self.env.user.sudo()
        connected = bool(user.google_calendar_rtoken) and not user.google_synchronization_stopped
        for appointment_type in self:
            appointment_type.google_calendar_connected = connected

    def _get_busy_intervals_by_user(self, users, start_utc, end_utc):
        """Busy time of ``users`` from their calendar events (incl. events synced
        from Google) between naive-UTC ``start_utc`` and ``end_utc``.

        Events created for appointment bookings are ignored: bookings are
        already counted, with their capacity rules, by the booking checks.

        :return: {user_id: [(start, stop), ...]} with naive UTC datetimes
        """
        self.ensure_one()
        import pytz
        from datetime import datetime, time, timedelta

        busy = {user.id: [] for user in users}
        if not users:
            return busy
        user_by_partner = {user.partner_id.id: user.id for user in users if user.partner_id}
        events = self.env['calendar.event'].sudo().search([
            '|', ('partner_ids', 'in', list(user_by_partner)), ('user_id', 'in', users.ids),
            ('show_as', '=', 'busy'),
            ('appointment_booking_ids', '=', False),
            # all-day events are stored with day hours, widen to catch them
            ('start', '<', end_utc + timedelta(days=1)),
            ('stop', '>', start_utc - timedelta(days=1)),
        ])
        tz = pytz.timezone(self.appointment_tz or self.company_id.partner_id.tz or self.env.user.tz or 'Asia/Calcutta')
        for event in events:
            if event.allday:
                if not event.start_date or not event.stop_date:
                    continue
                ev_start = tz.localize(datetime.combine(event.start_date, time.min))
                ev_stop = tz.localize(datetime.combine(event.stop_date + timedelta(days=1), time.min))
                ev_start = ev_start.astimezone(pytz.UTC).replace(tzinfo=None)
                ev_stop = ev_stop.astimezone(pytz.UTC).replace(tzinfo=None)
            else:
                ev_start, ev_stop = event.start, event.stop
            if not (ev_start < end_utc and ev_stop > start_utc):
                continue
            declined_partners = event.attendee_ids.filtered(lambda a: a.state == 'declined').partner_id
            busy_user_ids = {user_by_partner[p.id] for p in event.partner_ids - declined_partners if p.id in user_by_partner}
            if event.user_id.id in busy and event.user_id.partner_id not in declined_partners:
                busy_user_ids.add(event.user_id.id)
            for user_id in busy_user_ids:
                busy[user_id].append((ev_start, ev_stop))
        return busy

    def _get_closing_day_domain(self, users=None, resources=None):
        """Domain of the closing days applying to this type: its own closing
        days, company-wide ones, and those of ``users`` / ``resources``
        (by default the type's users and resources)."""
        self.ensure_one()
        appointment_type = self.sudo()
        users = appointment_type.user_ids if users is None else users
        resources = appointment_type.resource_ids if resources is None else resources
        return [
            '|', '|',
            '&', ('closing_type', '=', 'appointments'),
                 '|', ('appointment_type_ids', 'in', appointment_type.ids),
                      '&', ('appointment_type_ids', '=', False),
                           ('company_id', 'in', [False, appointment_type.company_id.id]),
            '&', ('closing_type', '=', 'resources'), ('resource_id', 'in', resources.ids),
            '&', ('closing_type', '=', 'users'), ('user_id', 'in', users.ids),
        ]

    def _get_closing_periods(self):
        """Periods closed by closing days, like Odoo: exactly from the start to
        the end datetime of each closing day.

        - "Appointments" closing days close this type: the ones listing it,
          or, when they list no type, every type of their company.
        - "Resources" / "Users" closing days only make that resource / user
          unavailable; the other resources / users stay bookable.

        :return: (type_periods, periods_by_user_id, periods_by_resource_id),
            lists of (start, stop) naive UTC datetimes
        """
        self.ensure_one()
        closings = self.env['appointment.closing.day'].sudo().search(self._get_closing_day_domain())
        type_periods = []
        periods_by_user = {}
        periods_by_resource = {}
        for closing in closings:
            if not closing.start_datetime or not closing.end_datetime or closing.end_datetime <= closing.start_datetime:
                continue
            period = (closing.start_datetime, closing.end_datetime)
            if closing.closing_type == 'resources':
                periods_by_resource.setdefault(closing.resource_id.id, []).append(period)
            elif closing.closing_type == 'users':
                periods_by_user.setdefault(closing.user_id.id, []).append(period)
            else:
                type_periods.append(period)
        return type_periods, periods_by_user, periods_by_resource

    def _period_overlaps(self, start, stop, periods):
        """Whether [start, stop) overlaps one of the (start, stop) ``periods``."""
        return any(p_start < stop and p_stop > start for p_start, p_stop in periods)

    def _get_open_hours_utc(self, day):
        """Opening hours of this type on local date ``day`` as naive UTC
        (start, stop) spans: its availability rows, the whole day with
        Employee Schedule and no rows, else the default 9:00-17:00."""
        self.ensure_one()
        import pytz
        from datetime import datetime, time, timedelta

        tz = pytz.timezone(self.appointment_tz or self.company_id.partner_id.tz or self.env.user.tz or 'Asia/Calcutta')
        midnight = datetime.combine(day, time.min)
        if self.schedule_type == 'flexible':
            # the slots starting that day
            return [period for period in self._get_flexible_periods()
                    if pytz.UTC.localize(period[0]).astimezone(tz).date() == day]
        if self.availability_ids:
            hours = [(row.start_time, row.end_time) for row in self.availability_ids
                     if row.day_of_week == str(day.weekday())]
        elif self.employee_schedule:
            hours = [(0.0, 24.0)]
        else:
            hours = [(9.0, 17.0)]
        spans = []
        for from_h, to_h in hours:
            span_start = tz.localize(midnight + timedelta(hours=from_h)).astimezone(pytz.UTC).replace(tzinfo=None)
            span_stop = tz.localize(midnight + timedelta(hours=to_h)).astimezone(pytz.UTC).replace(tzinfo=None)
            if span_stop > span_start:
                spans.append((span_start, span_stop))
        return spans

    def _is_day_closed(self, day, periods):
        """Whether closing ``periods`` cover all the opening hours of local date ``day``."""
        spans = self._get_open_hours_utc(day)
        if not spans or not periods:
            return False
        merged = []
        for p_start, p_stop in sorted(periods):
            if merged and p_start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], p_stop)
            else:
                merged.append([p_start, p_stop])
        return all(any(m_start <= span_start and span_stop <= m_stop for m_start, m_stop in merged)
                   for span_start, span_stop in spans)

    def _get_duration_label(self):
        """Duration shown on the website, e.g. "1 hour", "2 hours", "30 minutes"."""
        self.ensure_one()
        if self.schedule_type == 'flexible':
            return _("Flexible")
        minutes = int(round((self.appointment_duration or 0) * 60))
        hours, minutes = divmod(minutes, 60)
        if hours and minutes:
            return _("%(hours)s h %(minutes)s min", hours=hours, minutes=minutes)
        if hours:
            return _("1 hour") if hours == 1 else _("%s hours", hours)
        return _("1 minute") if minutes == 1 else _("%s minutes", minutes)

    def _get_location_label(self):
        """Where the appointment takes place, as shown on the website."""
        self.ensure_one()
        if self.booking_target != 'resources' and self.location == 'online':
            return _("Online")
        company = self.company_id or self.env.company
        return self.location_details or company.name or _("Office")

    def _get_flexible_periods(self):
        """(start, end) naive UTC of the slots of the "Flexible" schedule."""
        self.ensure_one()
        return [slot._get_period_utc() for slot in self.sudo().flexible_slot_ids]

    def _get_availability_intervals(self, start, end):
        """Opening hours of this appointment type (its availability rows, in the
        appointment timezone) between aware datetimes ``start`` and ``end``.
        Without availability rows the whole period is open."""
        self.ensure_one()
        from datetime import datetime, time, timedelta
        from zoneinfo import ZoneInfo
        from odoo.tools.intervals import Intervals

        no_attendance = self.env['resource.calendar.attendance']
        if self.schedule_type == 'flexible':
            from datetime import timezone
            return Intervals([
                (period_start.replace(tzinfo=timezone.utc), period_end.replace(tzinfo=timezone.utc), no_attendance)
                for period_start, period_end in self._get_flexible_periods()
            ]) & Intervals([(start, end, no_attendance)])
        if not self.availability_ids:
            return Intervals([(start, end, no_attendance)])
        tz = ZoneInfo(self.appointment_tz or self.company_id.partner_id.tz or self.env.user.tz or 'Asia/Calcutta')
        rows_by_dow = {}
        for row in self.availability_ids:
            rows_by_dow.setdefault(row.day_of_week, []).append(row)
        intervals = []
        day = start.astimezone(tz).date() - timedelta(days=1)
        last_day = end.astimezone(tz).date() + timedelta(days=1)
        while day <= last_day:
            midnight = datetime.combine(day, time.min)
            for row in rows_by_dow.get(str(day.weekday()), []):
                row_start = (midnight + timedelta(hours=row.start_time)).replace(tzinfo=tz)
                row_end = (midnight + timedelta(hours=row.end_time)).replace(tzinfo=tz)
                intervals.append((row_start, row_end, no_attendance))
            day += timedelta(days=1)
        return Intervals(intervals) & Intervals([(start, end, no_attendance)])

    def _get_employee_available_windows(self, users, start_utc, end_utc):
        """Periods in which each user can take this appointment according to
        their employee working schedule ("Employee Schedule" option).

        Uses Odoo's own working time computation, so contract versions, dated
        and recurring work lines, timezones and time off (company holidays,
        "counts as working time" leaves) are respected. Duration-based and
        flexible schedules have no fixed hours: such a working day is open
        all day. The result is limited to the type's availability rows.

        :param users: res.users recordset
        :param start_utc, end_utc: naive UTC datetimes
        :return: {user_id: [(start, stop), ...]} naive UTC datetimes; users
            without an employee have no availability
        """
        self.ensure_one()
        from datetime import datetime, time, timedelta, timezone
        from odoo.tools.intervals import Intervals

        result = {user.id: [] for user in users}
        if not users or 'hr.employee' not in self.env:
            return result
        start = start_utc.replace(tzinfo=timezone.utc)
        end = end_utc.replace(tzinfo=timezone.utc)
        if end <= start:
            return result

        # a user may have one employee per company: prefer the appointment's company
        employees = self.env['hr.employee'].sudo().search([('user_id', 'in', users.ids)])
        employee_by_user = {}
        for user in users:
            user_employees = employees.filtered(lambda e: e.user_id == user)
            employee = (
                user_employees.filtered(lambda e: self.company_id and e.company_id == self.company_id)[:1]
                or user_employees.filtered(lambda e: e.company_id == user.company_id)[:1]
                or user_employees[:1]
            )
            if employee.resource_id:
                employee_by_user[user.id] = employee
        if not employee_by_user:
            return result

        no_attendance = self.env['resource.calendar.attendance']
        whole_period = Intervals([(start, end, no_attendance)])
        availability = self._get_availability_intervals(start, end)
        resources = self.env['resource.resource'].sudo().browse(
            [employee.resource_id.id for employee in employee_by_user.values()])
        validity_per_resource = resources._get_calendars_validity_within_period(start, end)

        for user_id, employee in employee_by_user.items():
            resource = employee.resource_id.sudo()
            resources_per_tz = resource._get_resources_per_tz()
            work = Intervals()
            for calendar, validity in validity_per_resource[resource.id].items():
                calendar = calendar.sudo() if calendar else self.env['resource.calendar'].sudo()
                if not calendar or calendar._is_flexible():
                    attendances = whole_period
                else:
                    attendances = Intervals()
                    for att_start, att_stop, att_records in calendar._attendance_intervals_batch(
                            start, end, resources_per_tz)[resource.id]:
                        if att_records and all(att_records.mapped('duration_based')):
                            # only a number of hours is set for the day: open all day
                            day_start = datetime.combine(att_start.date(), time.min, tzinfo=att_start.tzinfo)
                            attendances |= Intervals([(day_start, day_start + timedelta(days=1), no_attendance)])
                        else:
                            attendances |= Intervals([(att_start, att_stop, no_attendance)])
                    attendances &= whole_period
                leaves = calendar._leave_intervals_batch(start, end, resources_per_tz)[resource.id]
                work |= (attendances - leaves) & Intervals(
                    [(s, e, no_attendance) for s, e, _records in validity])
            result[user_id] = [
                (s.astimezone(timezone.utc).replace(tzinfo=None), e.astimezone(timezone.utc).replace(tzinfo=None))
                for s, e, _records in (work & availability)
            ]
        return result

    def action_connect_google(self):
        self.ensure_one()
        try:
            # pyrefly: ignore [missing-import]
            from odoo.addons.google_calendar.utils.google_calendar_service import GoogleCalendarService
        except ImportError:
            return True

        base_url = self.env['ir.config_parameter'].sudo().get_str('web.base.url', False)
        google_service = self.env['google.service'].with_context(base_url=base_url)
        GoogleCal = GoogleCalendarService(google_service)

        client_id = google_service._get_client_id('calendar')
        if not client_id:
            if self.env.user.has_group('base.group_system'):
                return {
                    'name': _('Settings'),
                    'type': 'ir.actions.act_url',
                    'url': '/odoo/settings#sync_google_calendar_setting',
                    'target': 'self',
                }
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Google Calendar'),
                    'message': _('An administrator needs to configure Google Calendar synchronization before you can use it.'),
                    'type': 'warning',
                    'sticky': False,
                },
            }

        if not GoogleCal.is_authorized(self.env.user):
            # Google sends the user back to the Calendar app, which finishes the
            # connection (restarts a stopped sync) and runs the first sync.
            url = GoogleCal._google_authentication_url(from_url='/odoo/calendar')
            return {
                'type': 'ir.actions.act_url',
                'url': url,
                'target': 'self',
            }

        # Already connected: the Calendar app runs the synchronization itself,
        # with its own error, pause and stop handling.
        return self.env['ir.actions.act_window']._for_xml_id('calendar.action_calendar_event')

    # Phase 5 Fields
    # Questions Tab
    question_ids = fields.Many2many(
        'appointment.question', 'appointment_type_question_rel',
        'appointment_type_id', 'question_id',
        string='Questions', check_company=True,
    )
    
    # Communication Tab
    message_intro = fields.Html('Introduction Message', translate=True)
    message_confirmation = fields.Html('Confirmation Message', translate=True)
    reminder_ids = fields.Many2many('calendar.alarm', string="Reminders")
    booking_template_id = fields.Many2one('mail.template', string='Booking Email', domain=[('model', '=', 'appointment.booking')])
    cancel_template_id = fields.Many2one('mail.template', string='Cancellation Email', domain=[('model', '=', 'appointment.booking')])
    feedback_template_id = fields.Many2one(
        'mail.template', string='Feedback Email', domain=[('model', '=', 'appointment.booking')],
        default=lambda self: self.env.ref('appointment.email_template_feedback_request', raise_if_not_found=False),
        help="Sent to the customer once the appointment is over, to rate it. "
             "The ratings are listed in Reporting > Ratings. Leave empty to not ask for feedback.")
    
    # Options Tab
    allow_invitations = fields.Boolean(string="Allow Invitations", default=False)
    create_opportunity = fields.Boolean(string="Create Opportunity", default=False, help="Automatically create a CRM Lead/Opportunity when an appointment is booked.")
    has_payment_step = fields.Boolean(string="Up-front Payment", default=False)
    product_id = fields.Many2one('product.product', string="Booking Fees", domain=[('type', '=', 'service')], check_company=True)
    auto_confirm = fields.Boolean(string="Auto Confirm", default=True)
    auto_confirm_limit = fields.Integer('Auto Confirm Limit', default=100)
    display_pictures = fields.Boolean('Display pictures', default=True)
    schedule_type = fields.Selection([('weekly', 'Weekly'), ('flexible', 'Flexible')], string='Schedule', default='weekly')
    max_schedule_days = fields.Integer('Within the next X days', default=15)
    min_schedule_hours = fields.Float('at least X hours before', default=1.0)
    slot_interval = fields.Float('Create slot every', default=1.0)
    min_cancellation_hours = fields.Float('Cancellation up to', default=1.0)
    employee_schedule = fields.Boolean('Employee Schedule', default=False)

    @api.model
    def _create_and_open_appointment(self, vals):
        new_type = self.create(vals)
        return {
            'name': 'Appointment Type',
            'type': 'ir.actions.act_window',
            'res_model': 'appointment.type',
            'res_id': new_type.id,
            'view_mode': 'form',
            'target': 'current',
        }

    @api.model
    def action_preset_meeting(self):
        return self._create_and_open_appointment({
            'name': 'Meeting',
            'appointment_duration': 1.0,
            'location': 'office',
        })

    @api.model
    def action_preset_video(self):
        return self._create_and_open_appointment({
            'name': 'Video Call',
            'appointment_duration': 1.0,
            'location': 'online',
        })

    @api.model
    def action_preset_table(self):
        return self._create_and_open_appointment({
            'name': 'Table Booking',
            'appointment_duration': 2.0,
            'location': 'custom',
            'booking_target': 'resources',
        })

    @api.model
    def action_preset_resource(self):
        return self._create_and_open_appointment({
            'name': 'Book a Resource',
            'appointment_duration': 1.0,
            'booking_target': 'resources',
        })

    @api.constrains('slot_interval', 'appointment_duration')
    def _check_slot_configuration(self):
        for record in self:
            if getattr(record, 'slot_interval', 1.0) <= 0:
                raise ValidationError(
                    _("Slot Interval must be greater than 0.")
                )

            if getattr(record, 'appointment_duration', 1.0) <= 0:
                raise ValidationError(
                    _("Appointment Duration must be greater than 0.")
                )
