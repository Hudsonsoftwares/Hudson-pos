# pyrefly: ignore [missing-import]
from lxml import etree

# pyrefly: ignore [missing-import]
from odoo import fields, models, _

SCHEDULE_VALID_ATTRIBUTES = {
    '__validate__',  # ir.ui.view implementation detail
    'class',
    'js_class',
    'string',
    'group_by',
    'default_scale',
}


class IrUiView(models.Model):
    _inherit = 'ir.ui.view'

    # Gantt-like timeline of the bookings, one row per staff member / resource
    type = fields.Selection(selection_add=[('appointment_schedule', "Schedule")],
                            ondelete={'appointment_schedule': 'cascade'})

    def _validate_tag_appointment_schedule(self, node, name_manager, node_info):
        if not node_info['validate']:
            return
        for child in node.iterchildren(tag=etree.Element):
            self._raise_view_error(_("A schedule view cannot contain any element, got <%s>", child.tag), child)
        remaining = set(node.attrib) - SCHEDULE_VALID_ATTRIBUTES
        if remaining:
            self._raise_view_error(_(
                "Invalid attributes (%(invalid)s) in schedule view. Attributes must be in (%(valid)s)",
                invalid=", ".join(sorted(remaining)),
                valid=", ".join(sorted(SCHEDULE_VALID_ATTRIBUTES - {'__validate__'})),
            ), node)
        if node.get('group_by') not in (None, 'staff_user_id', 'resource_ids'):
            self._raise_view_error(_("group_by must be staff_user_id or resource_ids"), node)
        if node.get('default_scale') not in (None, 'day', 'week', 'month'):
            self._raise_view_error(_("default_scale must be day, week or month"), node)

    def _get_view_info(self):
        return {'appointment_schedule': {'icon': 'event_upcoming'}} | super()._get_view_info()
