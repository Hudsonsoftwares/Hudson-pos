# pyrefly: ignore [missing-import]
from odoo import api, models, fields, _
# pyrefly: ignore [missing-import]
from odoo.exceptions import ValidationError

class AppointmentClosingDay(models.Model):
    _name = 'appointment.closing.day'
    _description = 'Appointment Closing Day'
    _check_company_auto = True

    company_id = fields.Many2one(
        'res.company', string='Company', index=True,
        default=lambda self: self.env.company,
        help="Leave empty to apply this closing day to all companies.")

    closing_type = fields.Selection([
        ('appointments', 'Appointments'),
        ('resources', 'Resources'),
        ('users', 'Users')
    ], string='Closing Type', default='appointments', required=True)
    
    name = fields.Char('Reason', required=True)
    start_datetime = fields.Datetime('Start Date', required=True, default=lambda self: self._default_day_bound(end=False))
    end_datetime = fields.Datetime('End Date', required=True, default=lambda self: self._default_day_bound(end=True))
    
    appointment_type_ids = fields.Many2many('appointment.type', string='Appointments', check_company=True)
    resource_id = fields.Many2one('appointment.resource', string='Resource', check_company=True)
    user_id = fields.Many2one('res.users', string='User', check_company=True)

    @api.model
    def default_get(self, fields):
        res = super().default_get(fields)
        # opened for given appointment types: use their company
        type_ids = self.env.context.get('default_appointment_type_ids')
        if ('company_id' in fields and 'default_company_id' not in self.env.context
                and isinstance(type_ids, list) and type_ids and all(isinstance(i, int) for i in type_ids)):
            companies = self.env['appointment.type'].browse(type_ids).exists().company_id
            if len(companies) == 1:
                res['company_id'] = companies.id
        return res

    def _local_day_bound(self, value, end):
        """Start (00:00:00) or end (23:59:59) of the user's local day of naive UTC ``value``."""
        import pytz
        from datetime import datetime, time
        tz = pytz.timezone(self.env.user.tz or self.env.company.partner_id.tz or 'UTC')
        local_day = pytz.UTC.localize(value).astimezone(tz).date()
        local = datetime.combine(local_day, time(23, 59, 59) if end else time.min)
        return tz.localize(local).astimezone(pytz.UTC).replace(tzinfo=None)

    def _default_day_bound(self, end):
        # like Odoo's closing days: a new closing covers the whole current day
        return self._local_day_bound(fields.Datetime.now(), end)

    @api.onchange('start_datetime')
    def _onchange_start_datetime(self):
        if self.start_datetime and (not self.end_datetime or self.end_datetime <= self.start_datetime):
            self.end_datetime = self._local_day_bound(self.start_datetime, end=True)

    @api.constrains('start_datetime', 'end_datetime')
    def _check_dates(self):
        for closing in self:
            if closing.start_datetime and closing.end_datetime and closing.end_datetime <= closing.start_datetime:
                raise ValidationError(_("The end of a closing day must be after its start."))

    @api.constrains('closing_type', 'resource_id', 'user_id')
    def _check_target(self):
        for closing in self:
            if closing.closing_type == 'resources' and not closing.resource_id:
                raise ValidationError(_("Select the resource to close."))
            if closing.closing_type == 'users' and not closing.user_id:
                raise ValidationError(_("Select the user to close."))

    @api.onchange('closing_type')
    def _onchange_closing_type(self):
        # only the target of the selected type is kept
        if self.closing_type != 'appointments':
            self.appointment_type_ids = False
        if self.closing_type != 'resources':
            self.resource_id = False
        if self.closing_type != 'users':
            self.user_id = False

    def action_save(self):
        return {'type': 'ir.actions.act_window_close'}
