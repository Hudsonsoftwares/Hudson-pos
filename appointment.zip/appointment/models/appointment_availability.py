# pyrefly: ignore [missing-import]
from odoo import models, fields, api, _
# pyrefly: ignore [missing-import]
from odoo.exceptions import ValidationError

class AppointmentAvailability(models.Model):
    _name = 'appointment.availability'
    _description = 'Appointment Availability'

    appointment_type_id = fields.Many2one('appointment.type', string='Appointment Type', required=True, ondelete='cascade')
    day_of_week = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday'),
    ], string='Day of Week', required=True)
    
    start_time = fields.Float('Start Time', required=True)
    end_time = fields.Float('End Time', required=True)

    @api.constrains('start_time', 'end_time')
    def _check_times(self):
        for availability in self:
            if not 0 <= availability.start_time < availability.end_time <= 24:
                raise ValidationError(_(
                    "Availability hours must be between 00:00 and 24:00, and \"To\" must be later than \"From\" "
                    "(use 24-hour time, e.g. 16:00 for 4 PM)."
                ))
