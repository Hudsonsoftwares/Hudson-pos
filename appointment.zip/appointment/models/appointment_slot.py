# pyrefly: ignore [missing-import]
from odoo import models, fields, api, _
# pyrefly: ignore [missing-import]
from odoo.exceptions import ValidationError


class AppointmentSlot(models.Model):
    """One-off slot of an appointment type using the "Flexible" schedule:
    each slot can be booked as one appointment lasting the whole slot."""
    _name = 'appointment.slot'
    _description = 'Appointment Flexible Slot'
    _order = 'start_datetime, id'

    appointment_type_id = fields.Many2one(
        'appointment.type', string='Appointment Type', required=True, ondelete='cascade', index=True)
    start_datetime = fields.Datetime('Start', required=True)
    end_datetime = fields.Datetime('End', required=True)
    allday = fields.Boolean('All day', help="The slot covers the whole days, from the start date to the end date.")

    @api.constrains('start_datetime', 'end_datetime', 'allday')
    def _check_dates(self):
        for slot in self:
            if not slot.start_datetime or not slot.end_datetime:
                continue
            if slot.allday:
                if slot.end_datetime < slot.start_datetime:
                    raise ValidationError(_("The end of a slot must be after its start."))
            elif slot.end_datetime <= slot.start_datetime:
                raise ValidationError(_("The end of a slot must be after its start."))

    def _get_period_utc(self):
        """(start, end) naive UTC covered by the slot; an all-day slot covers
        whole days in the appointment timezone."""
        self.ensure_one()
        if not self.allday:
            return self.start_datetime, self.end_datetime
        import pytz
        from datetime import datetime, time, timedelta
        tz = pytz.timezone(self.appointment_type_id.appointment_tz or 'UTC')
        first_day = pytz.UTC.localize(self.start_datetime).astimezone(tz).date()
        last_day = pytz.UTC.localize(self.end_datetime).astimezone(tz).date()
        start = tz.localize(datetime.combine(first_day, time.min))
        end = tz.localize(datetime.combine(last_day + timedelta(days=1), time.min))
        return (start.astimezone(pytz.UTC).replace(tzinfo=None),
                end.astimezone(pytz.UTC).replace(tzinfo=None))
