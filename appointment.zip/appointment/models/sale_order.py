# pyrefly: ignore [missing-import]
from odoo import models

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def _action_confirm(self):
        res = super()._action_confirm()
        self._action_confirm_appointment_bookings()
        return res

    def _action_confirm_appointment_bookings(self):
        """Confirm the bookings waiting for the payment of these orders.

        Done with sudo: confirming a quotation must keep working for
        salespeople (or payment processing) without Appointments access.
        """
        bookings = self.env['appointment.booking'].sudo().search([
            ('sale_order_id', 'in', self.ids),
            ('state', '=', 'pending_payment')
        ])
        if bookings:
            bookings.write({'state': 'confirmed'})
            bookings._send_booking_confirmation_notifications()
