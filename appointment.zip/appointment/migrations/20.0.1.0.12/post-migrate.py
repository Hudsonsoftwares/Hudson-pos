import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    """Back to a single "Linked Resource".

    Version 20.0.1.0.11 (since reverted) moved the linked resource into a
    many2many table. Put it back in the linked_resource_id column (one per
    resource, the first one) before Odoo removes that table.
    """
    cr.execute("SELECT to_regclass('appointment_resource_linked_rel') IS NOT NULL")
    if not cr.fetchone()[0]:
        return
    cr.execute("""
        SELECT 1 FROM information_schema.columns
         WHERE table_name = 'appointment_resource' AND column_name = 'linked_resource_id'
    """)
    if not cr.fetchone():
        # upgrading straight to the many2many again (20.0.1.0.13): nothing to restore
        return
    cr.execute("""
        UPDATE appointment_resource r
           SET linked_resource_id = x.linked_resource_id
          FROM (SELECT resource_id, MIN(linked_resource_id) AS linked_resource_id
                  FROM appointment_resource_linked_rel
                 WHERE resource_id != linked_resource_id
                 GROUP BY resource_id) x
         WHERE x.resource_id = r.id
           AND r.linked_resource_id IS NULL
    """)
    _logger.info("appointment: linked resource restored on %s resource(s)", cr.rowcount)
