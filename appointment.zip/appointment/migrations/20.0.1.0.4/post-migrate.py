def migrate(cr, version):
    """Tags, reminders and notes of bookings are now stored on the booking
    (they were read from the calendar event): copy the existing values."""
    cr.execute("""
        INSERT INTO appointment_booking_calendar_event_type_rel (booking_id, type_id)
        SELECT b.id, rel.type_id
          FROM appointment_booking b
          JOIN meeting_category_rel rel ON rel.event_id = b.calendar_event_id
        ON CONFLICT DO NOTHING
    """)
    cr.execute("""
        INSERT INTO appointment_booking_calendar_alarm_rel (booking_id, alarm_id)
        SELECT b.id, rel.calendar_alarm_id
          FROM appointment_booking b
          JOIN calendar_alarm_calendar_event_rel rel ON rel.calendar_event_id = b.calendar_event_id
        ON CONFLICT DO NOTHING
    """)
    cr.execute("""
        UPDATE appointment_booking b
           SET notes = e.notes
          FROM calendar_event e
         WHERE e.id = b.calendar_event_id
           AND b.notes IS NULL
           AND e.notes IS NOT NULL
    """)
