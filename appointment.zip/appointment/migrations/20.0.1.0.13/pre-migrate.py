def migrate(cr, version):
    """Several linked resources (table appointment_resource_linked_rel).

    A database that ran the reverted 20.0.1.0.11 still has that table, with
    outdated rows: the single "Linked Resource" column is the current data
    (copied in post-migrate), so empty the table first. When the column is
    missing (database still on 20.0.1.0.11), the table is the current data:
    keep it.
    """
    cr.execute("SELECT to_regclass('appointment_resource_linked_rel') IS NOT NULL")
    if not cr.fetchone()[0]:
        return
    cr.execute("""
        SELECT 1 FROM information_schema.columns
         WHERE table_name = 'appointment_resource' AND column_name = 'linked_resource_id'
    """)
    if cr.fetchone():
        cr.execute("DELETE FROM appointment_resource_linked_rel")
