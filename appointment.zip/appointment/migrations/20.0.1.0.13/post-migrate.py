import logging

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    """Copy the former single "Linked Resource" (column linked_resource_id)
    into the new "Linked Resources" many2many."""
    cr.execute("""
        SELECT 1 FROM information_schema.columns
         WHERE table_name = 'appointment_resource' AND column_name = 'linked_resource_id'
    """)
    if not cr.fetchone():
        return
    cr.execute("""
        INSERT INTO appointment_resource_linked_rel (resource_id, linked_resource_id)
        SELECT r.id, r.linked_resource_id
          FROM appointment_resource r
          JOIN appointment_resource l ON l.id = r.linked_resource_id
         WHERE r.linked_resource_id != r.id
        ON CONFLICT DO NOTHING
    """)
    _logger.info("appointment: %s linked resource(s) moved to the new Linked Resources field", cr.rowcount)
