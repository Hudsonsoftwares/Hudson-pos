from odoo import api, SUPERUSER_ID


def migrate(cr, version):
    """Answers to dropdown / radio / checkbox questions only stored the chosen
    option names as text: fill the new "Selected Answer" from them."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    answers = env['appointment.answer'].search([
        ('question_id.question_type', 'in', ('select', 'radio', 'checkbox')),
        ('value_text', '!=', False),
    ])
    for answer in answers:
        if answer.value_answer_ids:
            continue
        chosen_names = {name.strip() for name in answer.value_text.split(',')}
        chosen = answer.question_id.answer_ids.filtered(lambda option: option.name in chosen_names)
        if chosen:
            answer.value_answer_ids = chosen
