def migrate(cr, version):
    """Questions became shareable between appointment types (Many2one -> Many2many).

    Copy each question's former appointment type into the new relation table,
    then drop the old column so its ON DELETE CASCADE foreign key can no longer
    delete questions when an appointment type is removed.
    """
    cr.execute("""
        SELECT 1
          FROM information_schema.columns
         WHERE table_schema = current_schema()
           AND table_name = 'appointment_question'
           AND column_name = 'appointment_type_id'
    """)
    if not cr.fetchone():
        return

    cr.execute("""
        INSERT INTO appointment_type_question_rel (appointment_type_id, question_id)
        SELECT q.appointment_type_id, q.id
          FROM appointment_question q
          JOIN appointment_type t ON t.id = q.appointment_type_id
        ON CONFLICT DO NOTHING
    """)
    cr.execute("ALTER TABLE appointment_question DROP COLUMN appointment_type_id CASCADE")
