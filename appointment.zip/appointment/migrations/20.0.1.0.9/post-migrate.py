import logging

from odoo import api, SUPERUSER_ID

_logger = logging.getLogger(__name__)


def migrate(cr, version):
    """Paid bookings stuck in "Pending Payment".

    Their quotation required an online signature, so the payment never
    confirmed it (and so never confirmed the booking). Confirm the quotations
    that are already paid; confirming them confirms their bookings.
    """
    env = api.Environment(cr, SUPERUSER_ID, {})
    bookings = env['appointment.booking'].search([
        ('state', '=', 'pending_payment'),
        ('sale_order_id', '!=', False),
    ])
    for order in bookings.sale_order_id:
        paid = order.transaction_ids.filtered(lambda tx: tx.state in ('authorized', 'done'))
        try:
            with cr.savepoint():
                if order.state in ('draft', 'sent'):
                    if not paid or not order._is_confirmation_amount_reached():
                        continue
                    order.require_signature = False
                    order.with_context(send_email=True).action_confirm()
                elif order.state == 'sale':
                    # order confirmed meanwhile, booking left behind
                    order._action_confirm_appointment_bookings()
            _logger.info("Appointment: confirmed paid order %s and its booking(s)", order.name)
        except Exception:
            _logger.exception("Appointment: could not confirm paid order %s", order.name)
