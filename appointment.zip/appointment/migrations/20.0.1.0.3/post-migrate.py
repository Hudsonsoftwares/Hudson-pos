def migrate(cr, version):
    """Set the new "Responsible" of existing appointment types: their creator,
    else their first staff member (internal, active users only, never the
    system user)."""
    cr.execute("""
        UPDATE appointment_type t
           SET user_id = t.create_uid
          FROM res_users u
         WHERE t.user_id IS NULL
           AND u.id = t.create_uid
           AND u.id != 1
           AND u.active
           AND NOT u.share
    """)
    cr.execute("""
        UPDATE appointment_type t
           SET user_id = staff.user_id
          FROM (
                SELECT DISTINCT ON (rel.appointment_type_id)
                       rel.appointment_type_id AS type_id, rel.res_users_id AS user_id
                  FROM appointment_type_res_users_rel rel
                  JOIN res_users u ON u.id = rel.res_users_id
                 WHERE u.id != 1 AND u.active AND NOT u.share
              ORDER BY rel.appointment_type_id, rel.res_users_id
               ) staff
         WHERE t.user_id IS NULL
           AND staff.type_id = t.id
    """)
