def migrate(cr, version):
    """Feedback requests are checked every minute (the job is a noupdate
    record, so the new interval has to be set on existing databases)."""
    cr.execute("""
        UPDATE ir_cron c
           SET interval_number = 1, interval_type = 'minutes'
          FROM ir_model_data d
         WHERE d.module = 'appointment'
           AND d.name = 'ir_cron_appointment_feedback'
           AND d.model = 'ir.cron'
           AND c.id = d.res_id
    """)
