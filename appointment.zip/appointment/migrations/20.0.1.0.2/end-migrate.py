def migrate(cr, version):
    """Fill the company of bookings and answers that existed before the
    multi-company fields were added.

    The stored related ``company_id`` fields were left empty on existing
    answers, which made them "shared" and visible in every company.
    Runs at the end of the upgrade so no later recomputation overrides it.
    """
    cr.execute("""
        UPDATE appointment_booking b
           SET company_id = t.company_id
          FROM appointment_type t
         WHERE t.id = b.appointment_type_id
           AND b.company_id IS DISTINCT FROM t.company_id
    """)
    cr.execute("""
        UPDATE appointment_answer a
           SET company_id = b.company_id
          FROM appointment_booking b
         WHERE b.id = a.booking_id
           AND a.company_id IS DISTINCT FROM b.company_id
    """)
