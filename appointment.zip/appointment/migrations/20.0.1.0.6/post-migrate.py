def migrate(cr, version):
    """Feedback requests: never send them for appointments that were already
    over before this version, and use the default feedback email on the
    existing appointment types (as for new ones)."""
    cr.execute("""
        UPDATE appointment_booking
           SET feedback_sent = TRUE
         WHERE end_datetime <= (NOW() AT TIME ZONE 'UTC')
    """)
    cr.execute("""
        SELECT res_id FROM ir_model_data
         WHERE module = 'appointment' AND name = 'email_template_feedback_request'
    """)
    row = cr.fetchone()
    if row:
        cr.execute("""
            UPDATE appointment_type SET feedback_template_id = %s WHERE feedback_template_id IS NULL
        """, (row[0],))
